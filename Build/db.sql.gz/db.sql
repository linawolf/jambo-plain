/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_jambotheme_wastereport`
--

DROP TABLE IF EXISTS `tx_jambotheme_wastereport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_jambotheme_wastereport` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ward` varchar(128) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `missed_on` varchar(10) NOT NULL DEFAULT '',
  `waste_type` varchar(64) NOT NULL DEFAULT '',
  `details` text DEFAULT NULL,
  `reporter_name` varchar(255) NOT NULL DEFAULT '',
  `reporter_email` varchar(255) NOT NULL DEFAULT '',
  `reporter_phone` varchar(64) NOT NULL DEFAULT '',
  `digest_sent_at` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `pending` (`digest_sent_at`),
  KEY `retention` (`crdate`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_config`
--

DROP TABLE IF EXISTS `index_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_config` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `set_id` int(11) NOT NULL DEFAULT 0,
  `session_data` mediumtext DEFAULT NULL,
  `alternative_source_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `depth` int(10) unsigned NOT NULL DEFAULT 0,
  `table2index` varchar(255) NOT NULL DEFAULT '',
  `indexcfgs` longtext DEFAULT NULL,
  `get_params` varchar(255) NOT NULL DEFAULT '',
  `fieldlist` varchar(255) NOT NULL DEFAULT '',
  `externalUrl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `extensions` varchar(255) NOT NULL DEFAULT '',
  `url_deny` longtext DEFAULT NULL,
  `records_indexonchange` smallint(5) unsigned NOT NULL DEFAULT 0,
  `timer_next_indexing` bigint(20) NOT NULL DEFAULT 0,
  `timer_offset` bigint(20) NOT NULL DEFAULT 0,
  `timer_frequency` int(10) unsigned NOT NULL DEFAULT 86400,
  `recordsbatch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_config`
--

LOCK TABLES `index_config` WRITE;
/*!40000 ALTER TABLE `index_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_fulltext`
--

DROP TABLE IF EXISTS `index_fulltext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_fulltext` (
  `phash` varchar(32) NOT NULL,
  `fulltextdata` mediumtext DEFAULT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_fulltext`
--

LOCK TABLES `index_fulltext` WRITE;
/*!40000 ALTER TABLE `index_fulltext` DISABLE KEYS */;
INSERT INTO `index_fulltext` VALUES
('0e6531c5d0ae0b0a3fa3622a23f7818e','Ward offices closed on 20 October All ward offices are closed for Mashujaa Day. Online services remain available.  All twelve ward offices and the county headquarters are closed on Tuesday 20 October for Mashujaa Day, and open again at 08:00 on Wednesday 21 October.  Permits, land rates and appointments can be dealt with online while the offices are closed.  '),
('1274e6ec4a76f4918a72b6b88575b2f1','Taarifa ya ufikivu Taarifa ya ufikivu\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Tovuti hii imetengenezwa itumike na kila mtu, wakiwemo wanaotumia kisomaji skrini, kibodi pekee, au kikuzaji.  Ukurasa ukikuzuia, tuambie kwa 0800 000 000 nasi tutarekebisha na kukueleza kilichobadilika.  '),
('132c3127164c3476556136c8b825863f','Siku mpya ya kuchukua taka kwa wodi ya Riverside Kuanzia tarehe 1 Novemba, taka za nyumbani katika wodi ya Riverside zitachukuliwa siku ya Jumanne badala ya Alhamisi.  Mabadiliko haya yanaruhusu lori moja kuhudumia wodi za Riverside na Market katika safari moja.  Tafadhali weka mapipa kando ya barabara kabla ya saa moja asubuhi. Kama taka hazikuchukuliwa, ripoti katika ukurasa wa ukusanyaji wa taka.  '),
('2398fdd24f0b64e9f9f3e15fc0bb6109','Notices 22 October 2026 \n            \n            \n              Public participation on the 2027 county budget  \n            \n                 Forums open in all twelve wards from 4 November. The draft estimates are published with this notice. \n            \n         \n    \n         \n            \n                 15 October 2026 \n            \n            \n              Tender: supply of water meters  \n            \n                 Bids close at 11:00 on 6 November at the county procurement office. \n            \n         \n    \n         \n            \n                 9 October 2026 \n            \n            \n              Ward offices closed on 20 October  \n            \n                 All ward offices are closed for Mashujaa Day. Online services remain available. \n            \n         \n    \n         \n            \n                 28 September 2026 \n            \n            \n              New collection day for Riverside ward  \n            \n                 From 1 November, household waste in Riverside ward is collected on Tuesdays instead of Thursdays.  '),
('3d798c3f120fdabe32985de46a5fc2fd','Home County services, online and in one place\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Apply for a permit, pay a levy, book an appointment at a ward office, or read what the council decided at its last sitting.   Find a service   Book an appointment  \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                A look around the county\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n    \n        \n        \n        \n        \n\n         \n             \n                \n                     \n                         \n                        \n                             The county headquarters on Uhuru Road, Jambo Town. \n                        \n                     \n                \n                     \n                         \n                        \n                             One of the twelve ward offices where applications are handed in. \n                        \n                     \n                \n                     \n                         \n                        \n                             A public participation forum on the county budget. \n                        \n                     \n                \n             \n\n            \n                  \n                  \n                  \n            \n         \n    \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n                 \n             \n        \n\n        \n             \n                 \n                     Popular services \n                     \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                 Business permits \n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Apply for a single business permit, renew one, or change the details on it. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                 Land rates \n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Check what is owed on a parcel and pay the current year’s rates. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Building approvals\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Submit plans for approval and follow the status of a submission. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Waste collection\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Collection days by ward, and how to report a missed collection. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Health facilities\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Opening hours and services of the county clinics and dispensaries. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                             \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Public participation\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Dates, venues and papers for the county’s public participation forums. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n \n                        \n                     \n                 \n             \n        \n\n        \n             \n                 \n                     Notices and announcements \n                     \n                        \n                             \n                                \n                                     22 October 2026 \n                                \n                                \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Public participation on the 2027 county budget\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Forums open in all twelve wards from 4 November. The draft estimates are published with this notice. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n                             \n                        \n                             \n                                \n                                     15 October 2026 \n                                \n                                \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Tender: supply of water meters\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Bids close at 11:00 on 6 November at the county procurement office. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n                             \n                        \n                             \n                                \n                                     9 October 2026 \n                                \n                                \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Ward offices closed on 20 October\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     All ward offices are closed for Mashujaa Day. Online services remain available.  '),
('480f7b1104526ca784330338f9bc8f68','Zabuni Zabuni\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Zabuni zilizo wazi za Kaunti ya Jambo, pamoja na tarehe za kufunga na nyaraka za kupakua.  Zabuni hupokelewa katika ofisi ya ununuzi ya kaunti. Washindi huchapishwa hapa tathmini ikikamilika.  '),
('4f6e807051e61027dadc02f9f2906020','County assembly County assembly\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     The assembly makes the laws of the county and approves its budget.  Sittings are open to the public. Order papers, bills and the record of each sitting are published after it.  '),
('4fe65afd46a96ebb6113e4082c07329f','Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027 Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili.  Kaunti inawakaribisha wakazi kutoa maoni kuhusu makadirio ya awali ya bajeti ya mwaka wa fedha wa 2027. Kila wodi itafanya mkutano mmoja, kuanzia saa nne asubuhi katika ofisi ya wodi.  Maoni yaliyoandikwa yanaweza kuachwa katika ofisi yoyote ya wodi au kutumwa kwa karani wa kaunti hadi tarehe 18 Novemba.  '),
('5192c25f9e1778c3c79dff990fa03437','Huduma Huduma\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Kila kitu ambacho kaunti hufanya kwa wakazi na wafanyabiashara, kimepangwa kulingana na unachohitaji kufanya.  Huduma nyingi zinaweza kuanzishwa mtandaoni. Pale inapohitajika kufika ana kwa ana, ukurasa wa huduma husika unaeleza ofisi ya kwenda na vitu vya kubeba.  '),
('53a65a8e3f722edf05d31693dce3236f','Mwanzo   '),
('55a8841b368fd8e1405e80ae0cf43f69','Tender: supply of water meters Bids close at 11:00 on 6 November at the county procurement office.  The county invites sealed bids for the supply and delivery of 2,000 domestic water meters.  Tender documents are available at the procurement office at the county headquarters from 20 October, against a non-refundable fee of KSh 1,000. Bids are opened publicly immediately after closing.  '),
('56ce185f3262c9101626cfd28a4127a4','Services Services\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Everything the county does for residents and businesses, grouped by what you need to get done.  Most services can be started online. Where a visit is needed, the page for that service says which office to go to and what to bring.  '),
('56e8dbba6bd49275b2763e0aa24d2418','New collection day for Riverside ward From 1 November, household waste in Riverside ward is collected on Tuesdays instead of Thursdays.  The change lets one lorry serve Riverside and Market wards on the same round.  Please leave bins at the kerb by 07:00. If a collection is missed, report it on the waste collection page.  '),
('67d787a12066aa33f927bc0bed2dc3fd','Contact us Contact us\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     How to reach Jambo County Council.  County Headquarters, Uhuru Road, Jambo Town. Monday to Friday, 08:00–17:00. The contact centre answers on 0800 000 000.  '),
('6d2ddd1174e062f12957e8f7a89bafb1','Land rates Land rates\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Land rates are charged on every rateable parcel in the county and fall due on 1 January each year.  Check the balance on a parcel with its plot number, then pay online, at a ward office, or by bank transfer.  '),
('78cabd40e1e1f417b9f83789c2321f4a','Business permits Business permits\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Every business operating in Jambo County needs a single business permit for the current year. Apply online, at a ward office, or at the county headquarters. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Who needs a permit\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     A permit is required for any trade, service or manufacturing activity carried out in the county, including a business run from home. One permit covers one premises. A business with premises in two wards needs a permit for each. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                What you need to apply\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n      The registration certificate of the business  The national identity card or passport of the owner  The KRA PIN certificate  The plot number or the lease agreement of the premises  \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Fees\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n      Permit fees for the 2026 calendar year    Category  Employees  Fee per year      Small trader  Up to 5  KSh 5,000    Medium enterprise  6 to 20  KSh 15,000    Large enterprise  More than 20  KSh 40,000    \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                How long it takes\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     A complete application is decided within five working days. The permit is issued at the office where the application was made, and a copy is sent to the email address on the application. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                \n\n      Renewing a permit  Permits run to 31 December and are renewed from 2 January. A permit renewed after 31 March carries a late fee of ten per cent.  \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Contact\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Department of Trade, Industry and Cooperatives County Headquarters, second floor Monday to Friday, 08:00–17:00  '),
('78d410ed8d322872c93e023c151a02b9','Waste collection Waste collection\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Household waste is collected once a week, on the day set for your ward.  If your waste was not collected on the day it should have been, tell us below. The waste team receives every report the next morning. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Report a missed collection  '),
('7fb9c8e8b02c27d3a5c5c229300fb27f','Faragha Faragha\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Kaunti hufanya nini na taarifa unazotoa.  Taarifa zinazotolewa na maombi hutumika kuamua maombi hayo na huhifadhiwa kwa muda unaotakiwa kisheria.  '),
('85c2621b0fce09ac51613f18ce135f4b','Privacy Privacy\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     What the county does with the data you give it.  Data submitted with an application is used to decide that application and is kept for as long as the law requires.  '),
('97b8cd0fe54b6d09a38ff14702afb4bc','Vibali vya biashara Vibali vya biashara\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Kila biashara inayofanya kazi katika Kaunti ya Jambo inahitaji kibali kimoja cha biashara kwa mwaka husika. Omba mtandaoni, katika ofisi ya wodi, au katika makao makuu ya kaunti. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Nani anahitaji kibali\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Kibali kinahitajika kwa biashara, huduma au utengenezaji wowote unaofanyika katika kaunti, pamoja na biashara inayoendeshwa nyumbani. Kibali kimoja kinahusu eneo moja. Biashara yenye maeneo katika wodi mbili inahitaji kibali kwa kila eneo. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Unachohitaji ili kuomba\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n      Cheti cha usajili wa biashara  Kitambulisho cha taifa au pasipoti ya mmiliki  Cheti cha PIN cha KRA  Nambari ya kiwanja au mkataba wa kukodi eneo  \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Ada\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n      Ada za vibali kwa mwaka wa 2026    Kundi  Wafanyakazi  Ada kwa mwaka      Mfanyabiashara mdogo  Hadi 5  KSh 5,000    Biashara ya kati  6 hadi 20  KSh 15,000    Biashara kubwa  Zaidi ya 20  KSh 40,000    \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Muda unaochukuliwa\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Maombi kamili hukamilishwa ndani ya siku tano za kazi. Kibali hutolewa katika ofisi ambapo maombi yalifanyika, na nakala hutumwa kwa barua pepe iliyotajwa katika maombi. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                \n\n      Kuongeza muda wa kibali  Vibali huisha tarehe 31 Desemba na huongezwa muda kuanzia tarehe 2 Januari. Kibali kinachoongezwa muda baada ya tarehe 31 Machi hutozwa ada ya ucheleweshaji ya asilimia kumi.  \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Mawasiliano\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Idara ya Biashara, Viwanda na Ushirika Makao Makuu ya Kaunti, ghorofa ya pili Jumatatu hadi Ijumaa, 08:00–17:00  '),
('9bd8393860e6e9cf4c907a0919ca687d','Departments Departments\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     The ten departments of the county and what each of them is responsible for.  Every department lists the services it runs, the offices where they are delivered, and who to ask when something goes wrong.  '),
('b4b473e088c0a9f40a7eb9053a621871','Ukusanyaji wa taka Ukusanyaji wa taka\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Taka za nyumbani huchukuliwa mara moja kwa wiki, siku iliyopangwa kwa wodi yako.  Ikiwa taka zako hazikuchukuliwa siku iliyopangwa, tuambie hapa chini. Timu ya taka hupokea kila ripoti asubuhi inayofuata. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Ripoti taka zisizochukuliwa  '),
('b676e408624805da6b4c35566cad496c','Bunge la kaunti Bunge la kaunti\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Bunge hutunga sheria za kaunti na kuidhinisha bajeti yake.  Vikao viko wazi kwa umma. Ratiba, miswada na kumbukumbu za kila kikao huchapishwa baada yake.  '),
('bec4701003457746b3e8eb7b62a181cf','Business permits Business permits\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     This page is in Easy Read.  It tells you about business permits. \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                What is a business permit?\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             A permit is a paper from the county.  It says you can run your business. \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Who needs a permit?\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             You need a permit for every business.  This is true if you work from home too.  You need one permit for each place you work. \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                What you need to bring\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n              The paper that says your business is registered  Your ID card or your passport  Your KRA PIN paper  The paper for your plot or your rent  \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                What it costs\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             You pay money once a year.  How much you pay depends on how many people work for you.   Up to 5 people: 5,000 shillings  6 to 20 people: 15,000 shillings  More than 20 people: 40,000 shillings  \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                How long it takes\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             We answer in 5 working days.  You get your permit at the office where you asked.  We also send a copy to your email. \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Every year you need a new permit\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             Your permit stops on 31 December.  You can get a new one from 2 January.  If you wait until after 31 March, you pay extra money. \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                If you need help\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             You can call us.  Our number is 0800 000 000.  We answer Monday to Friday.  We are there from 8 in the morning to 5 in the evening. \n         \n     \n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n    \n    \n         \n            \n\n    \n             \n                Where to find us\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n    \n     \n        \n             \n                \n                     \n                \n             \n        \n         \n             You can come to our office.  Department of Trade.  County Headquarters, second floor.  '),
('bf10d741ea1a3f66bd8f054520f99b4f','Matangazo 22 Oktoba 2026 \n            \n            \n              Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027  \n            \n                 Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili. \n            \n         \n    \n         \n            \n                 15 Oktoba 2026 \n            \n            \n              Zabuni: usambazaji wa mita za maji  \n            \n                 Zabuni zitafungwa saa 5:00 asubuhi tarehe 6 Novemba katika ofisi ya ununuzi ya kaunti. \n            \n         \n    \n         \n            \n                 9 Oktoba 2026 \n            \n            \n              Ofisi za wodi zitafungwa tarehe 20 Oktoba  \n            \n                 Ofisi zote za wodi zitafungwa kwa Siku ya Mashujaa. Huduma za mtandaoni zitaendelea kupatikana. \n            \n         \n    \n         \n            \n                 28 Septemba 2026 \n            \n            \n              Siku mpya ya kuchukua taka kwa wodi ya Riverside  \n            \n                 Kuanzia tarehe 1 Novemba, taka za nyumbani katika wodi ya Riverside zitachukuliwa siku ya Jumanne badala ya Alhamisi.  '),
('ca9fd685b16e5922e940b713a6166e7f','Masharti ya matumizi Masharti ya matumizi\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Masharti ambayo tovuti hii hutolewa kwayo.  Taarifa zilizopo hapa huchapishwa kwa nia njema. Zikitofautiana na uamuzi wa halmashauri, uamuzi hushinda.  '),
('d031f71935b894cc76f91a35ad5e466a','Terms of use Terms of use\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     The terms on which this site is provided.  The information here is published in good faith. Where it differs from a decision of the council, the decision stands.  '),
('d2b728c29c935917865a91198146007e','Wasiliana nasi Wasiliana nasi\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Jinsi ya kuwasiliana na Kaunti ya Jambo.  Makao Makuu ya Kaunti, Barabara ya Uhuru, Mji wa Jambo. Jumatatu hadi Ijumaa, 08:00–17:00. Kituo cha mawasiliano hupatikana kwa 0800 000 000.  '),
('d3c7afff432dc4a8674da3b6cfcc9624','Jambo County Council Jambo County Council\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     These pages are in Easy Read.  Easy Read is easier to read.  It has short sentences and pictures.  '),
('e45333e70f61f6118c6492c55e8605b9','Services Services\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     These are things the county does for you.  Right now one page is in Easy Read.  It is about business permits.  '),
('ec2f2d3462894284b37105ddedffd64c','Idara Idara\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Idara kumi za kaunti na majukumu ya kila moja.  Kila idara inaorodhesha huduma zake, ofisi zinapotolewa, na wa kuulizwa jambo linapoenda vibaya.  '),
('f3a121399cb34f4d849532713eec687b','Accessibility statement Accessibility statement\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     This site is built to be usable by everyone, including people who use a screen reader, a keyboard alone, or a magnifier.  If a page gets in your way, tell us on 0800 000 000 and we will fix it and tell you what changed.  '),
('f419bc4f32582095e72050c638a7a4a2','Public participation on the 2027 county budget Forums open in all twelve wards from 4 November. The draft estimates are published with this notice.  The county invites residents to comment on the draft budget estimates for the 2027 financial year. Each ward holds one forum, starting at 10:00 at the ward office.  Written submissions may be left at any ward office or sent to the county clerk until 18 November.  '),
('f6094f9496469f15515d4d4d29d1f233','Tenders Tenders\n             \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     Open tenders of Jambo County, with closing dates and the documents to download.  Bids are received at the county procurement office. Awards are published here once the evaluation is complete.  ');
/*!40000 ALTER TABLE `index_fulltext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_grlist`
--

DROP TABLE IF EXISTS `index_grlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_grlist` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` varchar(32) NOT NULL,
  `phash_x` varchar(32) NOT NULL,
  `hash_gr_list` varchar(32) NOT NULL,
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`hash_gr_list`),
  KEY `phash_grouping` (`phash_x`,`hash_gr_list`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_grlist`
--

LOCK TABLES `index_grlist` WRITE;
/*!40000 ALTER TABLE `index_grlist` DISABLE KEYS */;
INSERT INTO `index_grlist` VALUES
(1,'3d798c3f120fdabe32985de46a5fc2fd','3d798c3f120fdabe32985de46a5fc2fd','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(2,'56ce185f3262c9101626cfd28a4127a4','56ce185f3262c9101626cfd28a4127a4','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(3,'78cabd40e1e1f417b9f83789c2321f4a','78cabd40e1e1f417b9f83789c2321f4a','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(4,'6d2ddd1174e062f12957e8f7a89bafb1','6d2ddd1174e062f12957e8f7a89bafb1','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(5,'53a65a8e3f722edf05d31693dce3236f','53a65a8e3f722edf05d31693dce3236f','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(6,'5192c25f9e1778c3c79dff990fa03437','5192c25f9e1778c3c79dff990fa03437','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(7,'97b8cd0fe54b6d09a38ff14702afb4bc','97b8cd0fe54b6d09a38ff14702afb4bc','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(8,'9bd8393860e6e9cf4c907a0919ca687d','9bd8393860e6e9cf4c907a0919ca687d','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(9,'f6094f9496469f15515d4d4d29d1f233','f6094f9496469f15515d4d4d29d1f233','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(10,'4f6e807051e61027dadc02f9f2906020','4f6e807051e61027dadc02f9f2906020','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(11,'67d787a12066aa33f927bc0bed2dc3fd','67d787a12066aa33f927bc0bed2dc3fd','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(12,'f3a121399cb34f4d849532713eec687b','f3a121399cb34f4d849532713eec687b','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(13,'85c2621b0fce09ac51613f18ce135f4b','85c2621b0fce09ac51613f18ce135f4b','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(14,'d031f71935b894cc76f91a35ad5e466a','d031f71935b894cc76f91a35ad5e466a','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(15,'ec2f2d3462894284b37105ddedffd64c','ec2f2d3462894284b37105ddedffd64c','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(16,'480f7b1104526ca784330338f9bc8f68','480f7b1104526ca784330338f9bc8f68','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(17,'b676e408624805da6b4c35566cad496c','b676e408624805da6b4c35566cad496c','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(18,'d2b728c29c935917865a91198146007e','d2b728c29c935917865a91198146007e','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(19,'1274e6ec4a76f4918a72b6b88575b2f1','1274e6ec4a76f4918a72b6b88575b2f1','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(20,'7fb9c8e8b02c27d3a5c5c229300fb27f','7fb9c8e8b02c27d3a5c5c229300fb27f','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(21,'ca9fd685b16e5922e940b713a6166e7f','ca9fd685b16e5922e940b713a6166e7f','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(22,'d3c7afff432dc4a8674da3b6cfcc9624','d3c7afff432dc4a8674da3b6cfcc9624','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(23,'e45333e70f61f6118c6492c55e8605b9','e45333e70f61f6118c6492c55e8605b9','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(24,'bec4701003457746b3e8eb7b62a181cf','bec4701003457746b3e8eb7b62a181cf','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(25,'78d410ed8d322872c93e023c151a02b9','78d410ed8d322872c93e023c151a02b9','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(26,'b4b473e088c0a9f40a7eb9053a621871','b4b473e088c0a9f40a7eb9053a621871','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(27,'2398fdd24f0b64e9f9f3e15fc0bb6109','2398fdd24f0b64e9f9f3e15fc0bb6109','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(28,'f419bc4f32582095e72050c638a7a4a2','f419bc4f32582095e72050c638a7a4a2','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(29,'55a8841b368fd8e1405e80ae0cf43f69','55a8841b368fd8e1405e80ae0cf43f69','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(30,'0e6531c5d0ae0b0a3fa3622a23f7818e','0e6531c5d0ae0b0a3fa3622a23f7818e','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(31,'56e8dbba6bd49275b2763e0aa24d2418','56e8dbba6bd49275b2763e0aa24d2418','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(32,'bf10d741ea1a3f66bd8f054520f99b4f','bf10d741ea1a3f66bd8f054520f99b4f','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(33,'4fe65afd46a96ebb6113e4082c07329f','4fe65afd46a96ebb6113e4082c07329f','cdc0a8f9fe7f5e206d167723a90af880','0,-1'),
(34,'132c3127164c3476556136c8b825863f','132c3127164c3476556136c8b825863f','cdc0a8f9fe7f5e206d167723a90af880','0,-1');
/*!40000 ALTER TABLE `index_grlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_phash`
--

DROP TABLE IF EXISTS `index_phash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_phash` (
  `phash` varchar(32) NOT NULL,
  `phash_grouping` varchar(32) NOT NULL,
  `static_page_arguments` blob DEFAULT NULL,
  `data_filename` varchar(1024) NOT NULL DEFAULT '',
  `data_page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_type` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_mp` varchar(255) NOT NULL DEFAULT '',
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  `item_type` varchar(5) NOT NULL DEFAULT '',
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_description` varchar(255) NOT NULL DEFAULT '',
  `item_mtime` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `item_size` int(11) NOT NULL DEFAULT 0,
  `contentHash` varchar(32) NOT NULL,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `parsetime` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `item_crdate` int(11) NOT NULL DEFAULT 0,
  `externalUrl` smallint(6) NOT NULL DEFAULT 0,
  `recordUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexSetId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`),
  KEY `phash_grouping` (`phash_grouping`),
  KEY `freeIndexUid` (`freeIndexUid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_phash`
--

LOCK TABLES `index_phash` WRITE;
/*!40000 ALTER TABLE `index_phash` DISABLE KEYS */;
INSERT INTO `index_phash` VALUES
('0e6531c5d0ae0b0a3fa3622a23f7818e','77fb6b5dcba686122a63c08710e85649','[]','',37,0,'','0,-1','0','Ward offices closed on 20 October','All ward offices are closed for Mashujaa Day. Online services remain available. All twelve ward offices and the county headquarters are closed on Tuesday 20 October for Mashujaa Day, and open again at',1793191857,1793192057,10799,'0f560a19103c34615fbf03848a65076e',1793192057,7,0,1793191768,0,0,0,0),
('1274e6ec4a76f4918a72b6b88575b2f1','94704902feda7f471b0e657c9a9e40df','[]','',20,0,'','0,-1','0','Taarifa ya ufikivu','Taarifa ya ufikivu Tovuti hii imetengenezwa itumike na kila mtu, wakiwemo wanaotumia kisomaji skrini, kibodi pekee, au kikuzaji. Ukurasa ukikuzuia, tuambie kwa 0800 000 000 nasi tutarekebisha na kukue',1793174043,1793174192,8136,'f3f25d39e83861eef6d7825e42183def',1793174192,7,1,1793174043,0,0,0,0),
('132c3127164c3476556136c8b825863f','3e9aa576a0fe6c432c44567aa799a783','[]','',38,0,'','0,-1','0','Siku mpya ya kuchukua taka kwa wodi ya Riverside','Kuanzia tarehe 1 Novemba, taka za nyumbani katika wodi ya Riverside zitachukuliwa siku ya Jumanne badala ya Alhamisi. Mabadiliko haya yanaruhusu lori moja kuhudumia wodi za Riverside na Market katika ',1793191857,1793192058,11129,'fa30d1502c746831edab712e43d02709',1793192058,7,1,1793191807,0,0,0,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','0363943d2ad2f84e7e541a725a3ec55e','[]','',34,0,'','0,-1','0','Notices','22 October 2026 Public participation on the 2027 county budget Forums open in all twelve wards from 4 November. The draft estimates are published with this notice. 15 October 2026 Tender: supply of wa',1793191752,1793192057,10291,'fcae0e3b0764bedce5fa0a76f2eb0b40',1793192057,25,0,1793191752,0,0,0,0),
('3d798c3f120fdabe32985de46a5fc2fd','dc91fa3918f3fab9a43a16f82bb27086','[]','',1,0,'','0,-1','0','Home','County services, online and in one place Apply for a permit, pay a levy, book an appointment at a ward office, or read what the council decided at its last sitting. Find a service Book an appointment ',1793163092,1793166330,16374,'8954d1456e6d0e2ac3f3b60182ed5cf3',1793166330,371,0,1793117478,0,0,0,0),
('480f7b1104526ca784330338f9bc8f68','64a5ebcd6e517773c3ed56ddb71b840e','[]','',14,0,'','0,-1','0','Zabuni','Zabuni Zabuni zilizo wazi za Kaunti ya Jambo, pamoja na tarehe za kufunga na nyaraka za kupakua. Zabuni hupokelewa katika ofisi ya ununuzi ya kaunti. Washindi huchapishwa hapa tathmini ikikamilika.',1793174043,1793174192,8487,'d2ea76926b1d442ed64b9bd4ca85ee51',1793174192,9,1,1793174043,0,0,0,0),
('4f6e807051e61027dadc02f9f2906020','96b2aa8aa943db4a5d8f7349fa047831','[]','',16,0,'','0,-1','0','County assembly','County assembly The assembly makes the laws of the county and approves its budget. Sittings are open to the public. Order papers, bills and the record of each sitting are published after it.',1793174043,1793174191,8473,'22673528968afc1902a38d9dcac6c182',1793174191,6,0,1793174043,0,0,0,0),
('4fe65afd46a96ebb6113e4082c07329f','7f3980d4f04f98a6aac2dd28b0eb7ffe','[]','',35,0,'','0,-1','0','Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027','Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili. Kaunti inawakaribisha wakazi kutoa maoni kuhusu makadirio ya awali ya',1793191857,1793192058,11241,'5b00f962683c02c34e9800350ff7322a',1793192058,14,1,1793191807,0,0,0,0),
('5192c25f9e1778c3c79dff990fa03437','3450a071934930d65d23dd6e16db52b6','[]','',2,0,'','0,-1','0','Huduma','Huduma Kila kitu ambacho kaunti hufanya kwa wakazi na wafanyabiashara, kimepangwa kulingana na unachohitaji kufanya. Huduma nyingi zinaweza kuanzishwa mtandaoni. Pale inapohitajika kufika ana kwa ana,',1793167469,1793167479,5972,'1f7a0589fe7b40e8a1e8b9bdd4dc1f3a',1793167479,15,1,1793167382,0,0,0,0),
('53a65a8e3f722edf05d31693dce3236f','56a9ebb9de50230b8837a51d07b576ea','[]','',1,0,'','0,-1','0','Mwanzo','',1793167382,1793167479,4921,'90d97cdc7fc33e47049224fb47a21def',1793167479,16,1,1793167382,0,0,0,0),
('55a8841b368fd8e1405e80ae0cf43f69','1919a71ae655e5df20e85bd961d97fe6','[]','',36,0,'','0,-1','0','Tender: supply of water meters','Bids close at 11:00 on 6 November at the county procurement office. The county invites sealed bids for the supply and delivery of 2,000 domestic water meters. Tender documents are available at the pro',1793191857,1793192057,10811,'6c42bc675fec8369424a0b7a5b64535d',1793192057,11,0,1793191768,0,0,0,0),
('56ce185f3262c9101626cfd28a4127a4','cadd9455631c2005b0784198b1c7f739','[]','',2,0,'','0,-1','0','Services','Services Everything the county does for residents and businesses, grouped by what you need to get done. Most services can be started online. Where a visit is needed, the page for that service says whi',1793119088,1793166331,5980,'78b65734a12c5dc30182eacd2505dbc0',1793166331,31,0,1793118734,0,0,0,0),
('56e8dbba6bd49275b2763e0aa24d2418','7a934ffb1858618ac976c858e0a9ef3f','[]','',38,0,'','0,-1','0','New collection day for Riverside ward','From 1 November, household waste in Riverside ward is collected on Tuesdays instead of Thursdays. The change lets one lorry serve Riverside and Market wards on the same round. Please leave bins at the',1793191857,1793192058,10768,'667963dd4eeb96b9864153ab5212c410',1793192058,11,0,1793191768,0,0,0,0),
('67d787a12066aa33f927bc0bed2dc3fd','c75154cb583078c8920956ef93fc23c3','[]','',18,0,'','0,-1','0','Contact us','Contact us How to reach Jambo County Council. County Headquarters, Uhuru Road, Jambo Town. Monday to Friday, 08:00–17:00. The contact centre answers on 0800 000 000.',1793174043,1793174191,7920,'18e068fa033cf61ba6e3b42cec6c34fb',1793174191,5,0,1793174043,0,0,0,0),
('6d2ddd1174e062f12957e8f7a89bafb1','42a44c80384793445371a8816cb755cc','[]','',4,0,'','0,-1','0','Land rates','Land rates Land rates are charged on every rateable parcel in the county and fall due on 1 January each year. Check the balance on a parcel with its plot number, then pay online, at a ward office, or ',1793119088,1793166331,6100,'7ab4aed3087b1b37f157d2dc98a36f63',1793166331,22,0,1793118734,0,0,0,0),
('78cabd40e1e1f417b9f83789c2321f4a','17e3c529abc7b537c5fcf59f12035044','[]','',3,0,'','0,-1','0','Business permits','Business permits Every business operating in Jambo County needs a single business permit for the current year. Apply online, at a ward office, or at the county headquarters. Who needs a permit A permi',1793119088,1793166331,11341,'77094e5e0ea7e9ba49e9b639bee886d9',1793166331,70,0,1793118734,0,0,0,0),
('78d410ed8d322872c93e023c151a02b9','5ceab85c5cb85b1bb010430da08a0bf6','[]','',29,0,'','0,-1','0','Waste collection','Waste collection Household waste is collected once a week, on the day set for your ward. If your waste was not collected on the day it should have been, tell us below. The waste team receives every re',1793178400,1793178402,9902,'5e908b09ed2fa7390e3f640122a7b9f6',1793178402,19,0,1793178400,0,0,0,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','cf06396d48262798028f7493e78876a8','[]','',22,0,'','0,-1','0','Faragha','Faragha Kaunti hufanya nini na taarifa unazotoa. Taarifa zinazotolewa na maombi hutumika kuamua maombi hayo na huhifadhiwa kwa muda unaotakiwa kisheria.',1793174043,1793174192,7974,'4d691d4fccd75f3a0e40a6e571cfad3d',1793174192,6,1,1793174043,0,0,0,0),
('85c2621b0fce09ac51613f18ce135f4b','9a7bc725af3ac5065f0bbc97e5345d73','[]','',22,0,'','0,-1','0','Privacy','Privacy What the county does with the data you give it. Data submitted with an application is used to decide that application and is kept for as long as the law requires.',1793174043,1793174192,7903,'4df010b0d5510e808156aa7623a99ae3',1793174192,7,0,1793174043,0,0,0,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','71f7510e569d88ac1c6cdeb17e883a6c','[]','',3,0,'','0,-1','0','Vibali vya biashara','Vibali vya biashara Kila biashara inayofanya kazi katika Kaunti ya Jambo inahitaji kibali kimoja cha biashara kwa mwaka husika. Omba mtandaoni, katika ofisi ya wodi, au katika makao makuu ya kaunti. N',1793167469,1793167480,10711,'cd8d2fad655b1a46d68dec22df862c49',1793167480,31,1,1793167382,0,0,0,0),
('9bd8393860e6e9cf4c907a0919ca687d','f5bad68bc9b081e512151ece334fae4f','[]','',12,0,'','0,-1','0','Departments','Departments The ten departments of the county and what each of them is responsible for. Every department lists the services it runs, the offices where they are delivered, and who to ask when something',1793174043,1793174191,8439,'e61e2ce6fc9db915270f271dff9b2922',1793174191,21,0,1793174043,0,0,0,0),
('b4b473e088c0a9f40a7eb9053a621871','ec88f374837cd35507439c9c1a24b30d','[]','',29,0,'','0,-1','0','Ukusanyaji wa taka','Ukusanyaji wa taka Taka za nyumbani huchukuliwa mara moja kwa wiki, siku iliyopangwa kwa wodi yako. Ikiwa taka zako hazikuchukuliwa siku iliyopangwa, tuambie hapa chini. Timu ya taka hupokea kila ripo',1793178400,1793178403,9939,'4b3b9d7772df76278518317fe1038619',1793178403,9,1,1793178400,0,0,0,0),
('b676e408624805da6b4c35566cad496c','0fa569843e343d6e65291fcbf3d080dc','[]','',16,0,'','0,-1','0','Bunge la kaunti','Bunge la kaunti Bunge hutunga sheria za kaunti na kuidhinisha bajeti yake. Vikao viko wazi kwa umma. Ratiba, miswada na kumbukumbu za kila kikao huchapishwa baada yake.',1793174043,1793174192,8554,'8dacfc79d893513012cae52ff81b1d44',1793174192,6,1,1793174043,0,0,0,0),
('bec4701003457746b3e8eb7b62a181cf','6cf9987bd24a606b0e44a42f61b857f5','[]','',3,0,'','0,-1','0','Business permits','Business permits This page is in Easy Read. It tells you about business permits. What is a business permit? A permit is a paper from the county. It says you can run your business. Who needs a permit? ',1793177518,1793177522,16494,'bf959b7b3be714bcf4f6bfa467b39aed',1793177522,31,2,1793177518,0,0,0,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d24d3e57d74528d608f1dc43d74d7a8d','[]','',34,0,'','0,-1','0','Matangazo','22 Oktoba 2026 Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027 Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili.',1793191807,1793192058,10591,'340e9d1f128d4f4238e2e9458da3d4a8',1793192058,23,1,1793191807,0,0,0,0),
('ca9fd685b16e5922e940b713a6166e7f','3e5ea7bf1c69e388061c9f7f836b3524','[]','',24,0,'','0,-1','0','Masharti ya matumizi','Masharti ya matumizi Masharti ambayo tovuti hii hutolewa kwayo. Taarifa zilizopo hapa huchapishwa kwa nia njema. Zikitofautiana na uamuzi wa halmashauri, uamuzi hushinda.',1793174043,1793174192,8051,'9d04034c31c3ce2da19497e9f585f1da',1793174192,6,1,1793174043,0,0,0,0),
('d031f71935b894cc76f91a35ad5e466a','6da2b73b111e1de354ab684a0e989e21','[]','',24,0,'','0,-1','0','Terms of use','Terms of use The terms on which this site is provided. The information here is published in good faith. Where it differs from a decision of the council, the decision stands.',1793174043,1793174192,7934,'e104439410a258c1b822ed1e416a556a',1793174192,5,0,1793174043,0,0,0,0),
('d2b728c29c935917865a91198146007e','6c372bbfbd8d95b4696535fcf5c6d81f','[]','',18,0,'','0,-1','0','Wasiliana nasi','Wasiliana nasi Jinsi ya kuwasiliana na Kaunti ya Jambo. Makao Makuu ya Kaunti, Barabara ya Uhuru, Mji wa Jambo. Jumatatu hadi Ijumaa, 08:00–17:00. Kituo cha mawasiliano hupatikana kwa 0800 000 000.',1793174043,1793174192,8056,'fb21cc1b13945e46b20f95f6c5daf9bf',1793174192,9,1,1793174043,0,0,0,0),
('d3c7afff432dc4a8674da3b6cfcc9624','27c2dc8bdc1d2fb5634964d0a9652012','[]','',1,0,'','0,-1','0','Jambo County Council','Jambo County Council These pages are in Easy Read. Easy Read is easier to read. It has short sentences and pictures.',1793177518,1793177522,6579,'472d0d8453135e8033be50d4575fa7b7',1793177522,22,2,1793177518,0,0,0,0),
('e45333e70f61f6118c6492c55e8605b9','2f5d07715bcf73238c4b9c5bada2a74d','[]','',2,0,'','0,-1','0','Services','Services These are things the county does for you. Right now one page is in Easy Read. It is about business permits.',1793177518,1793177522,7084,'fe0119783526e7a64f53bc62148a8b2c',1793177522,11,2,1793177518,0,0,0,0),
('ec2f2d3462894284b37105ddedffd64c','9e4335ab1b8d2baafeb077e2c056d3e6','[]','',12,0,'','0,-1','0','Idara','Idara Idara kumi za kaunti na majukumu ya kila moja. Kila idara inaorodhesha huduma zake, ofisi zinapotolewa, na wa kuulizwa jambo linapoenda vibaya.',1793174043,1793174192,8443,'16b7eb53cc7b5bad70ff3061905fd258',1793174192,5,1,1793174043,0,0,0,0),
('f3a121399cb34f4d849532713eec687b','8b207ee6ce9869f89c55279b86c7a4ce','[]','',20,0,'','0,-1','0','Accessibility statement','Accessibility statement This site is built to be usable by everyone, including people who use a screen reader, a keyboard alone, or a magnifier. If a page gets in your way, tell us on 0800 000 000 and',1793174043,1793174192,8073,'d47815f7f59c59b4429cda4815f78b21',1793174192,10,0,1793174043,0,0,0,0),
('f419bc4f32582095e72050c638a7a4a2','d268c7681c2909bb61895411716f970f','[]','',35,0,'','0,-1','0','Public participation on the 2027 county budget','Forums open in all twelve wards from 4 November. The draft estimates are published with this notice. The county invites residents to comment on the draft budget estimates for the 2027 financial year. ',1793191857,1793192057,10900,'d31eec6a3fed44f47130054fb4f50721',1793192057,8,0,1793191768,0,0,0,0),
('f6094f9496469f15515d4d4d29d1f233','811df9a9574067c748074c9a437249e9','[]','',14,0,'','0,-1','0','Tenders','Tenders Open tenders of Jambo County, with closing dates and the documents to download. Bids are received at the county procurement office. Awards are published here once the evaluation is complete.',1793174043,1793174191,8391,'17c50469fd8a508aaef8d01b9d80e86f',1793174191,6,0,1793174043,0,0,0,0);
/*!40000 ALTER TABLE `index_phash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_rel`
--

DROP TABLE IF EXISTS `index_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_rel` (
  `phash` varchar(32) NOT NULL,
  `wid` varchar(32) NOT NULL,
  `count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `first` int(10) unsigned NOT NULL DEFAULT 0,
  `freq` smallint(5) unsigned NOT NULL DEFAULT 0,
  `flags` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`,`wid`),
  KEY `wid` (`wid`,`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_rel`
--

LOCK TABLES `index_rel` WRITE;
/*!40000 ALTER TABLE `index_rel` DISABLE KEYS */;
INSERT INTO `index_rel` VALUES
('0e6531c5d0ae0b0a3fa3622a23f7818e','10cd395cf71c18328c863c08e78f3fd0',1,9,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','15f6f8dc036519d7fe15b39338f6e5db',1,13,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','1a31a6f65cc993ff6bd9a5b85f0520b0',1,23,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','23a58bf9274bedb19375e527a0744fa9',1,46,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','2417b53255206bdce189add39d85fca1',1,42,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','2b80472febb0c52ab4551deca95dcd7b',4,0,21694,128),
('0e6531c5d0ae0b0a3fa3622a23f7818e','2c61ebff5a7f675451467527df66788d',1,43,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','31aa6d34f11de5c586cf042767e8d74e',1,52,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','349e686330723975502e9ef4f939a5ac',3,0,16271,128),
('0e6531c5d0ae0b0a3fa3622a23f7818e','3c59dc048e8850243be8079a5c74d079',1,36,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','3c8925c7fb2d563070c4c7aa96954e92',1,19,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','4015e9ce43edfb0668ddaa973ebc7e87',3,3,16271,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','4893680cd9e9b799a7b8de8e14ea804d',2,6,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','49ddafa93b4052e15e041a43d4343fda',3,0,16271,128),
('0e6531c5d0ae0b0a3fa3622a23f7818e','5188aa9e6815c731a69a0c302c772797',1,33,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','628b7db04235f228d40adc671413a8c8',2,7,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','639849f6b368019778991b32434354fc',1,31,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','669e30e88461ad462e642c08a25ffb05',1,45,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','6cd8b57ad8ec40b32215dcb1c8c76af2',1,40,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','7cef8a734855777c2a9d0caf42666e69',1,30,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','7d0db380a5b95a8ba1da0bca241abda1',1,32,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','7f46165474d11ee5836777d85df2cdab',2,8,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','87cf962b35146c21d0dd7f84594662b6',1,39,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','8fc42c6ddf9966db3b09e84365034357',2,17,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','901889f4f34f8ca18ac2f53d1fed346e',1,48,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','910955a907e739b81ec8855763108a29',1,44,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','98f13708210194c475687be6106a3b84',2,0,10847,128),
('0e6531c5d0ae0b0a3fa3622a23f7818e','a181a603769c1f98ad927e7367c7aa51',2,0,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','a6daad2f29decd1e94a592164d34183a',1,10,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','aad0cd42d3c8a3b36a2be6a641d0cd53',1,18,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','aae446086f8e81194ed115b566bf2e3d',1,35,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','be5d5d37542d75f93a87094459f76678',3,16,16271,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','c2f28daa81da003f46d3865ae0362d5c',1,38,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','d55669822f1a8cf72ec1911e462a54eb',2,5,10847,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','e4894ca167b08880bfc35862f18575eb',1,11,5423,0),
('0e6531c5d0ae0b0a3fa3622a23f7818e','e60a95f3f443e37f5a47210d9b340a05',3,0,16271,128),
('0e6531c5d0ae0b0a3fa3622a23f7818e','ed2b5c0139cec8ad2873829dc1117d50',3,0,16271,128),
('1274e6ec4a76f4918a72b6b88575b2f1','2f517001fcdc575005781fd245125e75',1,3,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','32af23ab89095528e5cac67ce5c2a497',1,18,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','42ddcea8b7d1fd6b522b633c9cac018e',2,0,19393,128),
('1274e6ec4a76f4918a72b6b88575b2f1','58258870a61e35f41e3c0aa1d7d6e29e',1,10,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','661a504c6c4cd163fe4d67836577b926',1,9,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','6ec66e124fb93c190e9207b0b82f542a',2,7,19393,0),
('1274e6ec4a76f4918a72b6b88575b2f1','7978648641239a911c0f5a639f530836',1,6,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','80570bebec5742bf89b3fbf9642cec02',1,8,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','819f7414a0023bc05eab45a7cc1a822c',2,0,19393,128),
('1274e6ec4a76f4918a72b6b88575b2f1','8282252205923a5847a803d007ed0c0e',1,20,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','89c26022b24ee6a919f70e5cb7249dad',1,13,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','8af54a059c168446a6ea9843ff32a05d',1,28,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','8bcc25c96aa5a71f7a76309077753e67',1,16,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','8f72382d96d9e4889cc14e35d423bf44',1,21,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','a9c97af092d8959d34afd99722d2b0dc',1,14,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','aff5412b9c6214a7ba9321f9f02a262d',1,26,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','bb9f601ba081ab8d336a14a697048cb0',1,25,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','bd5bb0ca70a22a3725257f45e0e9f549',1,22,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','c6f057b86584942e415435ffb1fa93d4',2,23,19393,0),
('1274e6ec4a76f4918a72b6b88575b2f1','ca0222f0a8e51643bad05c3195c37dc6',1,19,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','d5ee9f95a62d822c8296af787f94e3bf',1,5,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','d74600e380dbf727f67113fd71669d88',2,0,19393,128),
('1274e6ec4a76f4918a72b6b88575b2f1','d85e38447c7ce595b30df48be3e60329',1,15,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','dc42cc70ee86f1d2760ddcef21987882',1,11,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','de2843227b7e57d11cff826009db0ef4',1,29,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','de5b97db74bc753f659c63891c3e1e48',1,17,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','f057f5ccb87a310534b9dda3a69a72c4',1,4,9696,0),
('1274e6ec4a76f4918a72b6b88575b2f1','f9f95e1eedab26dc8502590bcea74a76',1,12,9696,0),
('132c3127164c3476556136c8b825863f','01fc8dbe01da25daf8fd5da8f519c6a1',1,1,5245,0),
('132c3127164c3476556136c8b825863f','05e2c42764429721c53046a2b83ffea4',1,52,5245,0),
('132c3127164c3476556136c8b825863f','0673e173f6d896cb2f1310a1499a1b6a',1,34,5245,0),
('132c3127164c3476556136c8b825863f','0b3cfa5de16ad41eedf27d40fd0149d0',1,50,5245,0),
('132c3127164c3476556136c8b825863f','14354d69d78781de8295a50fd7db897f',1,33,5245,0),
('132c3127164c3476556136c8b825863f','306826899d77aaa50c928e83657d2687',1,23,5245,0),
('132c3127164c3476556136c8b825863f','32af23ab89095528e5cac67ce5c2a497',1,48,5245,0),
('132c3127164c3476556136c8b825863f','4474385cf4b7c5b4a97b13026eeb0887',1,32,5245,0),
('132c3127164c3476556136c8b825863f','47a708336d417719c1a1e942ff7da27d',1,15,5245,0),
('132c3127164c3476556136c8b825863f','5592932dd92ccce1ceef6f3c5fbdede7',1,14,5245,0),
('132c3127164c3476556136c8b825863f','5cfc1f542032073a69e82c2c7c6a8386',1,42,5245,0),
('132c3127164c3476556136c8b825863f','5f38f7089756746b5389e8e7d8645c61',1,0,5245,128),
('132c3127164c3476556136c8b825863f','60190cb2b5a1d64c6c22fdda4d9e29e0',1,30,5245,0),
('132c3127164c3476556136c8b825863f','68944d7c9fbc300426a92fca45b6e014',1,43,5245,0),
('132c3127164c3476556136c8b825863f','6cb2b035fec9a521c8a8c79ee20e9ac1',1,6,5245,0),
('132c3127164c3476556136c8b825863f','6ec66e124fb93c190e9207b0b82f542a',1,27,5245,0),
('132c3127164c3476556136c8b825863f','71ad8fa7968ec98dcaff0824894d24b8',1,18,5245,0),
('132c3127164c3476556136c8b825863f','7702bad848a0039a0b92fbe490369d52',1,17,5245,0),
('132c3127164c3476556136c8b825863f','7820cd42355d0b56bb26edd33c628c13',1,0,5245,0),
('132c3127164c3476556136c8b825863f','7cc82ba62ed3892d8acbe1a73a0cba49',1,45,5245,0),
('132c3127164c3476556136c8b825863f','7e09f4be5df1e5ad108d0e10bcb365e7',1,19,5245,0),
('132c3127164c3476556136c8b825863f','7eb0ae4ada5be19f438ce67bef5929e6',1,38,5245,0),
('132c3127164c3476556136c8b825863f','8a1a17e049499fb3b978d1e11b4f7693',1,40,5245,0),
('132c3127164c3476556136c8b825863f','8f72382d96d9e4889cc14e35d423bf44',1,0,5245,128),
('132c3127164c3476556136c8b825863f','959848ca10cc8a60da818ac11523dc63',2,5,10491,0),
('132c3127164c3476556136c8b825863f','984eaf792802b84bce30376ec5e56247',3,22,15737,0),
('132c3127164c3476556136c8b825863f','af85b9ed98481408d4101739fed539d6',3,7,15737,0),
('132c3127164c3476556136c8b825863f','b01c779298700e97cfd00b5cec9f2b28',1,20,5245,0),
('132c3127164c3476556136c8b825863f','b2ae2cd3f4143bf192efb35bb9e7d369',1,3,5245,0),
('132c3127164c3476556136c8b825863f','b4714fa709d5fd6b39b5719b3b157622',1,35,5245,0),
('132c3127164c3476556136c8b825863f','c1c16452b04650ea34d1463da2739f3b',1,28,5245,0),
('132c3127164c3476556136c8b825863f','c1f7ed800b498c3e7d5ee7f3cbdedc63',3,0,15737,128),
('132c3127164c3476556136c8b825863f','c4ca4238a0b923820dcc509a6f75849b',1,2,5245,0),
('132c3127164c3476556136c8b825863f','c68c559d956d4ca20f435ed74a6e71e6',2,49,10491,0),
('132c3127164c3476556136c8b825863f','c8b6cb5a4739ab2974c13bc3b7887758',1,0,5245,128),
('132c3127164c3476556136c8b825863f','d4fbae6323ac161c03127c31690d81f4',3,0,15737,128),
('132c3127164c3476556136c8b825863f','d6327112b02e4af370dae5ceac67f6e5',1,11,5245,0),
('132c3127164c3476556136c8b825863f','d74600e380dbf727f67113fd71669d88',6,0,31475,128),
('132c3127164c3476556136c8b825863f','e0ba0c0363c5c47bb4c42b39afcbe0ae',3,0,15737,128),
('132c3127164c3476556136c8b825863f','e7841e2173994144a0203476d77a72f4',1,46,5245,0),
('132c3127164c3476556136c8b825863f','ea46e7e94ccee171a97fe14853d5861e',1,21,5245,0),
('132c3127164c3476556136c8b825863f','f318725c1410c1d610689d723cdd855c',1,37,5245,0),
('132c3127164c3476556136c8b825863f','fc9187af4b3b23c0e44e797fe4ba3ee9',2,0,10491,128),
('2398fdd24f0b64e9f9f3e15fc0bb6109','03c98ff9edc4b0e2fa19dd478e1613ee',1,35,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','07d9e3aefc4093a49121c91ef65e708b',1,34,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','0a538a0ca54a9f51fc1334040fb89d64',1,30,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','10cd395cf71c18328c863c08e78f3fd0',1,65,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','110cea74cf52e41ead691dccdf75f27b',1,69,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','13b5bfe96f3e2fe411c9f66f4a582adf',2,12,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','15f6f8dc036519d7fe15b39338f6e5db',1,14,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','1679091c5a880faf6fb5e6087eb1b2dc',1,40,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','22af645d1859cb5ca6da0c484f1f37ea',1,71,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','22d97324e887bceb83f5a3a68ef31390',1,88,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','23a58bf9274bedb19375e527a0744fa9',1,24,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','2af45960db0a678ed7f610f117b1d46e',1,0,3440,128),
('2398fdd24f0b64e9f9f3e15fc0bb6109','2b80472febb0c52ab4551deca95dcd7b',2,51,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','2f212049ce79d2b949fd242043004288',1,9,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','33e75ff09dd601bbe69f351039152189',1,68,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','349e686330723975502e9ef4f939a5ac',2,52,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','4015e9ce43edfb0668ddaa973ebc7e87',2,22,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','45c48cce2e2d7fbdea1afc51c7c6ad26',1,47,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','4893680cd9e9b799a7b8de8e14ea804d',1,62,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','49ddafa93b4052e15e041a43d4343fda',4,50,13763,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','4c9184f37cff01bcdc32dc486ec36961',1,3,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','4d04cedd6d05b1f16a4404ff5a1fa4af',3,18,10322,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','628b7db04235f228d40adc671413a8c8',2,63,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','68daf8bdc8755fe8f4859024b3054fb8',1,10,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','716f6b30598ba30945d84485e61c1027',1,36,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','7cef8a734855777c2a9d0caf42666e69',1,11,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','7d0db380a5b95a8ba1da0bca241abda1',2,37,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','7f46165474d11ee5836777d85df2cdab',1,64,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','8bf8854bebe108183caeb845c7676ae4',2,32,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','8dee49165153fc68ffacb5f7f7bf9a3a',1,89,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,23,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','8fc42c6ddf9966db3b09e84365034357',3,6,10322,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','90fafe3a7d04ee1c17239fa2d768f8fc',1,15,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','93aa88d53279ccb3e40713d4396e198f',1,45,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','9460370bb0ca1c98a779b1bcc6861c2c',1,33,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','95723b5e620e47cf613462b9f293282a',1,86,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','98f13708210194c475687be6106a3b84',1,54,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,27,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','9e925e9341b490bfd3b4c4ca3b0c1ef2',1,25,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','9f62b8625f914a002496335037e9ad97',1,7,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','a181a603769c1f98ad927e7367c7aa51',2,13,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','a2a551a6458a8de22446cc76d639a9e9',1,85,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','a6daad2f29decd1e94a592164d34183a',1,66,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','a87ff679a2f3e71d9181a67b7542122c',1,17,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','aad0cd42d3c8a3b36a2be6a641d0cd53',2,8,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','aaf9a7ade8ad853549f9ce5d53e8d645',1,31,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','b6d767d2f8ed5d21a44b0e5886680cb9',1,0,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','bbf3c5a13c25133cc08db092814e9167',1,91,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','c1f7ed800b498c3e7d5ee7f3cbdedc63',2,75,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','c4ca4238a0b923820dcc509a6f75849b',1,78,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','c92a10324374fac681719d63979d00fe',4,2,13763,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','cb15e32f389b7af9b285a63ca1044651',1,81,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','cb73f2f1a23779bd445d8199ad3c522f',1,38,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','d55669822f1a8cf72ec1911e462a54eb',2,61,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','d72749910e71e75279b310239e18f36f',1,21,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','d98a07f84921b24ee30f86fd8cd85c3c',2,16,6881,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','db6d9b451b818ccc9a449383f2f0c450',1,72,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','e4894ca167b08880bfc35862f18575eb',1,67,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','e60a95f3f443e37f5a47210d9b340a05',4,1,13763,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','e72f4545eb68c96c754f91fc01573517',1,46,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','ed2b5c0139cec8ad2873829dc1117d50',4,5,13763,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','efd2af60c8501931cb9c736b5ad74f65',1,26,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','f2dd6c078b512971abdd8ed871bafb6f',1,80,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','f91b2829bf8603e358094e1dedb6f947',1,20,3440,0),
('2398fdd24f0b64e9f9f3e15fc0bb6109','f9cb12f89c3f82ffaba2483cd3551d82',1,4,3440,0),
('3d798c3f120fdabe32985de46a5fc2fd','01b6e20344b68835c5ed1ddedf20d531',1,124,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','03c7c0ace395d80182db07ae2c30f034',2,101,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','03c98ff9edc4b0e2fa19dd478e1613ee',1,192,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','07d9e3aefc4093a49121c91ef65e708b',1,191,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','0931be4cc434934e64b1894aa2dba1ae',2,10,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','0a538a0ca54a9f51fc1334040fb89d64',1,187,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','0ba4439ee9a46d9d9f14c60f88f45f87',1,89,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','0cc175b9c0f1b6a831c399e269772661',10,9,14159,0),
('3d798c3f120fdabe32985de46a5fc2fd','0d149b90e7394297301c90191ae775f0',1,86,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','0f710bba8d16303a415266af8bb52fcb',1,115,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','106a6c241b8797f52e1e77317b96a201',1,0,1415,128),
('3d798c3f120fdabe32985de46a5fc2fd','10cd395cf71c18328c863c08e78f3fd0',4,1,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','13b5bfe96f3e2fe411c9f66f4a582adf',3,4,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','15f6f8dc036519d7fe15b39338f6e5db',2,53,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','161667482354e5692dd1942931f981fd',1,59,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','1679091c5a880faf6fb5e6087eb1b2dc',1,197,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','18b049cc8d8535787929df716f9f4e68',2,15,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','1b20e9021b3a16b059287caddc7862f6',1,103,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','20820bde05df43a0783e8886c51ace9a',1,127,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','23a58bf9274bedb19375e527a0744fa9',1,181,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','27792947ed5d5da7c0d1f43327ed9dab',1,84,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','29a5417a3ebd1c4bd3108d86a3e5b995',1,39,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','2af45960db0a678ed7f610f117b1d46e',1,154,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','2b80472febb0c52ab4551deca95dcd7b',3,55,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','2f212049ce79d2b949fd242043004288',2,68,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','349e686330723975502e9ef4f939a5ac',2,209,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','362140d5183309f61f9b3c34ec801fd6',1,140,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','3c68cbe461787ba38509df85e731f1a6',1,47,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','3c8925c7fb2d563070c4c7aa96954e92',1,44,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','4015e9ce43edfb0668ddaa973ebc7e87',3,58,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','43b5c9175984c071f30b873fdce0a000',1,99,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','44fdec47036f482b68b748f9d786801b',1,119,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','45c48cce2e2d7fbdea1afc51c7c6ad26',1,204,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','4893680cd9e9b799a7b8de8e14ea804d',1,219,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','49ddafa93b4052e15e041a43d4343fda',5,19,7079,0),
('3d798c3f120fdabe32985de46a5fc2fd','4a2028eceac5e1f4d252ea13c71ecec6',2,23,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','4c9184f37cff01bcdc32dc486ec36961',4,62,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','4d04cedd6d05b1f16a4404ff5a1fa4af',2,175,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','4da463dcb391d40ec0352edd2e42b2d2',2,7,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','52a1c95fd889c4a3b00f33472a845157',1,25,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','555bf8344ca0caf09b42f55e185526d8',1,129,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','567904efe9e64d9faf3e41ef402cb568',1,56,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','57f8fcaeb8f4d8fdda329582bdc9b72c',1,104,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','584826e70485130530f7f01a973d5637',1,28,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','5c48b229521c5bbe9ac425745e45b724',1,30,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','5d6eacb879f2a0d08080c3ca04e292c5',1,224,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','5fa3852b08951fcdc4d2e60f89a85bfe',1,69,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','628b7db04235f228d40adc671413a8c8',1,220,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','6639c3233dfa712e4e2aa1bd48315bcc',1,13,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','68daf8bdc8755fe8f4859024b3054fb8',2,153,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','6cd8b57ad8ec40b32215dcb1c8c76af2',2,88,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','6e5f1255c3b7e3008e41ca8974012fc4',1,130,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','716f6b30598ba30945d84485e61c1027',1,193,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','7198cda575b51b68a0dc83f5d66c2aee',1,49,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','73cdddd7730abfc13a55efb9f5685a3b',1,132,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','7877adcb96eb8221c075f0008093bbf7',1,143,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','7cef8a734855777c2a9d0caf42666e69',1,168,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','7d0db380a5b95a8ba1da0bca241abda1',4,17,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','7d5291299ad348d03615a1d1577a7808',1,106,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','7f46165474d11ee5836777d85df2cdab',2,2,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','821f03288846297c2cf43c34766a38f7',2,14,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','84cdc76cabf41bd7c961f6ab12f117d8',1,100,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','87cf962b35146c21d0dd7f84594662b6',1,87,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','8bf8854bebe108183caeb845c7676ae4',4,51,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','8c4291f6956da81515a5c0caec2976d0',1,38,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,180,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','8fc42c6ddf9966db3b09e84365034357',13,24,18407,0),
('3d798c3f120fdabe32985de46a5fc2fd','90fafe3a7d04ee1c17239fa2d768f8fc',1,172,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','93aa88d53279ccb3e40713d4396e198f',1,202,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','9460370bb0ca1c98a779b1bcc6861c2c',1,190,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','98bd1c45684cf587ac2347a92dd7bb51',1,29,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','98f13708210194c475687be6106a3b84',1,211,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','9acb44549b41563697bb490144ec6258',1,112,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,184,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','9e925e9341b490bfd3b4c4ca3b0c1ef2',1,182,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','9f62b8625f914a002496335037e9ad97',1,164,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a181a603769c1f98ad927e7367c7aa51',2,170,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','a2a551a6458a8de22446cc76d639a9e9',1,91,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a4010945e4bd924bc2a890a2effea0e6',1,110,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a546cabc633a9d02345954ffa2c98f44',1,79,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a566b2bebc62611dff4cdaceac1a7bbd',1,146,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a6daad2f29decd1e94a592164d34183a',1,223,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','a87ff679a2f3e71d9181a67b7542122c',1,174,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','aaabf0d39951f3e6c3e8a7911df524c2',1,33,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','aad0cd42d3c8a3b36a2be6a641d0cd53',8,0,11327,0),
('3d798c3f120fdabe32985de46a5fc2fd','aaf9a7ade8ad853549f9ce5d53e8d645',1,188,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','b02a45a596bfb86fe2578bde75ff5444',2,11,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','b1caa385c37f1fec467494c8fde4f49b',2,16,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','b1ccce9f4800002b39d95661dde1185e',1,138,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','b4992073ceb7cead98413d6509b1db49',1,26,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','b5fba9ff24d0045d1377a05a46b32f68',1,57,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','b6d767d2f8ed5d21a44b0e5886680cb9',1,157,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','bbdbe444288550204c968fe7002a97a9',1,64,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','bccd1749fc2f1ef02fdc62280cd40df0',1,156,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','be5d5d37542d75f93a87094459f76678',8,3,11327,0),
('3d798c3f120fdabe32985de46a5fc2fd','c1d8ae6cfb3b6b1cc7d95f4259339a83',1,131,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','c277c9611f0a0f19beb3658245ac305f',1,144,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','c2f28daa81da003f46d3865ae0362d5c',1,72,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','c79bdf421714f5087fc34b7c538b6807',1,105,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','c91497eaedfc46b7398ef737efc428e0',1,46,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','c92a10324374fac681719d63979d00fe',3,159,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','cb15e32f389b7af9b285a63ca1044651',1,116,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','cb73f2f1a23779bd445d8199ad3c522f',1,195,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','d55669822f1a8cf72ec1911e462a54eb',5,8,7079,0),
('3d798c3f120fdabe32985de46a5fc2fd','d72749910e71e75279b310239e18f36f',1,178,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','d8aea03e0a2a7e49a90d3d62728feafe',1,92,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','d98a07f84921b24ee30f86fd8cd85c3c',1,173,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','db6d9b451b818ccc9a449383f2f0c450',3,117,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','db88a0257c220dbfdd2e40f6152d6a8d',1,123,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','dd5c07036f2975ff4bce568b6511d3bc',1,76,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','df3f079de6961496f0460dcfdbf9bca3',1,120,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','e170e3a15923188224c1c2bd1477d451',1,95,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','e60a95f3f443e37f5a47210d9b340a05',4,158,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','e6f06702c43d31c81cb42967420c0b31',1,48,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','e72f4545eb68c96c754f91fc01573517',2,20,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','e81c4e4f2b7b93b481e13a8553c2ae1b',2,21,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','e98d2f001da5678b39482efbdf5770dc',1,125,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','ea170e2cafb1337755c8b3d5ae4437f4',1,31,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','eb399bcaca686f8609137153307eecf1',1,82,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','ebed715e82a0a0f3e950ef6565cdc4a8',1,6,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','ecae13117d6f0584c25a9da6c8f8415e',1,22,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','ed2b5c0139cec8ad2873829dc1117d50',7,45,9911,0),
('3d798c3f120fdabe32985de46a5fc2fd','efd2af60c8501931cb9c736b5ad74f65',1,183,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','f5d7e2532cc9ad16bc2a41222d76f269',2,71,2831,0),
('3d798c3f120fdabe32985de46a5fc2fd','f91b2829bf8603e358094e1dedb6f947',1,177,1415,0),
('3d798c3f120fdabe32985de46a5fc2fd','f97c5d29941bfb1b2fdab0874906ab82',3,5,4247,0),
('3d798c3f120fdabe32985de46a5fc2fd','f9cb12f89c3f82ffaba2483cd3551d82',4,63,5663,0),
('3d798c3f120fdabe32985de46a5fc2fd','fb251350149d040f301da700807ee378',1,108,1415,0),
('480f7b1104526ca784330338f9bc8f68','01fc8dbe01da25daf8fd5da8f519c6a1',1,10,10322,0),
('480f7b1104526ca784330338f9bc8f68','2940c973c72bd82aad4460dbbb3c5a52',1,14,10322,0),
('480f7b1104526ca784330338f9bc8f68','32bc1a1098bc887b73a516fa31e5d04a',1,25,10322,0),
('480f7b1104526ca784330338f9bc8f68','66007490e4f17e80484c9965fe1b4416',1,18,10322,0),
('480f7b1104526ca784330338f9bc8f68','69d5f5f86a3e0858494d1d10493f1af6',1,16,10322,0),
('480f7b1104526ca784330338f9bc8f68','6e9b99b713d2006a61c58f305913b66e',1,8,10322,0),
('480f7b1104526ca784330338f9bc8f68','6ec66e124fb93c190e9207b0b82f542a',2,9,20645,0),
('480f7b1104526ca784330338f9bc8f68','72dacc9d1e0082d557ac8c1a4543a737',4,0,32000,128),
('480f7b1104526ca784330338f9bc8f68','73dc10cdc7580b395e0ae39d15f88919',1,2,10322,0),
('480f7b1104526ca784330338f9bc8f68','74a2dbd693f0f1e713011b1832c54d8c',1,29,10322,0),
('480f7b1104526ca784330338f9bc8f68','87c131a1c1e6f6bdcdf14c8f92104306',1,3,10322,0),
('480f7b1104526ca784330338f9bc8f68','8a1edb7c17ea34190b9aa6a751987d07',2,5,20645,0),
('480f7b1104526ca784330338f9bc8f68','959848ca10cc8a60da818ac11523dc63',3,4,30967,0),
('480f7b1104526ca784330338f9bc8f68','97eab50bed12220597a62014b33e2420',1,12,10322,0),
('480f7b1104526ca784330338f9bc8f68','a5212ecae231b0a7405799192fc34ab5',1,20,10322,0),
('480f7b1104526ca784330338f9bc8f68','a5582ce082dd86808f032b23447b370f',1,28,10322,0),
('480f7b1104526ca784330338f9bc8f68','af85b9ed98481408d4101739fed539d6',1,19,10322,0),
('480f7b1104526ca784330338f9bc8f68','c1c4b206324f9567d8f593bd0e4d1634',1,26,10322,0),
('480f7b1104526ca784330338f9bc8f68','d74600e380dbf727f67113fd71669d88',3,6,30967,0),
('480f7b1104526ca784330338f9bc8f68','e23670e9a137bdfe52b8a3a27797a450',1,22,10322,0),
('480f7b1104526ca784330338f9bc8f68','e6f06702c43d31c81cb42967420c0b31',1,7,10322,0),
('480f7b1104526ca784330338f9bc8f68','fa350f2393222ede0b459dfa89e1df26',1,27,10322,0),
('4f6e807051e61027dadc02f9f2906020','01b6e20344b68835c5ed1ddedf20d531',1,17,9142,0),
('4f6e807051e61027dadc02f9f2906020','08d5f9e9048e2000531c3170f4b833b1',3,0,27428,128),
('4f6e807051e61027dadc02f9f2906020','1d9e348141a4a084c649ca616877f279',1,32,9142,0),
('4f6e807051e61027dadc02f9f2906020','29d0b8d9daec06cdd0cda7269997b216',1,4,9142,0),
('4f6e807051e61027dadc02f9f2906020','2f212049ce79d2b949fd242043004288',1,13,9142,0),
('4f6e807051e61027dadc02f9f2906020','4015e9ce43edfb0668ddaa973ebc7e87',2,15,18285,0),
('4f6e807051e61027dadc02f9f2906020','4c9184f37cff01bcdc32dc486ec36961',1,19,9142,0),
('4f6e807051e61027dadc02f9f2906020','584826e70485130530f7f01a973d5637',1,12,9142,0),
('4f6e807051e61027dadc02f9f2906020','5c48b229521c5bbe9ac425745e45b724',1,28,9142,0),
('4f6e807051e61027dadc02f9f2906020','632a2406bbcbcd553eec45ac14b40a0a',1,31,9142,0),
('4f6e807051e61027dadc02f9f2906020','6f59adb57bd48bba19fed2dfec4bf275',1,11,9142,0),
('4f6e807051e61027dadc02f9f2906020','70a17ffa722a3985b86d30b034ad06d7',1,20,9142,0),
('4f6e807051e61027dadc02f9f2906020','74b92d895652792b35d69f92e3bab531',1,14,9142,0),
('4f6e807051e61027dadc02f9f2906020','7cef8a734855777c2a9d0caf42666e69',1,16,9142,0),
('4f6e807051e61027dadc02f9f2906020','8bf8854bebe108183caeb845c7676ae4',2,7,18285,0),
('4f6e807051e61027dadc02f9f2906020','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,30,9142,0),
('4f6e807051e61027dadc02f9f2906020','8fc42c6ddf9966db3b09e84365034357',5,2,32000,0),
('4f6e807051e61027dadc02f9f2906020','933dd8674c563081260867dfa95b5e74',1,27,9142,0),
('4f6e807051e61027dadc02f9f2906020','a00e43bc9d0a6d583cfcd6f8d00b1d35',1,6,9142,0),
('4f6e807051e61027dadc02f9f2906020','a566b2bebc62611dff4cdaceac1a7bbd',1,21,9142,0),
('4f6e807051e61027dadc02f9f2906020','aad0cd42d3c8a3b36a2be6a641d0cd53',3,0,27428,128),
('4f6e807051e61027dadc02f9f2906020','b5237b6a7892a42a4a7a60fdfbe828b9',1,22,9142,0),
('4f6e807051e61027dadc02f9f2906020','be5d5d37542d75f93a87094459f76678',2,10,18285,0),
('4f6e807051e61027dadc02f9f2906020','de17f0f24b49f8364187891f8550ffbb',1,25,9142,0),
('4fe65afd46a96ebb6113e4082c07329f','01bbba85d02955b23cbb2be354be2be2',1,62,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','01fc8dbe01da25daf8fd5da8f519c6a1',2,9,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','0b9a34b7bbce73bb011739b229debda7',1,0,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','0d3c4f5d92495e85c1af09b4b8e6f536',1,53,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','2116c221c2db2f9b400349baa6e3d7d1',1,15,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','2c9ceb35a9743095e6adddc158f6f31f',1,41,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','2e1268172f08d3cf32f2172eae567fb8',1,51,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','31783e73d792207712a1add81d10cbe9',1,19,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','592cbbfa476b65fe142c0463135b5c67',1,34,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','5b431d3d0cd0aafac0ed312ac7ff536b',1,56,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','5be23b1de1eff5ddf95ff3d5d9a4bd90',1,0,4155,128),
('4fe65afd46a96ebb6113e4082c07329f','5cfc1f542032073a69e82c2c7c6a8386',1,45,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','6094a70fb9532dfc3b1a9133364f3f7e',1,0,4155,128),
('4fe65afd46a96ebb6113e4082c07329f','61ba8e10509e5b38886b6a2a1cae367a',1,60,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','636d50a77da70596843a5638ac61d2b6',1,32,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','6e9b99b713d2006a61c58f305913b66e',1,16,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','6ec66e124fb93c190e9207b0b82f542a',2,6,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','6f4922f45568161a8cdf4ad2299f6d23',1,67,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','7071db26295c44957f44c77f3759aa10',2,0,8311,128),
('4fe65afd46a96ebb6113e4082c07329f','76671d4b83f6e6f953ea2dfb75ded921',1,65,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','7820cd42355d0b56bb26edd33c628c13',2,8,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','80570bebec5742bf89b3fbf9642cec02',1,37,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','85377d38c845e2d0661d1ad29d1aa0b2',1,40,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','88ae91df0447a7b6e338a3d65ce73be3',2,14,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','8a1a17e049499fb3b978d1e11b4f7693',1,43,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','8a1edb7c17ea34190b9aa6a751987d07',3,0,12467,128),
('4fe65afd46a96ebb6113e4082c07329f','8bcc25c96aa5a71f7a76309077753e67',1,59,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','8f3b0c9cf515520ce0b4b48a3daeb501',1,7,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','8f72382d96d9e4889cc14e35d423bf44',1,61,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','9173c9ad929ae18dca5d684fc40f5595',1,52,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','9e6823d5a518efab0ef808da6caffa93',1,22,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','9f62b8625f914a002496335037e9ad97',2,0,8311,128),
('4fe65afd46a96ebb6113e4082c07329f','a3c222e464ac4c7fc64d8686ed379439',1,18,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','a5212ecae231b0a7405799192fc34ab5',2,47,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','a57627656770ae9f260aa162ecacecb3',1,23,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','a87ff679a2f3e71d9181a67b7542122c',1,10,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','af85b9ed98481408d4101739fed539d6',3,2,12467,0),
('4fe65afd46a96ebb6113e4082c07329f','b2ae2cd3f4143bf192efb35bb9e7d369',1,11,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','bae2084bfdeaa3f6d8428ecbb0baf7da',1,1,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','bba21ef56d55c873195e173c1e2c3e04',1,68,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','be43f0cbf4bcbb3ab0d83b14b868920e',1,5,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','c64ace31a7ae9d6b932ef82e562433af',1,39,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','c68c559d956d4ca20f435ed74a6e71e6',4,0,16623,128),
('4fe65afd46a96ebb6113e4082c07329f','d4fbae6323ac161c03127c31690d81f4',4,3,16623,0),
('4fe65afd46a96ebb6113e4082c07329f','d6145d469d21cc6a3c808862fc17d089',1,4,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','d7427581d459b8812a848189f4ea3636',2,0,8311,128),
('4fe65afd46a96ebb6113e4082c07329f','d74600e380dbf727f67113fd71669d88',7,0,29090,128),
('4fe65afd46a96ebb6113e4082c07329f','dde4bab04145ef8852c840d66cd2f07b',2,12,8311,0),
('4fe65afd46a96ebb6113e4082c07329f','e0d2deb0913fdcf884c0f7971df7a623',1,21,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','e113a38355ed45892a2d3b2d385c48f2',1,44,4155,0),
('4fe65afd46a96ebb6113e4082c07329f','ef836cc47626c394523434ab2fbe7dcd',2,24,8311,0),
('5192c25f9e1778c3c79dff990fa03437','1c7a710dcf915e3ea681e113f7795eca',1,10,8205,0),
('5192c25f9e1778c3c79dff990fa03437','1feb078f3e07a4b9b47c90c6495c894d',1,5,8205,0),
('5192c25f9e1778c3c79dff990fa03437','21c5084aeff1e5fbcbaa98b661758382',4,0,32000,128),
('5192c25f9e1778c3c79dff990fa03437','276b6c4692e78d4799c12ada515bc3e4',2,23,16410,0),
('5192c25f9e1778c3c79dff990fa03437','28ef5e079b0571848c806ff5266c2c22',1,29,8205,0),
('5192c25f9e1778c3c79dff990fa03437','32af23ab89095528e5cac67ce5c2a497',1,26,8205,0),
('5192c25f9e1778c3c79dff990fa03437','34a7956c816cd1faa1b96dbe2806f9b3',1,37,8205,0),
('5192c25f9e1778c3c79dff990fa03437','36eee0019cac8e1c32d9f87d19de1355',1,33,8205,0),
('5192c25f9e1778c3c79dff990fa03437','3a5afaf5d67c2547a79f0c517e1191f1',1,36,8205,0),
('5192c25f9e1778c3c79dff990fa03437','4842977d009b213a738666fe26ba78e6',1,16,8205,0),
('5192c25f9e1778c3c79dff990fa03437','4917dba1522528ff583a4abe5a90b62c',1,17,8205,0),
('5192c25f9e1778c3c79dff990fa03437','5464125f42d78ff58c5a88c3dedf675a',1,13,8205,0),
('5192c25f9e1778c3c79dff990fa03437','5f919c0306e6579479e36d34ea7fb648',1,11,8205,0),
('5192c25f9e1778c3c79dff990fa03437','677221a278ff6fd52c06f79626dbbf76',1,22,8205,0),
('5192c25f9e1778c3c79dff990fa03437','6c1990b7d29f5774a516bfbf7bd05975',1,20,8205,0),
('5192c25f9e1778c3c79dff990fa03437','6ec66e124fb93c190e9207b0b82f542a',3,8,24615,0),
('5192c25f9e1778c3c79dff990fa03437','7ce10e36b6c1837a30f1bed7c05c60ad',1,21,8205,0),
('5192c25f9e1778c3c79dff990fa03437','80570bebec5742bf89b3fbf9642cec02',1,1,8205,0),
('5192c25f9e1778c3c79dff990fa03437','8a1edb7c17ea34190b9aa6a751987d07',1,4,8205,0),
('5192c25f9e1778c3c79dff990fa03437','8e1b595f6403c7a34b46acdf8732288d',1,30,8205,0),
('5192c25f9e1778c3c79dff990fa03437','8e39dd47f29a3fa442ba24ff6ebaacbd',1,14,8205,0),
('5192c25f9e1778c3c79dff990fa03437','8f72382d96d9e4889cc14e35d423bf44',2,6,16410,0),
('5192c25f9e1778c3c79dff990fa03437','9cd237cbcfaa843bac1e5a8299f9f2a1',1,9,8205,0),
('5192c25f9e1778c3c79dff990fa03437','9e6823d5a518efab0ef808da6caffa93',1,7,8205,0),
('5192c25f9e1778c3c79dff990fa03437','a212ff322370e1d58e71fba0550aca76',1,35,8205,0),
('5192c25f9e1778c3c79dff990fa03437','a22c8f2df3150c0d125b5769235ab6af',1,18,8205,0),
('5192c25f9e1778c3c79dff990fa03437','a5212ecae231b0a7405799192fc34ab5',1,31,8205,0),
('5192c25f9e1778c3c79dff990fa03437','c4cdd836c5df69ba56216bfb3d4e3fb7',1,2,8205,0),
('5192c25f9e1778c3c79dff990fa03437','c68c559d956d4ca20f435ed74a6e71e6',1,27,8205,0),
('5192c25f9e1778c3c79dff990fa03437','d74600e380dbf727f67113fd71669d88',1,32,8205,0),
('5192c25f9e1778c3c79dff990fa03437','ebb021ec2f9dabb53dcd71109d87c1d5',1,19,8205,0),
('5192c25f9e1778c3c79dff990fa03437','ff6f9e6eb127358d7f6cac078f7fba1d',1,3,8205,0),
('53a65a8e3f722edf05d31693dce3236f','4be77da577a5f3e817dbfde199c142f6',1,0,32000,128),
('55a8841b368fd8e1405e80ae0cf43f69','03c98ff9edc4b0e2fa19dd478e1613ee',3,0,15238,0),
('55a8841b368fd8e1405e80ae0cf43f69','07d9e3aefc4093a49121c91ef65e708b',2,0,10158,128),
('55a8841b368fd8e1405e80ae0cf43f69','0a538a0ca54a9f51fc1334040fb89d64',2,0,10158,128),
('55a8841b368fd8e1405e80ae0cf43f69','0bead884803fe8c5643dda0dcb94b1bc',1,15,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','0cc175b9c0f1b6a831c399e269772661',1,44,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','1679091c5a880faf6fb5e6087eb1b2dc',1,5,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','21f64da1e5792c8295b964d159a14491',1,29,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','2a4982f2efa6b2c278db2286b3c23e8f',1,54,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','2fd7cb590fc8e5de760a3a21256b5555',1,48,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','36a383994590c1a836800f68a08d00ba',1,43,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','3a50c5e41a1c3eee6dcddca9e04992e0',1,53,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','3c8925c7fb2d563070c4c7aa96954e92',1,39,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','4015e9ce43edfb0668ddaa973ebc7e87',2,30,10158,0),
('55a8841b368fd8e1405e80ae0cf43f69','4a46687a15a878b7c06dbc3d07a8f0ef',1,14,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','4d04cedd6d05b1f16a4404ff5a1fa4af',1,6,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','632a2406bbcbcd553eec45ac14b40a0a',1,56,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','7108537956afa2a526f96cc9da7b0c36',1,21,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','716f6b30598ba30945d84485e61c1027',1,1,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','7d0db380a5b95a8ba1da0bca241abda1',4,2,20317,0),
('55a8841b368fd8e1405e80ae0cf43f69','8bf8854bebe108183caeb845c7676ae4',3,0,15238,128),
('55a8841b368fd8e1405e80ae0cf43f69','8e57eec98946ddacf0f4b4cbc844bdb8',1,45,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','8fc42c6ddf9966db3b09e84365034357',5,8,25396,0),
('55a8841b368fd8e1405e80ae0cf43f69','93aa88d53279ccb3e40713d4396e198f',2,10,10158,0),
('55a8841b368fd8e1405e80ae0cf43f69','9460370bb0ca1c98a779b1bcc6861c2c',2,0,10158,128),
('55a8841b368fd8e1405e80ae0cf43f69','98f13708210194c475687be6106a3b84',1,41,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','aad0cd42d3c8a3b36a2be6a641d0cd53',3,9,15238,0),
('55a8841b368fd8e1405e80ae0cf43f69','aaf9a7ade8ad853549f9ce5d53e8d645',2,0,10158,128),
('55a8841b368fd8e1405e80ae0cf43f69','acbaf7dd72a645872b64a28687e0cb45',1,25,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','b3ba719b7f5004d91df10aff537603e4',1,57,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','be5d5d37542d75f93a87094459f76678',1,20,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','c4ca4238a0b923820dcc509a6f75849b',1,49,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','c6f057b86584942e415435ffb1fa93d4',2,24,10158,0),
('55a8841b368fd8e1405e80ae0cf43f69','c81e728d9d4c2f636f067f89cc14862c',1,23,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','cb73f2f1a23779bd445d8199ad3c522f',1,3,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','d4319fefc66c701f24c875afda6360d6',1,46,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','d55669822f1a8cf72ec1911e462a54eb',1,17,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','d98a07f84921b24ee30f86fd8cd85c3c',1,40,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','e4894ca167b08880bfc35862f18575eb',1,31,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','e60a95f3f443e37f5a47210d9b340a05',1,42,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','e72f4545eb68c96c754f91fc01573517',2,11,10158,0),
('55a8841b368fd8e1405e80ae0cf43f69','ed2b5c0139cec8ad2873829dc1117d50',1,4,5079,0),
('55a8841b368fd8e1405e80ae0cf43f69','ffe181130430aff6386df37df36347f8',1,55,5079,0),
('56ce185f3262c9101626cfd28a4127a4','01b6e20344b68835c5ed1ddedf20d531',4,14,29090,0),
('56ce185f3262c9101626cfd28a4127a4','0cc175b9c0f1b6a831c399e269772661',1,24,7272,0),
('56ce185f3262c9101626cfd28a4127a4','10cd395cf71c18328c863c08e78f3fd0',3,0,21818,128),
('56ce185f3262c9101626cfd28a4127a4','21582c6c30be1217322cdb9aebaf4a59',1,31,7272,0),
('56ce185f3262c9101626cfd28a4127a4','2c61ebff5a7f675451467527df66788d',1,19,7272,0),
('56ce185f3262c9101626cfd28a4127a4','312db69f5bf4447dfe3c58983083b54f',1,1,7272,0),
('56ce185f3262c9101626cfd28a4127a4','34d1f91fb2e514b8576fab1a75a89a6b',1,37,7272,0),
('56ce185f3262c9101626cfd28a4127a4','39306192204262ad0b88470c636a75dd',1,9,7272,0),
('56ce185f3262c9101626cfd28a4127a4','3bebb2f89180b03fa5ae736665f648d9',1,21,7272,0),
('56ce185f3262c9101626cfd28a4127a4','430773153341c662da6867d207e96ae2',1,6,7272,0),
('56ce185f3262c9101626cfd28a4127a4','4a2028eceac5e1f4d252ea13c71ecec6',2,11,14545,0),
('56ce185f3262c9101626cfd28a4127a4','5440e70c43cc02aba90d879c888e6e09',1,4,7272,0),
('56ce185f3262c9101626cfd28a4127a4','567904efe9e64d9faf3e41ef402cb568',1,23,7272,0),
('56ce185f3262c9101626cfd28a4127a4','639bae9ac6b3e1a84cebb7b403297b79',1,12,7272,0),
('56ce185f3262c9101626cfd28a4127a4','6b2ded51d81a4403d8a4bd25fa1e57ee',1,16,7272,0),
('56ce185f3262c9101626cfd28a4127a4','71860c77c6745379b0d44304d66b6a13',1,29,7272,0),
('56ce185f3262c9101626cfd28a4127a4','7f46165474d11ee5836777d85df2cdab',1,22,7272,0),
('56ce185f3262c9101626cfd28a4127a4','84eeb81e61c76ad3f4103b0b051c7021',1,33,7272,0),
('56ce185f3262c9101626cfd28a4127a4','8b7af514f25f1f9456dcd10d2337f753',1,34,7272,0),
('56ce185f3262c9101626cfd28a4127a4','8fc42c6ddf9966db3b09e84365034357',2,2,14545,0),
('56ce185f3262c9101626cfd28a4127a4','910955a907e739b81ec8855763108a29',1,20,7272,0),
('56ce185f3262c9101626cfd28a4127a4','9a09e6ec9d67e3856d220f708ceb1508',1,8,7272,0),
('56ce185f3262c9101626cfd28a4127a4','9de70f6546b2452f6e7b98b46ac36070',1,25,7272,0),
('56ce185f3262c9101626cfd28a4127a4','a2a551a6458a8de22446cc76d639a9e9',1,26,7272,0),
('56ce185f3262c9101626cfd28a4127a4','aaabf0d39951f3e6c3e8a7911df524c2',1,32,7272,0),
('56ce185f3262c9101626cfd28a4127a4','aad0cd42d3c8a3b36a2be6a641d0cd53',1,3,7272,0),
('56ce185f3262c9101626cfd28a4127a4','b5eda0a74558a342cf659187f06f746f',1,15,7272,0),
('56ce185f3262c9101626cfd28a4127a4','b99a78d80570fc2b2bfd0dab4c39ea04',1,42,7272,0),
('56ce185f3262c9101626cfd28a4127a4','be5d5d37542d75f93a87094459f76678',2,7,14545,0),
('56ce185f3262c9101626cfd28a4127a4','c0ca5324e06afa567f7d5ad10a592576',1,27,7272,0),
('56ce185f3262c9101626cfd28a4127a4','d55669822f1a8cf72ec1911e462a54eb',2,5,14545,0),
('56ce185f3262c9101626cfd28a4127a4','df3f079de6961496f0460dcfdbf9bca3',1,10,7272,0),
('56ce185f3262c9101626cfd28a4127a4','e72f4545eb68c96c754f91fc01573517',1,35,7272,0),
('56ce185f3262c9101626cfd28a4127a4','e877c56e4fb621e81fd30dbd114a545b',1,13,7272,0),
('56ce185f3262c9101626cfd28a4127a4','f7c0a09108cdf26287c1bc5af2ed1f93',1,17,7272,0),
('56e8dbba6bd49275b2763e0aa24d2418','0cc175b9c0f1b6a831c399e269772661',1,38,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','0d149b90e7394297301c90191ae775f0',1,43,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','13b5bfe96f3e2fe411c9f66f4a582adf',1,5,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','20820bde05df43a0783e8886c51ace9a',1,41,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','20cc39187933346eee8108ec76a2f796',1,20,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','21927851c1be56cb95b9baa4abcb023c',1,17,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','22af645d1859cb5ca6da0c484f1f37ea',1,0,5818,128),
('56e8dbba6bd49275b2763e0aa24d2418','22d97324e887bceb83f5a3a68ef31390',1,11,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','39c8942e1038872a822c0dc75eedbde3',1,37,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','49ddafa93b4052e15e041a43d4343fda',2,0,11636,128),
('56e8dbba6bd49275b2763e0aa24d2418','4d04cedd6d05b1f16a4404ff5a1fa4af',1,2,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','51037a4a37730f52c8732586d3aaa316',1,27,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','55ab85e676ef2f7305f22d8119d53410',1,19,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','6050ce63e4bce6764cb34cac51fb44d1',1,29,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','628b7db04235f228d40adc671413a8c8',1,0,5818,128),
('56e8dbba6bd49275b2763e0aa24d2418','6c374e70334072aeeb62ed46ea987838',1,30,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','7d0db380a5b95a8ba1da0bca241abda1',1,32,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','8bf8854bebe108183caeb845c7676ae4',1,13,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','8dee49165153fc68ffacb5f7f7bf9a3a',1,12,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','8fc42c6ddf9966db3b09e84365034357',4,15,23272,0),
('56e8dbba6bd49275b2763e0aa24d2418','90fafe3a7d04ee1c17239fa2d768f8fc',1,24,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','95723b5e620e47cf613462b9f293282a',1,9,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','9bbd993d9da7df60b3fd4a4ed721b082',1,28,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','a16574242b3bbe2fc5ec9dc26fe4deb2',1,48,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','a2a551a6458a8de22446cc76d639a9e9',2,8,11636,0),
('56e8dbba6bd49275b2763e0aa24d2418','ab280114f07686e8c6872827c99ca96e',1,34,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','bbc675c430deefa88c9091c8084ec4c9',1,14,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','be5d5d37542d75f93a87094459f76678',1,22,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','c1c16452b04650ea34d1463da2739f3b',1,23,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','c1f7ed800b498c3e7d5ee7f3cbdedc63',3,0,17454,128),
('56e8dbba6bd49275b2763e0aa24d2418','c4ca4238a0b923820dcc509a6f75849b',1,1,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','cb15e32f389b7af9b285a63ca1044651',2,4,11636,0),
('56e8dbba6bd49275b2763e0aa24d2418','d55669822f1a8cf72ec1911e462a54eb',1,0,5818,128),
('56e8dbba6bd49275b2763e0aa24d2418','d98a07f84921b24ee30f86fd8cd85c3c',1,0,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','db6d9b451b818ccc9a449383f2f0c450',3,0,17454,128),
('56e8dbba6bd49275b2763e0aa24d2418','df3f079de6961496f0460dcfdbf9bca3',1,35,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','e98d2f001da5678b39482efbdf5770dc',1,42,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','eb399bcaca686f8609137153307eecf1',1,16,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','ed2b5c0139cec8ad2873829dc1117d50',3,10,17454,0),
('56e8dbba6bd49275b2763e0aa24d2418','f2dd6c078b512971abdd8ed871bafb6f',1,3,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','f61657e8b1aa35d4af30522a25c4df3a',1,31,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','f97c5d29941bfb1b2fdab0874906ab82',1,18,5818,0),
('56e8dbba6bd49275b2763e0aa24d2418','fd375dee4843d6afdf6aeae485db529d',1,36,5818,0),
('67d787a12066aa33f927bc0bed2dc3fd','01b6e20344b68835c5ed1ddedf20d531',2,3,22068,0),
('67d787a12066aa33f927bc0bed2dc3fd','0b3b97fa66886c5688ee4ae80ec0c3c2',2,0,22068,128),
('67d787a12066aa33f927bc0bed2dc3fd','2f8a6bf31f3bd67bd2d9720c58b19c9a',3,0,32000,128),
('67d787a12066aa33f927bc0bed2dc3fd','3c68cbe461787ba38509df85e731f1a6',1,11,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','3c8925c7fb2d563070c4c7aa96954e92',1,9,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','4c9858e082cad5bd214a9efc0f2f8cec',1,4,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','5188aa9e6815c731a69a0c302c772797',1,17,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','52a1c95fd889c4a3b00f33472a845157',1,7,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','5a0f33b732e7824bd6477cbb1ee20c64',1,26,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','7198cda575b51b68a0dc83f5d66c2aee',1,13,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','78949a75178ddd3c0c73cfcd5475d75a',1,22,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','8fc42c6ddf9966db3b09e84365034357',1,19,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','944ba223a5c1b5f4b495708e7cd5ee37',1,14,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','aad0cd42d3c8a3b36a2be6a641d0cd53',2,6,22068,0),
('67d787a12066aa33f927bc0bed2dc3fd','bd5bb0ca70a22a3725257f45e0e9f549',1,24,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','c6f057b86584942e415435ffb1fa93d4',1,25,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','c91497eaedfc46b7398ef737efc428e0',1,10,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','d64a4d022098892cecf250b5842c2a48',1,21,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','db88a0257c220dbfdd2e40f6152d6a8d',1,2,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','e6f06702c43d31c81cb42967420c0b31',2,5,22068,0),
('67d787a12066aa33f927bc0bed2dc3fd','ed2b5c0139cec8ad2873829dc1117d50',1,23,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','f6f7fec07f372b7bd5eb196bbca0f3f4',1,16,11034,0),
('67d787a12066aa33f927bc0bed2dc3fd','fb9e0c48b8a116a3da9a28c36bdd6840',1,18,11034,0),
('6d2ddd1174e062f12957e8f7a89bafb1','0ba4439ee9a46d9d9f14c60f88f45f87',1,21,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','0cc175b9c0f1b6a831c399e269772661',2,25,14545,0),
('6d2ddd1174e062f12957e8f7a89bafb1','0e5243d9965540f62aac19a985f3f33e',1,31,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','13b5bfe96f3e2fe411c9f66f4a582adf',1,10,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','2069ca795d8e10a6f9a92dd57d01af10',1,23,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','23a58bf9274bedb19375e527a0744fa9',1,27,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','32fa6e1b78a9d4028953e60564a2aa4c',1,29,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','4015e9ce43edfb0668ddaa973ebc7e87',1,4,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','467b6140fe3bb958f2332983914de787',1,18,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','48aee20d947736a18c6e9d09b526f75a',1,5,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','49ddafa93b4052e15e041a43d4343fda',1,36,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','584826e70485130530f7f01a973d5637',1,28,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','6cd8b57ad8ec40b32215dcb1c8c76af2',3,0,21818,128),
('6d2ddd1174e062f12957e8f7a89bafb1','7d0db380a5b95a8ba1da0bca241abda1',1,34,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','7f46165474d11ee5836777d85df2cdab',1,33,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','83ab982dd08483187289a75163dc50fe',1,7,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','84cdc76cabf41bd7c961f6ab12f117d8',1,20,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','87cf962b35146c21d0dd7f84594662b6',3,0,21818,128),
('6d2ddd1174e062f12957e8f7a89bafb1','8fc42c6ddf9966db3b09e84365034357',2,11,14545,0),
('6d2ddd1174e062f12957e8f7a89bafb1','933dd8674c563081260867dfa95b5e74',1,19,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','96f223040672ea79c655dceda08e0830',1,14,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','aad0cd42d3c8a3b36a2be6a641d0cd53',1,12,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','b02a45a596bfb86fe2578bde75ff5444',1,32,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','b1bc248a7ff2b2e95569f56de68615df',1,30,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ba543925dcf34943ee34636edfb90198',1,41,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','bd5af1f610a12434c9128e4a399cef8a',1,40,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','be5d5d37542d75f93a87094459f76678',1,13,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','c4ca4238a0b923820dcc509a6f75849b',1,17,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d6659eb12bf486df161279952521dcfc',1,8,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','d6692dd335c3c6b2ad020e2758eed628',1,15,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','df3f079de6961496f0460dcfdbf9bca3',1,39,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e170e3a15923188224c1c2bd1477d451',2,9,14545,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e72f4545eb68c96c754f91fc01573517',1,37,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','e81c4e4f2b7b93b481e13a8553c2ae1b',1,38,7272,0),
('6d2ddd1174e062f12957e8f7a89bafb1','ed2b5c0139cec8ad2873829dc1117d50',3,6,21818,0),
('78cabd40e1e1f417b9f83789c2321f4a','01b6e20344b68835c5ed1ddedf20d531',6,74,8533,0),
('78cabd40e1e1f417b9f83789c2321f4a','057a00ebe4c35f8e72be9349834dc619',1,119,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','075a3e36a0a52dcbc568c05788e8a713',1,126,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','09300df44b9d20cc219b25abddc3346e',2,127,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','0931be4cc434934e64b1894aa2dba1ae',9,12,12800,0),
('78cabd40e1e1f417b9f83789c2321f4a','09416c048ec5193549d096e7eb7fa36f',1,213,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','0c83f57c786a0b4a39efab23731c7ebc',1,174,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','0cc175b9c0f1b6a831c399e269772661',12,9,17066,0),
('78cabd40e1e1f417b9f83789c2321f4a','0d149b90e7394297301c90191ae775f0',1,144,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','0f5264038205edfb1ac05fbb0e8c5e94',1,143,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','100b8cad7cf2a56f6df78f171f97a1ec',1,37,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','106a6c241b8797f52e1e77317b96a201',1,53,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','12cba3ee81cf4a793796a51b6327c678',1,169,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','131be413a48a3a5ce429995e2170c5aa',1,199,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','13b5bfe96f3e2fe411c9f66f4a582adf',3,5,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','1679091c5a880faf6fb5e6087eb1b2dc',1,128,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','1adc13cf053c4d8e60b6a20a9e611123',1,100,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','21e119daf697467b14b076f2d5819aec',2,38,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','23a58bf9274bedb19375e527a0744fa9',1,61,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','28e32fb02cd44e44796348fbc2b93e1c',1,158,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','2d95b19b24f71bcabbc68e31afaff694',1,206,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','2f8a6bf31f3bd67bd2d9720c58b19c9a',1,207,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','2fd7cb590fc8e5de760a3a21256b5555',3,123,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','30056e1cab7a61d256fc8edd970d14f5',1,152,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','32fa6e1b78a9d4028953e60564a2aa4c',1,96,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','35ea8083fa3fa79e8294cb56d079387d',3,8,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','3676d55f84497cbeadfc614c1b1b62fc',3,148,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','3c8925c7fb2d563070c4c7aa96954e92',2,27,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','4015e9ce43edfb0668ddaa973ebc7e87',1,188,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','4061838f4395ef541fb1b3f07e42bc21',1,198,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','43b5c9175984c071f30b873fdce0a000',1,15,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','44fdec47036f482b68b748f9d786801b',1,154,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','459d9fca17e3a950deae755d13578292',1,208,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','467b6140fe3bb958f2332983914de787',1,192,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','46c48bec0d282018b9d167eef7711b2c',1,120,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','49ddafa93b4052e15e041a43d4343fda',1,21,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','4a2028eceac5e1f4d252ea13c71ecec6',1,71,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','4ab8710d781ba5b13aaf561cafd896b7',1,166,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','4da463dcb391d40ec0352edd2e42b2d2',2,17,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','5188aa9e6815c731a69a0c302c772797',1,221,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','53d670af9bb16ea82e7ef41ee23ec6df',1,28,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','563873d38950b841aebf89c3be1b1a35',1,77,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','567904efe9e64d9faf3e41ef402cb568',1,162,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','582ca3f7cbaf4edcc1b445f8ea90b503',1,114,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','5ba3205251522e793017b3af03c607ce',1,101,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','5dd2199ad68327cc76d583b057aee7d5',1,85,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','60df9e64b0693131b626e465236c6874',1,151,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','632a2406bbcbcd553eec45ac14b40a0a',1,196,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','639bae9ac6b3e1a84cebb7b403297b79',1,72,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','646e6c2859df4288ae1bca30363de15e',3,58,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','69a256025f66e4ce5d15c9dd7225d357',1,42,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','72122ce96bfec66e2396d2e25225d70a',1,90,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','7515875808ef6219fa6fd725e2105588',1,217,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','758f0e9ea526af2ca587384176f5bbf3',2,189,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','7761127a460aaf290ed953098284dd1a',1,137,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','789183b7e98646c11d5f0544c8f3c4c9',1,171,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','7b7813f00f42b7e5366e7065aaa798c6',1,48,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','7d0db380a5b95a8ba1da0bca241abda1',3,19,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','7f46165474d11ee5836777d85df2cdab',1,18,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','83ab982dd08483187289a75163dc50fe',1,2,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','84cdc76cabf41bd7c961f6ab12f117d8',3,16,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','884d9804999fc47a3c2694e49ad2536a',1,175,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','8a6f503814aa4a7cd863e68c7778fbdb',1,93,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','8bf8854bebe108183caeb845c7676ae4',5,79,7111,0),
('78cabd40e1e1f417b9f83789c2321f4a','8d31d9aa2193cbd93731d668fe8caadc',1,41,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','8fc42c6ddf9966db3b09e84365034357',17,14,24177,0),
('78cabd40e1e1f417b9f83789c2321f4a','90fafe3a7d04ee1c17239fa2d768f8fc',1,65,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','933dd8674c563081260867dfa95b5e74',1,70,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','94074ce331b5db47060fd2d8009503a8',1,211,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','944ba223a5c1b5f4b495708e7cd5ee37',1,218,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','98f13708210194c475687be6106a3b84',2,130,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,132,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','a0e7b2a565119c0a7ec3126a16016113',1,111,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','a1b140811f9aa57a4154706e98fa2dee',1,43,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','a1ff09453cc85d1a8cc7fb1f4911f8e4',2,105,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','a2a551a6458a8de22446cc76d639a9e9',4,34,5688,0),
('78cabd40e1e1f417b9f83789c2321f4a','a53108f7543b75adbb34afc035d4cdf6',2,51,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','a77b3598941cb803eac0fcdafe44fac9',1,165,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','a9e4f7e098ba45314ead394184671cc7',1,56,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','a9f0e61a137d86aa9db53465e0801612',1,216,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','aaabf0d39951f3e6c3e8a7911df524c2',1,39,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','aad0cd42d3c8a3b36a2be6a641d0cd53',4,7,5688,0),
('78cabd40e1e1f417b9f83789c2321f4a','ac67ede5a84eb5a1add7ff4440e9a485',1,35,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','addec426932e71323700afa1911f8f1c',1,136,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','afacdb0a401ccdf6b48551bbc00e8a74',1,134,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','b1b9a972ccd8c962a473909b97007eb4',1,204,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','b1bc248a7ff2b2e95569f56de68615df',1,97,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','b4992073ceb7cead98413d6509b1db49',1,150,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','b8a9f715dbb64fd5c56e7783c6820a61',1,64,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','be5d5d37542d75f93a87094459f76678',3,167,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','c16a5320fa475530d9583c34fd356ef5',2,185,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','c1a55efe8fd9efed48836d50691cdae4',1,4,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','c2f28daa81da003f46d3865ae0362d5c',3,0,4266,128),
('78cabd40e1e1f417b9f83789c2321f4a','c327b49efdca2668f28cd7b4beee54b3',1,153,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','c4ef352f74e502ef5e7bc98e6f4e493d',1,113,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','c68271a63ddbc431c307beb7d2918275',1,44,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','c6f057b86584942e415435ffb1fa93d4',3,125,4266,0),
('78cabd40e1e1f417b9f83789c2321f4a','c81e728d9d4c2f636f067f89cc14862c',1,191,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','c92a10324374fac681719d63979d00fe',1,110,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','d056025fbea3c4700729c5b96b0ff97b',1,87,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','d4319fefc66c701f24c875afda6360d6',2,115,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','d55669822f1a8cf72ec1911e462a54eb',4,13,5688,0),
('78cabd40e1e1f417b9f83789c2321f4a','d645920e395fedad7bbbed0eca3fe2e0',1,140,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','d78406cbaeb5be8c2ef9dfca493dc55e',1,92,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','d98a07f84921b24ee30f86fd8cd85c3c',2,52,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','d9a22d7a8178d5b42a8750123cbfe5b1',1,147,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','db88a0257c220dbfdd2e40f6152d6a8d',1,142,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','dd5c07036f2975ff4bce568b6511d3bc',1,10,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','e0d30cef5c6139275b58b525001b413c',2,78,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','e4da3b7fbbce2345d7772b0674a318d5',2,122,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','e6f06702c43d31c81cb42967420c0b31',1,6,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','e72f4545eb68c96c754f91fc01573517',2,22,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','e81c4e4f2b7b93b481e13a8553c2ae1b',4,23,5688,0),
('78cabd40e1e1f417b9f83789c2321f4a','e877c56e4fb621e81fd30dbd114a545b',1,73,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','eb5c1399a871211c7e7ed732d15e3a8b',1,118,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','ed2b5c0139cec8ad2873829dc1117d50',1,176,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f2c67381db28fa11c59fe7a6df0f2587',1,201,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f5d7e2532cc9ad16bc2a41222d76f269',7,0,9955,128),
('78cabd40e1e1f417b9f83789c2321f4a','f6f7fec07f372b7bd5eb196bbca0f3f4',1,220,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f75cac02116d825a000c33a7c326af37',1,145,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f82d71a6491c31b384ab5b57d85b6593',1,83,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f962bed5616612c8c7053f6e97e72b12',1,186,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','f97c5d29941bfb1b2fdab0874906ab82',2,54,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','fb9e0c48b8a116a3da9a28c36bdd6840',1,222,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','fbf5b451f590a940e1a18477b062f8e0',1,179,1422,0),
('78cabd40e1e1f417b9f83789c2321f4a','fe3838c7c11aa406dd956566e17360d5',2,116,2844,0),
('78cabd40e1e1f417b9f83789c2321f4a','ff483d1ff591898a9942916050d2ca3f',1,84,1422,0),
('78d410ed8d322872c93e023c151a02b9','0b3b97fa66886c5688ee4ae80ec0c3c2',1,30,6808,0),
('78d410ed8d322872c93e023c151a02b9','0cc175b9c0f1b6a831c399e269772661',2,7,13617,0),
('78d410ed8d322872c93e023c151a02b9','0d149b90e7394297301c90191ae775f0',1,25,6808,0),
('78d410ed8d322872c93e023c151a02b9','172a8327fcd3685ab3c0f740d031da09',1,8,6808,0),
('78d410ed8d322872c93e023c151a02b9','20820bde05df43a0783e8886c51ace9a',1,43,6808,0),
('78d410ed8d322872c93e023c151a02b9','39c8942e1038872a822c0dc75eedbde3',1,16,6808,0),
('78d410ed8d322872c93e023c151a02b9','49ddafa93b4052e15e041a43d4343fda',1,15,6808,0),
('78d410ed8d322872c93e023c151a02b9','55f195813a158d82e2934cfac569575d',1,26,6808,0),
('78d410ed8d322872c93e023c151a02b9','628b7db04235f228d40adc671413a8c8',2,11,13617,0),
('78d410ed8d322872c93e023c151a02b9','62cc0b4ebb0b57b40778179234246c38',2,14,13617,0),
('78d410ed8d322872c93e023c151a02b9','6cede1cfde12fc6d88ad1d8b6636a977',1,31,6808,0),
('78d410ed8d322872c93e023c151a02b9','7587ec3e10e7c0a2032fc022bb45b1fe',1,35,6808,0),
('78d410ed8d322872c93e023c151a02b9','83ab982dd08483187289a75163dc50fe',1,36,6808,0),
('78d410ed8d322872c93e023c151a02b9','8c00c19e66a7ba9d80bded9460cb1b41',1,28,6808,0),
('78d410ed8d322872c93e023c151a02b9','8fc42c6ddf9966db3b09e84365034357',4,10,27234,0),
('78d410ed8d322872c93e023c151a02b9','95723b5e620e47cf613462b9f293282a',2,5,13617,0),
('78d410ed8d322872c93e023c151a02b9','a2a551a6458a8de22446cc76d639a9e9',1,4,6808,0),
('78d410ed8d322872c93e023c151a02b9','a77b3598941cb803eac0fcdafe44fac9',1,19,6808,0),
('78d410ed8d322872c93e023c151a02b9','b42dad5453b2128a32f6612b13ea5d9f',1,27,6808,0),
('78d410ed8d322872c93e023c151a02b9','c7c3169c21f1d92e9577871831d067c8',1,40,6808,0),
('78d410ed8d322872c93e023c151a02b9','cb15e32f389b7af9b285a63ca1044651',5,0,32000,128),
('78d410ed8d322872c93e023c151a02b9','cdaeeeba9b4a4c5ebf042c0215a7bb0e',1,12,6808,0),
('78d410ed8d322872c93e023c151a02b9','d0cab90d8d20d57e2f2b9be52f7dd25d',1,39,6808,0),
('78d410ed8d322872c93e023c151a02b9','d529e941509eb9e9b9cfaeae1fe7ca23',1,20,6808,0),
('78d410ed8d322872c93e023c151a02b9','d55669822f1a8cf72ec1911e462a54eb',1,13,6808,0),
('78d410ed8d322872c93e023c151a02b9','db6d9b451b818ccc9a449383f2f0c450',3,0,20425,128),
('78d410ed8d322872c93e023c151a02b9','e2eff6c2dafd909df8508f891b385d88',1,6,6808,0),
('78d410ed8d322872c93e023c151a02b9','e98d2f001da5678b39482efbdf5770dc',2,37,13617,0),
('78d410ed8d322872c93e023c151a02b9','ed2b5c0139cec8ad2873829dc1117d50',2,9,13617,0),
('78d410ed8d322872c93e023c151a02b9','f2dd6c078b512971abdd8ed871bafb6f',1,2,6808,0),
('78d410ed8d322872c93e023c151a02b9','f894427cc1c571f79da49605ef8b112f',1,34,6808,0),
('78d410ed8d322872c93e023c151a02b9','fe17ec3c451f132ef82a3a54e84a461e',1,29,6808,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','1feb078f3e07a4b9b47c90c6495c894d',1,2,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','33a931c25fc53fb3541e1d9754dbcc62',2,0,29090,128),
('7fb9c8e8b02c27d3a5c5c229300fb27f','393095cbd61196a5346e69acc966a029',1,6,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','42ddcea8b7d1fd6b522b633c9cac018e',2,5,29090,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','6d8a6dae33d1c8276853e32544b4ccf6',1,14,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','6ec66e124fb93c190e9207b0b82f542a',3,4,32000,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','778a15406292a461ce949276efcd87a3',2,10,29090,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','8a1edb7c17ea34190b9aa6a751987d07',1,1,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','8f72382d96d9e4889cc14e35d423bf44',1,17,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','9195c5d7e168864e4a7b5f74067fa638',1,12,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','942c5256345499efd6c26aea884f4a58',1,11,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','9662d33089e9ecf2a7b0caebcc22a977',1,19,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','9b865ffcca75bae72520a5b43a64a47e',1,8,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','db5cee64d8879581f189d71178dcb055',1,3,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','e1a1ba25715bed51a3b86e54d07bcf20',1,18,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','ee45ece1ad226515c7e61bf67940f6dc',1,16,14545,0),
('7fb9c8e8b02c27d3a5c5c229300fb27f','fbccd5bc2be21e45d77b45272dcefed4',1,20,14545,0),
('85c2621b0fce09ac51613f18ce135f4b','01b6e20344b68835c5ed1ddedf20d531',1,18,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','0d149b90e7394297301c90191ae775f0',1,10,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','0f5264038205edfb1ac05fbb0e8c5e94',1,27,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','18b049cc8d8535787929df716f9f4e68',1,14,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','1aec9c5d0644e11fd9dd0f9fb36009fb',1,17,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','21582c6c30be1217322cdb9aebaf4a59',1,20,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','21cec257feb15bcc84e0acd5b0773883',2,0,19393,128),
('85c2621b0fce09ac51613f18ce135f4b','23a58bf9274bedb19375e527a0744fa9',2,5,19393,0),
('85c2621b0fce09ac51613f18ce135f4b','3676d55f84497cbeadfc614c1b1b62fc',2,15,19393,0),
('85c2621b0fce09ac51613f18ce135f4b','410d98939d4116adb562b97046d2a3eb',1,12,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','4a2028eceac5e1f4d252ea13c71ecec6',1,1,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','4d8b6084f3d167b76cac66a22a91be02',1,24,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','5440e70c43cc02aba90d879c888e6e09',1,4,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','639bae9ac6b3e1a84cebb7b403297b79',1,8,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','681647a719e45584566fe980061fe10d',1,19,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','829a56cc8ffa56209e3a10b80d0bbdf8',1,30,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','8d777f385d3dfec8815d20f7496026dc',2,7,19393,0),
('85c2621b0fce09ac51613f18ce135f4b','8fc42c6ddf9966db3b09e84365034357',3,2,29090,0),
('85c2621b0fce09ac51613f18ce135f4b','a1ec23e9b9ab43a88222d9949ee26499',1,9,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','a2a551a6458a8de22446cc76d639a9e9',2,16,19393,0),
('85c2621b0fce09ac51613f18ce135f4b','aad0cd42d3c8a3b36a2be6a641d0cd53',1,3,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','be5d5d37542d75f93a87094459f76678',1,22,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','d0970d0bb517ca0203cd7c95dd98a8f4',1,31,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','d55669822f1a8cf72ec1911e462a54eb',1,25,9696,0),
('85c2621b0fce09ac51613f18ce135f4b','f970e2767d0cfe75876ea857f92e319b',2,26,19393,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','000500166bc26ce9d248efa151a93742',1,32,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','01d1005bf5dd0c289b1af9226f6a01d5',2,13,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','01fc8dbe01da25daf8fd5da8f519c6a1',3,164,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','02ea2ae2a237c042285e093e6972eaa9',1,31,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','0347b574e0d2e699ffa6216abd44b6dc',1,153,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','05155838d6a9b3ff384a8b247be221b5',1,116,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','060ad00963b820f66e4048a428c8dbd5',1,19,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','0b352de3203b618d4f2e91f0bbb142dd',1,175,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','0cdebd4dc2635cced6099c034960b542',1,35,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','0e4b899600d9dbe31eb6f61080374baa',1,203,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','154d453667082d5297415cabcb7ac0ae',1,173,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','15d72a64dfa9800801dae9a5abc4950c',1,182,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','1679091c5a880faf6fb5e6087eb1b2dc',1,117,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','1718e70ba445df7073e04b1a679d2fa3',1,90,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','18b243c932d6f259d2a0ce658720f41b',1,88,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','193da9b96f9705c746b0943c593bfbf3',1,185,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','1976e926544da8d517bb7a722ce5fc68',2,28,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','1aa39ec59532b438bfa67d6527e10d99',1,124,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','21c5084aeff1e5fbcbaa98b661758382',1,38,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','23860c3722bca6a44358306a395480fd',2,27,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','28ef5e079b0571848c806ff5266c2c22',1,18,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','29b7537f38eb598ebaec123f6a7c6a8e',1,80,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','2fd7cb590fc8e5de760a3a21256b5555',3,111,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','32efcf78f15ffb8500029a8e74c0b8f4',1,168,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','33e26553024adb44e6e95937bc1439fd',1,143,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','358c4c7750d79fd100568536318758ed',1,67,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','3598e4f00157c2446d9ff61be81d66b0',1,155,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','39ec46822b0f6f5eae91475d0960ddd7',1,181,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','3a5afaf5d67c2547a79f0c517e1191f1',2,0,3033,128),
('97b8cd0fe54b6d09a38ff14702afb4bc','434d51c5183af28f7f4ec4661b81397e',1,125,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','49aa1219402b59fa7dd9b894e1101484',1,136,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','49b0be73826dd0f37993e8b19e583f44',1,102,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','4ae07446a1d8ca36a97e34fcfce80376',1,146,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','4c0a1c806189b2c621111acee40217ac',11,0,16682,128),
('97b8cd0fe54b6d09a38ff14702afb4bc','5188aa9e6815c731a69a0c302c772797',1,206,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','5464125f42d78ff58c5a88c3dedf675a',1,66,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','55c013101011f633b2d8b0b3fd27e123',1,189,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','5db97dad4d4d722e4cc31cff4ebda2fe',1,205,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','5e4020157ffb71ed07a530ac5c9c9be6',1,151,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','636d50a77da70596843a5638ac61d2b6',3,17,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','657ae4b9e8b99f712b8f24621483e7a1',1,41,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','65a1fa2f453bc4b96ef8b1b5a267478f',1,68,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','697623632caf407f9bcb5cc2a399de63',1,92,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','6a6f3774bb043964a8817729b501f988',1,5,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','6cb2b035fec9a521c8a8c79ee20e9ac1',1,49,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','6cdc4630ff5785e3cad3d47850021cce',1,177,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','6d07377eb5cd42102c36d2adec8eb7fd',4,0,6066,128),
('97b8cd0fe54b6d09a38ff14702afb4bc','6e9b99b713d2006a61c58f305913b66e',1,45,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','6ec66e124fb93c190e9207b0b82f542a',4,46,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','715a89390c6ba5fb2f93570784ccf6d3',1,42,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','735e3acf03c5919833eb09776229fef4',1,163,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','76671d4b83f6e6f953ea2dfb75ded921',3,109,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','76910c443f73ac1788d6bd692d6f0ce0',1,107,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','76ef63369f7d5b6597a543017e1ef578',1,202,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','778a15406292a461ce949276efcd87a3',3,133,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','7820cd42355d0b56bb26edd33c628c13',1,170,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','79a41c87ab53aba8350287d29a7011af',1,195,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','7cd623f978d45e86a183f38489993e21',1,78,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','7e5187ccd575afcd362ec67efd5891bd',1,76,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','7fa1b37085e839d1de27b470abdf7973',1,158,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','80570bebec5742bf89b3fbf9642cec02',2,3,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','82002249bfc8b93e42f329ab528426b1',1,103,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8867e7959e7070fdf9127554f966eb3f',1,139,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8a1edb7c17ea34190b9aa6a751987d07',4,8,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8a6f503814aa4a7cd863e68c7778fbdb',1,83,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8bcc25c96aa5a71f7a76309077753e67',4,25,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8c8d357b5e872bbacd45197626bd5759',4,94,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8ccb649d8531adae5c2e89610629b12d',1,187,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8f3b0c9cf515520ce0b4b48a3daeb501',1,60,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','8f72382d96d9e4889cc14e35d423bf44',6,16,9099,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','913b9c1b73b00bdcd1107494026d1c89',1,132,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','926e27eecdbc7a18858b3798ba99bddd',1,154,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','94c774b2721ef9f51cc1c7b9df42b07c',1,48,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','959848ca10cc8a60da818ac11523dc63',2,96,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','984eaf792802b84bce30376ec5e56247',1,54,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','98f13708210194c475687be6106a3b84',2,119,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,121,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','a12ace82ecc53103152294f32edc19fe',2,6,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','a249768ea130ced1376e512efff73021',1,190,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','a48a68f037b7ff127cdecac38b2581bd',3,53,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','a5212ecae231b0a7405799192fc34ab5',2,22,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','af85b9ed98481408d4101739fed539d6',7,7,10616,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','b0a00b35f2131ede81d4717282b6a90f',1,56,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','b8bf222bdaf3eb9c6559c0b5386861e4',1,135,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','bd0dd14cd9e91d6290387dd7b66baefb',2,69,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','be43f0cbf4bcbb3ab0d83b14b868920e',1,188,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','beae3de7729a01f28c1a7857dee08ead',1,108,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c16a5320fa475530d9583c34fd356ef5',2,165,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c16ab7b9eb450c2b6a74bbc56ffc2442',1,74,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c2477f223c3c4ca19a5029e0cd91fda8',5,14,7582,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c68c559d956d4ca20f435ed74a6e71e6',4,72,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c6f057b86584942e415435ffb1fa93d4',3,113,4549,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c81e728d9d4c2f636f067f89cc14862c',1,172,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','c92a10324374fac681719d63979d00fe',1,101,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d19f18cfcef6bf11646efd672718c57b',1,166,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d301c2ac0c0c28d573de9c8b2e4ea57c',1,150,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d4fbae6323ac161c03127c31690d81f4',2,24,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d645920e395fedad7bbbed0eca3fe2e0',1,129,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d72e436f8bf8d8982bcdb3f51e356849',1,86,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d74600e380dbf727f67113fd71669d88',14,9,21232,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d78406cbaeb5be8c2ef9dfca493dc55e',1,85,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','d88c2449e1f4aa6a7cdf21932598ce91',8,12,12132,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','dd7d7ea7a3ea82cc1a987a084f03e379',1,71,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','df3df30793210c75e78c66ecb845d3c9',1,200,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e188e9c5f384131b52fd2a30258312d6',2,11,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e1a1ba25715bed51a3b86e54d07bcf20',4,131,6066,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e4da3b7fbbce2345d7772b0674a318d5',2,110,3033,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e58f2b4a9bde8c7c349b44be5b469bb6',1,40,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e651c10fdbc910984f0f1edd22727541',1,193,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','e6f06702c43d31c81cb42967420c0b31',1,10,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','ebb021ec2f9dabb53dcd71109d87c1d5',1,20,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','ebbb763f6bd9ffd6ec8d2a7e9a68e91a',1,148,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','faa078ebcbce40c9dc56e5163430e48a',1,52,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','fb9e0c48b8a116a3da9a28c36bdd6840',1,207,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','fbf72ef07575a3df98f24440047b609a',1,57,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','fc9187af4b3b23c0e44e797fe4ba3ee9',1,138,1516,0),
('97b8cd0fe54b6d09a38ff14702afb4bc','fd5b2e5383df624fab39afadb1b8896a',1,134,1516,0),
('9bd8393860e6e9cf4c907a0919ca687d','01b6e20344b68835c5ed1ddedf20d531',1,30,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','0d149b90e7394297301c90191ae775f0',1,20,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','0e3a8d38d6a037ceca6885c6b654124e',1,27,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','10cd395cf71c18328c863c08e78f3fd0',1,19,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','2b80472febb0c52ab4551deca95dcd7b',1,23,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','2bb3d86d95234affa7c5bd68c4bab606',1,25,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','4015e9ce43edfb0668ddaa973ebc7e87',1,26,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','437b930db84b8079c2dd804a71936b5f',1,33,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','459d9fca17e3a950deae755d13578292',1,16,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','4a2028eceac5e1f4d252ea13c71ecec6',1,8,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','53d670af9bb16ea82e7ef41ee23ec6df',1,29,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','567904efe9e64d9faf3e41ef402cb568',1,24,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','5ed33f7008771c9d49e3716aeaeca581',1,31,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','83ab982dd08483187289a75163dc50fe',1,15,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','878983117a2370e5b702db49786da067',1,21,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','89fe7b5ca56cdee4e750f4eb3ab12fbb',1,34,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','8bf8854bebe108183caeb845c7676ae4',2,4,17297,0),
('9bd8393860e6e9cf4c907a0919ca687d','8fc42c6ddf9966db3b09e84365034357',4,1,32000,0),
('9bd8393860e6e9cf4c907a0919ca687d','91eac053445a914d25ddd441f92f24cc',1,13,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','933dd8674c563081260867dfa95b5e74',1,9,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','a2a551a6458a8de22446cc76d639a9e9',1,12,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','aad0cd42d3c8a3b36a2be6a641d0cd53',1,6,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','b1b9a972ccd8c962a473909b97007eb4',1,2,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','be5d5d37542d75f93a87094459f76678',2,7,17297,0),
('9bd8393860e6e9cf4c907a0919ca687d','ca698f1db3dca4b22a58d2c426ec716e',3,0,25945,128),
('9bd8393860e6e9cf4c907a0919ca687d','d55669822f1a8cf72ec1911e462a54eb',1,14,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','df491a4de50739fa9cffdbd4e3f4b4bb',1,32,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','e6dbca21d4865b265ca2780205b19305',1,17,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','e886b5e8a9e6a8b1a306ac1efb18ec84',1,11,8648,0),
('9bd8393860e6e9cf4c907a0919ca687d','fb5d2d956db4905af044dfb1e0680a95',1,35,8648,0),
('b4b473e088c0a9f40a7eb9053a621871','0b3cfa5de16ad41eedf27d40fd0149d0',2,0,16410,128),
('b4b473e088c0a9f40a7eb9053a621871','232e016a0f0555fc7f8e477f650c94c5',1,24,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','36c3e41a4eef4082ea47cc9494244c79',1,35,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','5cfc1f542032073a69e82c2c7c6a8386',1,31,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','6cb2b035fec9a521c8a8c79ee20e9ac1',1,5,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','6f7748a83b9a124aadf27755faf8a5f4',1,15,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','700541d99871107ff17c418c65ece8c7',1,6,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','719931acac86b6d8a7d5482ca145fe34',1,18,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','7cc82ba62ed3892d8acbe1a73a0cba49',1,19,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','80570bebec5742bf89b3fbf9642cec02',1,29,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','8282252205923a5847a803d007ed0c0e',1,22,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','8cac409b9b51935cca7c7ec697656e80',1,7,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','8cf179ec0fa4b3ce5abe77fdf9deb0b8',2,12,16410,0),
('b4b473e088c0a9f40a7eb9053a621871','8f69d9e05a57132f2d3fd21ca569eebc',1,16,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','8f72382d96d9e4889cc14e35d423bf44',2,9,16410,0),
('b4b473e088c0a9f40a7eb9053a621871','959848ca10cc8a60da818ac11523dc63',1,4,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','984eaf792802b84bce30376ec5e56247',1,8,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','a2c93d508496a6e10ed94b231302fc3a',1,28,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','c68c559d956d4ca20f435ed74a6e71e6',2,0,16410,128),
('b4b473e088c0a9f40a7eb9053a621871','c8e461e773e69f597ca10f66dfc46016',1,32,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','c994344e3f36e9d9a9e97398adf5ce20',1,25,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','d4fbae6323ac161c03127c31690d81f4',1,14,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','d54b7ba27571a2f00b38ed9273b974f2',1,10,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','d74600e380dbf727f67113fd71669d88',1,26,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','e0ba0c0363c5c47bb4c42b39afcbe0ae',6,0,32000,128),
('b4b473e088c0a9f40a7eb9053a621871','e7841e2173994144a0203476d77a72f4',2,30,16410,0),
('b4b473e088c0a9f40a7eb9053a621871','fa350f2393222ede0b459dfa89e1df26',1,23,8205,0),
('b4b473e088c0a9f40a7eb9053a621871','fc9187af4b3b23c0e44e797fe4ba3ee9',2,11,16410,0),
('b676e408624805da6b4c35566cad496c','3adf9b14e32c8e7a8013482c89bd78b8',1,13,10666,0),
('b676e408624805da6b4c35566cad496c','509484d31b4ecf0a63251503d19b88e9',1,20,10666,0),
('b676e408624805da6b4c35566cad496c','5be23b1de1eff5ddf95ff3d5d9a4bd90',1,16,10666,0),
('b676e408624805da6b4c35566cad496c','6178b53b06f14bed62ca36ba066c8862',1,9,10666,0),
('b676e408624805da6b4c35566cad496c','6cdc4630ff5785e3cad3d47850021cce',1,25,10666,0),
('b676e408624805da6b4c35566cad496c','6ec66e124fb93c190e9207b0b82f542a',2,8,21333,0),
('b676e408624805da6b4c35566cad496c','6ed3e17a8745b6beef55c309768c05df',3,0,32000,128),
('b676e408624805da6b4c35566cad496c','7071db26295c44957f44c77f3759aa10',1,10,10666,0),
('b676e408624805da6b4c35566cad496c','77b401c373f3e42e6e873fc3b29a50e0',1,5,10666,0),
('b676e408624805da6b4c35566cad496c','80570bebec5742bf89b3fbf9642cec02',1,22,10666,0),
('b676e408624805da6b4c35566cad496c','8510c43ca591928d86fde94dd386538b',1,18,10666,0),
('b676e408624805da6b4c35566cad496c','87c131a1c1e6f6bdcdf14c8f92104306',1,14,10666,0),
('b676e408624805da6b4c35566cad496c','8a1edb7c17ea34190b9aa6a751987d07',3,0,32000,128),
('b676e408624805da6b4c35566cad496c','8f72382d96d9e4889cc14e35d423bf44',1,15,10666,0),
('b676e408624805da6b4c35566cad496c','959848ca10cc8a60da818ac11523dc63',2,6,21333,0),
('b676e408624805da6b4c35566cad496c','a4ddbadbe786fc766560cb14b16ffc90',1,23,10666,0),
('b676e408624805da6b4c35566cad496c','af1fcc06be6421a2519c0a048a526ba6',1,11,10666,0),
('b676e408624805da6b4c35566cad496c','b33f4c25b86a0df3480941ffa14a0686',1,17,10666,0),
('b676e408624805da6b4c35566cad496c','c1c4b206324f9567d8f593bd0e4d1634',1,24,10666,0),
('b676e408624805da6b4c35566cad496c','c9089f3c9adaf0186f6ffb1ee8d6501c',2,0,21333,128),
('b676e408624805da6b4c35566cad496c','ccf04975637febdf16f9b1ebddffa3dd',1,4,10666,0),
('b676e408624805da6b4c35566cad496c','d71a968296f22a13f920ca7e9e36baa1',1,12,10666,0),
('b676e408624805da6b4c35566cad496c','faf005cd0a28451902235d831661432e',1,26,10666,0),
('bec4701003457746b3e8eb7b62a181cf','01b6e20344b68835c5ed1ddedf20d531',8,66,10322,0),
('bec4701003457746b3e8eb7b62a181cf','06ed9988df31251829e6237a844aa5d3',3,121,3870,0),
('bec4701003457746b3e8eb7b62a181cf','07ccfe360dce69b84595428e2ec1c1cc',1,157,1290,0),
('bec4701003457746b3e8eb7b62a181cf','0931be4cc434934e64b1894aa2dba1ae',8,18,10322,0),
('bec4701003457746b3e8eb7b62a181cf','0b3b97fa66886c5688ee4ae80ec0c3c2',2,204,2580,0),
('bec4701003457746b3e8eb7b62a181cf','0c83f57c786a0b4a39efab23731c7ebc',1,163,1290,0),
('bec4701003457746b3e8eb7b62a181cf','0cc175b9c0f1b6a831c399e269772661',9,16,11612,0),
('bec4701003457746b3e8eb7b62a181cf','0d149b90e7394297301c90191ae775f0',4,8,5161,0),
('bec4701003457746b3e8eb7b62a181cf','0f5264038205edfb1ac05fbb0e8c5e94',1,137,1290,0),
('bec4701003457746b3e8eb7b62a181cf','106a6c241b8797f52e1e77317b96a201',1,52,1290,0),
('bec4701003457746b3e8eb7b62a181cf','12a032ce9179c32a6c7ab397b9d871fa',4,111,5161,0),
('bec4701003457746b3e8eb7b62a181cf','12cba3ee81cf4a793796a51b6327c678',1,160,1290,0),
('bec4701003457746b3e8eb7b62a181cf','12de3a4dab98ef8a7d67aace8150b540',1,235,1290,0),
('bec4701003457746b3e8eb7b62a181cf','13b5bfe96f3e2fe411c9f66f4a582adf',4,5,5161,0),
('bec4701003457746b3e8eb7b62a181cf','162e31afc5ade88a04d3f428e97e8f46',2,205,2580,0),
('bec4701003457746b3e8eb7b62a181cf','1679091c5a880faf6fb5e6087eb1b2dc',1,122,1290,0),
('bec4701003457746b3e8eb7b62a181cf','1e41815a0ec40fdda1523537c23a70da',1,155,1290,0),
('bec4701003457746b3e8eb7b62a181cf','21582c6c30be1217322cdb9aebaf4a59',1,70,1290,0),
('bec4701003457746b3e8eb7b62a181cf','21e119daf697467b14b076f2d5819aec',1,241,1290,0),
('bec4701003457746b3e8eb7b62a181cf','22af645d1859cb5ca6da0c484f1f37ea',2,169,2580,0),
('bec4701003457746b3e8eb7b62a181cf','237c3a9e6f91efa017ad144794777f42',1,245,1290,0),
('bec4701003457746b3e8eb7b62a181cf','2541d938b0a58946090d7abdde0d3890',1,158,1290,0),
('bec4701003457746b3e8eb7b62a181cf','2c61ebff5a7f675451467527df66788d',4,30,5161,0),
('bec4701003457746b3e8eb7b62a181cf','3103a7d8f63cb184287c558ca51c6160',1,189,1290,0),
('bec4701003457746b3e8eb7b62a181cf','32fa6e1b78a9d4028953e60564a2aa4c',1,90,1290,0),
('bec4701003457746b3e8eb7b62a181cf','3413e60c4be854b769e90cfa4cb1730d',1,67,1290,0),
('bec4701003457746b3e8eb7b62a181cf','35ea8083fa3fa79e8294cb56d079387d',1,35,1290,0),
('bec4701003457746b3e8eb7b62a181cf','39c8942e1038872a822c0dc75eedbde3',3,48,3870,0),
('bec4701003457746b3e8eb7b62a181cf','3c8925c7fb2d563070c4c7aa96954e92',1,243,1290,0),
('bec4701003457746b3e8eb7b62a181cf','4015e9ce43edfb0668ddaa973ebc7e87',1,217,1290,0),
('bec4701003457746b3e8eb7b62a181cf','4061838f4395ef541fb1b3f07e42bc21',1,192,1290,0),
('bec4701003457746b3e8eb7b62a181cf','44fdec47036f482b68b748f9d786801b',1,145,1290,0),
('bec4701003457746b3e8eb7b62a181cf','459d9fca17e3a950deae755d13578292',1,239,1290,0),
('bec4701003457746b3e8eb7b62a181cf','467b6140fe3bb958f2332983914de787',1,185,1290,0),
('bec4701003457746b3e8eb7b62a181cf','46b3931b9959c927df4fc65fdee94b07',1,11,1290,0),
('bec4701003457746b3e8eb7b62a181cf','46c48bec0d282018b9d167eef7711b2c',1,115,1290,0),
('bec4701003457746b3e8eb7b62a181cf','48bb6e862e54f2a795ffc4e541caed4d',1,6,1290,0),
('bec4701003457746b3e8eb7b62a181cf','49256b9819abacbb8e6e031a03abe81b',1,188,1290,0),
('bec4701003457746b3e8eb7b62a181cf','4a2028eceac5e1f4d252ea13c71ecec6',3,14,3870,0),
('bec4701003457746b3e8eb7b62a181cf','53b9e9679a8ea25880376080b76f98ad',1,203,1290,0),
('bec4701003457746b3e8eb7b62a181cf','53d670af9bb16ea82e7ef41ee23ec6df',1,34,1290,0),
('bec4701003457746b3e8eb7b62a181cf','567904efe9e64d9faf3e41ef402cb568',2,153,2580,0),
('bec4701003457746b3e8eb7b62a181cf','5dd2199ad68327cc76d583b057aee7d5',1,78,1290,0),
('bec4701003457746b3e8eb7b62a181cf','61e3bbe3ca4c8bc38e142b139a346b46',1,173,1290,0),
('bec4701003457746b3e8eb7b62a181cf','62cc0b4ebb0b57b40778179234246c38',10,32,12903,0),
('bec4701003457746b3e8eb7b62a181cf','632a2406bbcbcd553eec45ac14b40a0a',1,190,1290,0),
('bec4701003457746b3e8eb7b62a181cf','639bae9ac6b3e1a84cebb7b403297b79',19,10,24516,0),
('bec4701003457746b3e8eb7b62a181cf','657f8b8da628ef83cf69101b6817150a',1,200,1290,0),
('bec4701003457746b3e8eb7b62a181cf','67e92c8765a9bc7fb2d335c459de9eb5',3,50,3870,0),
('bec4701003457746b3e8eb7b62a181cf','71860c77c6745379b0d44304d66b6a13',1,3,1290,0),
('bec4701003457746b3e8eb7b62a181cf','7761127a460aaf290ed953098284dd1a',1,130,1290,0),
('bec4701003457746b3e8eb7b62a181cf','7d0db380a5b95a8ba1da0bca241abda1',1,150,1290,0),
('bec4701003457746b3e8eb7b62a181cf','7e3f660480ab1640de8024c200b5a4d3',4,23,5161,0),
('bec4701003457746b3e8eb7b62a181cf','83ab982dd08483187289a75163dc50fe',2,43,2580,0),
('bec4701003457746b3e8eb7b62a181cf','847c8ebb0e477b63fbc34fc0cd42b404',1,107,1290,0),
('bec4701003457746b3e8eb7b62a181cf','84cdc76cabf41bd7c961f6ab12f117d8',2,102,2580,0),
('bec4701003457746b3e8eb7b62a181cf','84eeb81e61c76ad3f4103b0b051c7021',2,28,2580,0),
('bec4701003457746b3e8eb7b62a181cf','8a6f503814aa4a7cd863e68c7778fbdb',1,84,1290,0),
('bec4701003457746b3e8eb7b62a181cf','8bf8854bebe108183caeb845c7676ae4',1,240,1290,0),
('bec4701003457746b3e8eb7b62a181cf','8cd283d8b7bacc277f2bae5e26ce6d1e',1,110,1290,0),
('bec4701003457746b3e8eb7b62a181cf','8fc42c6ddf9966db3b09e84365034357',6,25,7741,0),
('bec4701003457746b3e8eb7b62a181cf','933dd8674c563081260867dfa95b5e74',1,59,1290,0),
('bec4701003457746b3e8eb7b62a181cf','944ba223a5c1b5f4b495708e7cd5ee37',1,213,1290,0),
('bec4701003457746b3e8eb7b62a181cf','9726255eec083aa56dc0449a21b33190',2,99,2580,0),
('bec4701003457746b3e8eb7b62a181cf','98f13708210194c475687be6106a3b84',2,124,2580,0),
('bec4701003457746b3e8eb7b62a181cf','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,126,1290,0),
('bec4701003457746b3e8eb7b62a181cf','9e925e9341b490bfd3b4c4ca3b0c1ef2',2,2,2580,0),
('bec4701003457746b3e8eb7b62a181cf','a2a551a6458a8de22446cc76d639a9e9',6,4,7741,0),
('bec4701003457746b3e8eb7b62a181cf','a2b8ed9c305b8ea86116b603cca78a97',1,75,1290,0),
('bec4701003457746b3e8eb7b62a181cf','a363b8d13575101a0226e8d0d054f2e7',2,141,2580,0),
('bec4701003457746b3e8eb7b62a181cf','a53108f7543b75adbb34afc035d4cdf6',1,31,1290,0),
('bec4701003457746b3e8eb7b62a181cf','a8c478391757a06ee53d8aec274b31a6',1,9,1290,0),
('bec4701003457746b3e8eb7b62a181cf','a9f0e61a137d86aa9db53465e0801612',1,244,1290,0),
('bec4701003457746b3e8eb7b62a181cf','aad0cd42d3c8a3b36a2be6a641d0cd53',2,26,2580,0),
('bec4701003457746b3e8eb7b62a181cf','addec426932e71323700afa1911f8f1c',1,129,1290,0),
('bec4701003457746b3e8eb7b62a181cf','b02a45a596bfb86fe2578bde75ff5444',3,98,3870,0),
('bec4701003457746b3e8eb7b62a181cf','b1bc248a7ff2b2e95569f56de68615df',1,206,1290,0),
('bec4701003457746b3e8eb7b62a181cf','b326b5062b2f0e69046810717534cb09',1,47,1290,0),
('bec4701003457746b3e8eb7b62a181cf','b403d3f0efbf4cb850d2d543758cb57c',1,53,1290,0),
('bec4701003457746b3e8eb7b62a181cf','b5eda0a74558a342cf659187f06f746f',2,147,2580,0),
('bec4701003457746b3e8eb7b62a181cf','b6f3b4b5b8b20e28fb9763001bb4b079',1,93,1290,0),
('bec4701003457746b3e8eb7b62a181cf','b80bb7740288fda1f201890375a60c8f',1,77,1290,0),
('bec4701003457746b3e8eb7b62a181cf','bd5bb0ca70a22a3725257f45e0e9f549',1,208,1290,0),
('bec4701003457746b3e8eb7b62a181cf','be9bd32df53512c2246361c712a26051',1,96,1290,0),
('bec4701003457746b3e8eb7b62a181cf','c16a5320fa475530d9583c34fd356ef5',2,175,2580,0),
('bec4701003457746b3e8eb7b62a181cf','c2f28daa81da003f46d3865ae0362d5c',3,0,3870,128),
('bec4701003457746b3e8eb7b62a181cf','c327b49efdca2668f28cd7b4beee54b3',1,144,1290,0),
('bec4701003457746b3e8eb7b62a181cf','c6f057b86584942e415435ffb1fa93d4',5,120,6451,0),
('bec4701003457746b3e8eb7b62a181cf','c7c3169c21f1d92e9577871831d067c8',1,223,1290,0),
('bec4701003457746b3e8eb7b62a181cf','c81e728d9d4c2f636f067f89cc14862c',1,184,1290,0),
('bec4701003457746b3e8eb7b62a181cf','c9f0f895fb98ab9159f51fd0297e236d',1,220,1290,0),
('bec4701003457746b3e8eb7b62a181cf','d056025fbea3c4700729c5b96b0ff97b',1,81,1290,0),
('bec4701003457746b3e8eb7b62a181cf','d55669822f1a8cf72ec1911e462a54eb',4,42,5161,0),
('bec4701003457746b3e8eb7b62a181cf','d645920e395fedad7bbbed0eca3fe2e0',1,133,1290,0),
('bec4701003457746b3e8eb7b62a181cf','d78406cbaeb5be8c2ef9dfca493dc55e',1,83,1290,0),
('bec4701003457746b3e8eb7b62a181cf','d850f04cdb48312a9be171e214c0b4ee',1,218,1290,0),
('bec4701003457746b3e8eb7b62a181cf','d98a07f84921b24ee30f86fd8cd85c3c',4,24,5161,0),
('bec4701003457746b3e8eb7b62a181cf','db88a0257c220dbfdd2e40f6152d6a8d',3,103,3870,0),
('bec4701003457746b3e8eb7b62a181cf','e2eff6c2dafd909df8508f891b385d88',1,100,1290,0),
('bec4701003457746b3e8eb7b62a181cf','e4da3b7fbbce2345d7772b0674a318d5',4,117,5161,0),
('bec4701003457746b3e8eb7b62a181cf','e72f4545eb68c96c754f91fc01573517',2,152,2580,0),
('bec4701003457746b3e8eb7b62a181cf','e81c4e4f2b7b93b481e13a8553c2ae1b',2,79,2580,0),
('bec4701003457746b3e8eb7b62a181cf','e877c56e4fb621e81fd30dbd114a545b',5,39,6451,0),
('bec4701003457746b3e8eb7b62a181cf','ea170e2cafb1337755c8b3d5ae4437f4',1,231,1290,0),
('bec4701003457746b3e8eb7b62a181cf','ea9f91b2cda019730f2891bd12a7a4d6',1,195,1290,0),
('bec4701003457746b3e8eb7b62a181cf','ebed715e82a0a0f3e950ef6565cdc4a8',1,60,1290,0),
('bec4701003457746b3e8eb7b62a181cf','ecae13117d6f0584c25a9da6c8f8415e',1,7,1290,0),
('bec4701003457746b3e8eb7b62a181cf','ed2b5c0139cec8ad2873829dc1117d50',2,108,2580,0),
('bec4701003457746b3e8eb7b62a181cf','ee1150845fa3041ceb3a3fcdbe42d68a',1,228,1290,0),
('bec4701003457746b3e8eb7b62a181cf','ef56b0b0ddb93c2885892c06be830c68',1,104,1290,0),
('bec4701003457746b3e8eb7b62a181cf','f5d7e2532cc9ad16bc2a41222d76f269',7,0,9032,128),
('bec4701003457746b3e8eb7b62a181cf','f6f7fec07f372b7bd5eb196bbca0f3f4',1,215,1290,0),
('bec4701003457746b3e8eb7b62a181cf','f75cac02116d825a000c33a7c326af37',1,139,1290,0),
('bec4701003457746b3e8eb7b62a181cf','f962bed5616612c8c7053f6e97e72b12',1,176,1290,0),
('bec4701003457746b3e8eb7b62a181cf','f97c5d29941bfb1b2fdab0874906ab82',2,56,2580,0),
('bec4701003457746b3e8eb7b62a181cf','ff1ccf57e98c817df1efcd9fe44a8aeb',4,140,5161,0),
('bf10d741ea1a3f66bd8f054520f99b4f','01fc8dbe01da25daf8fd5da8f519c6a1',4,21,11636,0),
('bf10d741ea1a3f66bd8f054520f99b4f','0b9a34b7bbce73bb011739b229debda7',1,12,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','11efd54a5c384515bfd9cb473eef8ac5',1,77,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','1679091c5a880faf6fb5e6087eb1b2dc',1,47,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','1c6154a8b601535135a2d76cd4ffdecb',1,40,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','2116c221c2db2f9b400349baa6e3d7d1',1,27,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','21c5084aeff1e5fbcbaa98b661758382',1,74,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','2694d7d3321f7a44a04b461e1955c8d8',4,1,11636,0),
('bf10d741ea1a3f66bd8f054520f99b4f','31783e73d792207712a1add81d10cbe9',1,31,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','33e75ff09dd601bbe69f351039152189',1,79,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','3eec4e89e171cfb8c51262fe749722e6',1,0,2909,128),
('bf10d741ea1a3f66bd8f054520f99b4f','45c48cce2e2d7fbdea1afc51c7c6ad26',1,55,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','47a708336d417719c1a1e942ff7da27d',1,106,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','4893680cd9e9b799a7b8de8e14ea804d',1,73,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','5592932dd92ccce1ceef6f3c5fbdede7',1,105,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','5ad960d224f349e7d93b8f38e96886db',1,36,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','5be23b1de1eff5ddf95ff3d5d9a4bd90',1,5,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','5cfc1f542032073a69e82c2c7c6a8386',1,45,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','5f38f7089756746b5389e8e7d8645c61',1,83,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','6040c69f06d0c61ef4dc25567bd0213c',1,108,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','6094a70fb9532dfc3b1a9133364f3f7e',1,3,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','624f02e348502edb4269ed73e2e14545',3,42,8727,0),
('bf10d741ea1a3f66bd8f054520f99b4f','6cb2b035fec9a521c8a8c79ee20e9ac1',1,97,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','6e9b99b713d2006a61c58f305913b66e',1,28,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','6ec66e124fb93c190e9207b0b82f542a',2,18,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','7071db26295c44957f44c77f3759aa10',1,7,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','72dacc9d1e0082d557ac8c1a4543a737',2,35,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','7820cd42355d0b56bb26edd33c628c13',2,20,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','88ae91df0447a7b6e338a3d65ce73be3',1,26,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','8a1a17e049499fb3b978d1e11b4f7693',1,43,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','8a1edb7c17ea34190b9aa6a751987d07',2,9,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','8f3b0c9cf515520ce0b4b48a3daeb501',1,19,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','8f72382d96d9e4889cc14e35d423bf44',2,70,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','93d4baf39753fa03a63feee313b022b0',1,78,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','959848ca10cc8a60da818ac11523dc63',5,39,14545,0),
('bf10d741ea1a3f66bd8f054520f99b4f','98f13708210194c475687be6106a3b84',1,63,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','9bf31c7ff062936a96d3c8bd1f8f2ff3',1,32,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','9f62b8625f914a002496335037e9ad97',1,11,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','a3c222e464ac4c7fc64d8686ed379439',1,30,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','a5212ecae231b0a7405799192fc34ab5',3,50,8727,0),
('bf10d741ea1a3f66bd8f054520f99b4f','a87ff679a2f3e71d9181a67b7542122c',1,22,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','ac29e4af163e60052daea96214151601',1,44,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','af85b9ed98481408d4101739fed539d6',3,14,8727,0),
('bf10d741ea1a3f66bd8f054520f99b4f','b2ae2cd3f4143bf192efb35bb9e7d369',3,23,8727,0),
('bf10d741ea1a3f66bd8f054520f99b4f','b6d767d2f8ed5d21a44b0e5886680cb9',1,0,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','bae2084bfdeaa3f6d8428ecbb0baf7da',1,13,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','bae3d929b274a4cd35c38fe92f059f1a',1,38,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','be43f0cbf4bcbb3ab0d83b14b868920e',1,17,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c048177706eb0476cea140a8b54eaca8',1,80,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c1f7ed800b498c3e7d5ee7f3cbdedc63',2,90,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c4ca4238a0b923820dcc509a6f75849b',1,93,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c68c559d956d4ca20f435ed74a6e71e6',2,4,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c8b6cb5a4739ab2974c13bc3b7887758',1,85,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','c92a10324374fac681719d63979d00fe',4,2,11636,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d4fbae6323ac161c03127c31690d81f4',5,15,14545,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d6145d469d21cc6a3c808862fc17d089',2,16,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d6327112b02e4af370dae5ceac67f6e5',1,102,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d7427581d459b8812a848189f4ea3636',1,6,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','d74600e380dbf727f67113fd71669d88',11,8,32000,0),
('bf10d741ea1a3f66bd8f054520f99b4f','dde4bab04145ef8852c840d66cd2f07b',1,24,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','e0ba0c0363c5c47bb4c42b39afcbe0ae',2,86,5818,0),
('bf10d741ea1a3f66bd8f054520f99b4f','e23670e9a137bdfe52b8a3a27797a450',1,52,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','ebb021ec2f9dabb53dcd71109d87c1d5',1,76,2909,0),
('bf10d741ea1a3f66bd8f054520f99b4f','fc9187af4b3b23c0e44e797fe4ba3ee9',3,71,8727,0),
('ca9fd685b16e5922e940b713a6166e7f','02f12e93b2441290199a82ec7c270f5b',1,20,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','04a481486dd84d7c8bfdfc89d38136a6',1,14,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','2f517001fcdc575005781fd245125e75',1,5,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','313ab1575a0de48f02ee31f281346eee',1,16,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','33e26553024adb44e6e95937bc1439fd',1,7,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','42ddcea8b7d1fd6b522b633c9cac018e',1,9,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','470773b77a7114d03daa3480a975b8c0',1,10,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','6ec66e124fb93c190e9207b0b82f542a',1,17,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','7848ee4d5502d6243eaa56ac7270da02',1,22,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','8f72382d96d9e4889cc14e35d423bf44',1,13,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','92eb9d8343658eafaae461d6276df50c',1,15,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','ab431ce8ae539a4bf0f21c2f5fcfe0cf',3,0,32000,128),
('ca9fd685b16e5922e940b713a6166e7f','c1c4b206324f9567d8f593bd0e4d1634',1,12,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','c55ef437cbcc4d74946ba1ce40b31e6d',1,4,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','c68c559d956d4ca20f435ed74a6e71e6',1,19,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','d3d08f32ecb981f9bf60e43277e93177',1,8,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','d74600e380dbf727f67113fd71669d88',2,0,24615,128),
('ca9fd685b16e5922e940b713a6166e7f','def87c3849a544babc82c3fc4e84a695',2,18,24615,0),
('ca9fd685b16e5922e940b713a6166e7f','f057f5ccb87a310534b9dda3a69a72c4',1,6,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','fa350f2393222ede0b459dfa89e1df26',1,11,12307,0),
('ca9fd685b16e5922e940b713a6166e7f','fc0f4646481d70f1b597b52204c360eb',2,0,24615,128),
('d031f71935b894cc76f91a35ad5e466a','0cc175b9c0f1b6a831c399e269772661',1,23,9411,0),
('d031f71935b894cc76f91a35ad5e466a','0d149b90e7394297301c90191ae775f0',1,20,9411,0),
('d031f71935b894cc76f91a35ad5e466a','13b5bfe96f3e2fe411c9f66f4a582adf',1,16,9411,0),
('d031f71935b894cc76f91a35ad5e466a','1f5f6080965ed6d0a90e6b9ec599e441',1,10,9411,0),
('d031f71935b894cc76f91a35ad5e466a','27e1eb6ed60750644938070d3893555e',1,21,9411,0),
('d031f71935b894cc76f91a35ad5e466a','35661b0f1f47e1023ec3dfd336c62bd7',1,30,9411,0),
('d031f71935b894cc76f91a35ad5e466a','52a1c95fd889c4a3b00f33472a845157',1,27,9411,0),
('d031f71935b894cc76f91a35ad5e466a','567904efe9e64d9faf3e41ef402cb568',1,19,9411,0),
('d031f71935b894cc76f91a35ad5e466a','5ef76d30bf9232902687324b5bfa0bd2',2,0,18823,128),
('d031f71935b894cc76f91a35ad5e466a','6c92285fa6d3e827b198d120ea3ac674',1,13,9411,0),
('d031f71935b894cc76f91a35ad5e466a','6f493bf6f3beb9d46a9c649d2f7ddd29',3,0,28235,128),
('d031f71935b894cc76f91a35ad5e466a','755f85c2723bb39381c7379a604160d8',1,17,9411,0),
('d031f71935b894cc76f91a35ad5e466a','8b7af514f25f1f9456dcd10d2337f753',1,6,9411,0),
('d031f71935b894cc76f91a35ad5e466a','8bf8854bebe108183caeb845c7676ae4',3,0,28235,128),
('d031f71935b894cc76f91a35ad5e466a','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,15,9411,0),
('d031f71935b894cc76f91a35ad5e466a','8fc42c6ddf9966db3b09e84365034357',4,3,32000,0),
('d031f71935b894cc76f91a35ad5e466a','98defd6ee70dfb1dea416cecdf391f58',1,8,9411,0),
('d031f71935b894cc76f91a35ad5e466a','9e925e9341b490bfd3b4c4ca3b0c1ef2',1,7,9411,0),
('d031f71935b894cc76f91a35ad5e466a','a2a551a6458a8de22446cc76d639a9e9',2,9,18823,0),
('d031f71935b894cc76f91a35ad5e466a','b9b9e36c1a5d1be22158df398f2e29b8',2,24,18823,0),
('d031f71935b894cc76f91a35ad5e466a','bb3ccd5881d651448ded1dac904054ac',1,12,9411,0),
('d031f71935b894cc76f91a35ad5e466a','d98a07f84921b24ee30f86fd8cd85c3c',1,22,9411,0),
('d031f71935b894cc76f91a35ad5e466a','ecee7df9bbac50b9b428483bfea1dd7c',1,18,9411,0),
('d031f71935b894cc76f91a35ad5e466a','ed2b5c0139cec8ad2873829dc1117d50',1,5,9411,0),
('d2b728c29c935917865a91198146007e','0b545251ae2a1ce47d189c39bc1b91bc',1,4,9411,0),
('d2b728c29c935917865a91198146007e','0e4b899600d9dbe31eb6f61080374baa',1,19,9411,0),
('d2b728c29c935917865a91198146007e','1976e926544da8d517bb7a722ce5fc68',1,10,9411,0),
('d2b728c29c935917865a91198146007e','23860c3722bca6a44358306a395480fd',1,9,9411,0),
('d2b728c29c935917865a91198146007e','50ea87f4ddc58f228221d3b6bcad462b',2,0,18823,128),
('d2b728c29c935917865a91198146007e','5188aa9e6815c731a69a0c302c772797',1,22,9411,0),
('d2b728c29c935917865a91198146007e','55c013101011f633b2d8b0b3fd27e123',1,26,9411,0),
('d2b728c29c935917865a91198146007e','5a0f33b732e7824bd6477cbb1ee20c64',1,31,9411,0),
('d2b728c29c935917865a91198146007e','5db97dad4d4d722e4cc31cff4ebda2fe',1,21,9411,0),
('d2b728c29c935917865a91198146007e','6ec66e124fb93c190e9207b0b82f542a',1,5,9411,0),
('d2b728c29c935917865a91198146007e','76671d4b83f6e6f953ea2dfb75ded921',1,20,9411,0),
('d2b728c29c935917865a91198146007e','839d2f69c685976fdfc9a403d0aa9921',1,16,9411,0),
('d2b728c29c935917865a91198146007e','8a1edb7c17ea34190b9aa6a751987d07',2,6,18823,0),
('d2b728c29c935917865a91198146007e','8d307a36f1482990b806d415f85fff86',1,2,9411,0),
('d2b728c29c935917865a91198146007e','8f72382d96d9e4889cc14e35d423bf44',1,28,9411,0),
('d2b728c29c935917865a91198146007e','b550a1f8cb36a6cad7477f4a8ac18f48',1,24,9411,0),
('d2b728c29c935917865a91198146007e','ba2b767d7dfa81d754fa0b8ea4692eb7',1,27,9411,0),
('d2b728c29c935917865a91198146007e','bb9f601ba081ab8d336a14a697048cb0',2,0,18823,128),
('d2b728c29c935917865a91198146007e','bd5bb0ca70a22a3725257f45e0e9f549',1,29,9411,0),
('d2b728c29c935917865a91198146007e','c2477f223c3c4ca19a5029e0cd91fda8',1,25,9411,0),
('d2b728c29c935917865a91198146007e','c68c559d956d4ca20f435ed74a6e71e6',1,17,9411,0),
('d2b728c29c935917865a91198146007e','c6f057b86584942e415435ffb1fa93d4',1,30,9411,0),
('d2b728c29c935917865a91198146007e','c91497eaedfc46b7398ef737efc428e0',1,15,9411,0),
('d2b728c29c935917865a91198146007e','d74600e380dbf727f67113fd71669d88',4,3,32000,0),
('d2b728c29c935917865a91198146007e','e6f06702c43d31c81cb42967420c0b31',2,8,18823,0),
('d2b728c29c935917865a91198146007e','f318725c1410c1d610689d723cdd855c',1,13,9411,0),
('d2b728c29c935917865a91198146007e','fb9e0c48b8a116a3da9a28c36bdd6840',1,23,9411,0),
('d3c7afff432dc4a8674da3b6cfcc9624','01b6e20344b68835c5ed1ddedf20d531',1,13,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','05b1aee1a08b2265d582914c2e1293d1',1,12,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','0d149b90e7394297301c90191ae775f0',1,15,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','0f5659687e42a1bb10aff6af0ca58adf',1,20,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','13b5bfe96f3e2fe411c9f66f4a582adf',1,6,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','3309a7a7941818e131b4dfb9a6349914',1,16,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','4015e9ce43edfb0668ddaa973ebc7e87',1,5,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','48bb6e862e54f2a795ffc4e541caed4d',2,7,26666,0),
('d3c7afff432dc4a8674da3b6cfcc9624','4f09daa9d95bcb166a302407a0e0babe',1,17,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','52a1c95fd889c4a3b00f33472a845157',2,0,26666,128),
('d3c7afff432dc4a8674da3b6cfcc9624','9cc49ff7cdca6cb5a0646f1e962943a4',1,18,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','a2a551a6458a8de22446cc76d639a9e9',1,11,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','aad0cd42d3c8a3b36a2be6a641d0cd53',2,0,26666,128),
('d3c7afff432dc4a8674da3b6cfcc9624','b3b32a2d422265cd25c3323ed0157f81',1,4,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,3,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','be5d5d37542d75f93a87094459f76678',1,19,13333,0),
('d3c7afff432dc4a8674da3b6cfcc9624','e6f06702c43d31c81cb42967420c0b31',2,0,26666,128),
('d3c7afff432dc4a8674da3b6cfcc9624','ecae13117d6f0584c25a9da6c8f8415e',3,8,32000,0),
('e45333e70f61f6118c6492c55e8605b9','0d149b90e7394297301c90191ae775f0',1,17,13913,0),
('e45333e70f61f6118c6492c55e8605b9','10cd395cf71c18328c863c08e78f3fd0',2,0,27826,128),
('e45333e70f61f6118c6492c55e8605b9','13b5bfe96f3e2fe411c9f66f4a582adf',1,14,13913,0),
('e45333e70f61f6118c6492c55e8605b9','4015e9ce43edfb0668ddaa973ebc7e87',1,2,13913,0),
('e45333e70f61f6118c6492c55e8605b9','46b3931b9959c927df4fc65fdee94b07',1,19,13913,0),
('e45333e70f61f6118c6492c55e8605b9','48bb6e862e54f2a795ffc4e541caed4d',1,15,13913,0),
('e45333e70f61f6118c6492c55e8605b9','5440e70c43cc02aba90d879c888e6e09',1,6,13913,0),
('e45333e70f61f6118c6492c55e8605b9','639bae9ac6b3e1a84cebb7b403297b79',1,8,13913,0),
('e45333e70f61f6118c6492c55e8605b9','71860c77c6745379b0d44304d66b6a13',1,12,13913,0),
('e45333e70f61f6118c6492c55e8605b9','7c4f29407893c334a6cb7a87bf045c0d',1,9,13913,0),
('e45333e70f61f6118c6492c55e8605b9','8fc42c6ddf9966db3b09e84365034357',1,4,13913,0),
('e45333e70f61f6118c6492c55e8605b9','97bc592b27a9ada2d9a4bb418ed0ebed',1,10,13913,0),
('e45333e70f61f6118c6492c55e8605b9','a2a551a6458a8de22446cc76d639a9e9',2,13,27826,0),
('e45333e70f61f6118c6492c55e8605b9','aad0cd42d3c8a3b36a2be6a641d0cd53',1,5,13913,0),
('e45333e70f61f6118c6492c55e8605b9','bd4c4ea1b44a8ff2afa18dfd261ec2c8',1,1,13913,0),
('e45333e70f61f6118c6492c55e8605b9','d55669822f1a8cf72ec1911e462a54eb',1,7,13913,0),
('e45333e70f61f6118c6492c55e8605b9','d624e01f1ab405400b5cb596e45c6fc3',1,21,13913,0),
('e45333e70f61f6118c6492c55e8605b9','e64c3132023b29762b354a750b474c53',1,3,13913,0),
('e45333e70f61f6118c6492c55e8605b9','ecae13117d6f0584c25a9da6c8f8415e',1,16,13913,0),
('e45333e70f61f6118c6492c55e8605b9','f5d7e2532cc9ad16bc2a41222d76f269',1,20,13913,0),
('e45333e70f61f6118c6492c55e8605b9','f97c5d29941bfb1b2fdab0874906ab82',1,11,13913,0),
('ec2f2d3462894284b37105ddedffd64c','1038fe0a61dc0a70212f8845171167b0',1,12,13333,0),
('ec2f2d3462894284b37105ddedffd64c','21c5084aeff1e5fbcbaa98b661758382',1,13,13333,0),
('ec2f2d3462894284b37105ddedffd64c','43dc06f87883e446a94dbfd78d833852',1,16,13333,0),
('ec2f2d3462894284b37105ddedffd64c','59ee99bd85013d119227d6f93de6155d',1,14,13333,0),
('ec2f2d3462894284b37105ddedffd64c','6ec66e124fb93c190e9207b0b82f542a',2,5,26666,0),
('ec2f2d3462894284b37105ddedffd64c','80570bebec5742bf89b3fbf9642cec02',2,8,26666,0),
('ec2f2d3462894284b37105ddedffd64c','8a1edb7c17ea34190b9aa6a751987d07',1,4,13333,0),
('ec2f2d3462894284b37105ddedffd64c','959848ca10cc8a60da818ac11523dc63',1,3,13333,0),
('ec2f2d3462894284b37105ddedffd64c','984eaf792802b84bce30376ec5e56247',1,9,13333,0),
('ec2f2d3462894284b37105ddedffd64c','a249768ea130ced1376e512efff73021',4,0,32000,128),
('ec2f2d3462894284b37105ddedffd64c','a5212ecae231b0a7405799192fc34ab5',1,15,13333,0),
('ec2f2d3462894284b37105ddedffd64c','b39a10c3757e6c589ea4fe4db9f04cc9',1,21,13333,0),
('ec2f2d3462894284b37105ddedffd64c','be43f0cbf4bcbb3ab0d83b14b868920e',1,2,13333,0),
('ec2f2d3462894284b37105ddedffd64c','c1e9bbd19a22e89056f55541cc14a9f1',1,6,13333,0),
('ec2f2d3462894284b37105ddedffd64c','c68c559d956d4ca20f435ed74a6e71e6',1,18,13333,0),
('ec2f2d3462894284b37105ddedffd64c','d74600e380dbf727f67113fd71669d88',1,7,13333,0),
('ec2f2d3462894284b37105ddedffd64c','e6f06702c43d31c81cb42967420c0b31',1,20,13333,0),
('ec2f2d3462894284b37105ddedffd64c','f8dbe7019222241d15ac0a1c3f28a6a0',1,22,13333,0),
('ec2f2d3462894284b37105ddedffd64c','fdd0f1186c86fe0da3e761f32e50ed55',1,19,13333,0),
('f3a121399cb34f4d849532713eec687b','01b6e20344b68835c5ed1ddedf20d531',1,6,6530,0),
('f3a121399cb34f4d849532713eec687b','0b3b97fa66886c5688ee4ae80ec0c3c2',1,32,6530,0),
('f3a121399cb34f4d849532713eec687b','0cc175b9c0f1b6a831c399e269772661',4,15,26122,0),
('f3a121399cb34f4d849532713eec687b','0d149b90e7394297301c90191ae775f0',1,41,6530,0),
('f3a121399cb34f4d849532713eec687b','0ff85bf08b1dda54ff95e390af1d9b99',2,0,13061,128),
('f3a121399cb34f4d849532713eec687b','12a032ce9179c32a6c7ab397b9d871fa',1,12,6530,0),
('f3a121399cb34f4d849532713eec687b','13b5bfe96f3e2fe411c9f66f4a582adf',1,28,6530,0),
('f3a121399cb34f4d849532713eec687b','18218139eec55d83cf82679934e5cd75',1,39,6530,0),
('f3a121399cb34f4d849532713eec687b','1de9b0a30075ae8c303eb420c103c320',1,17,6530,0),
('f3a121399cb34f4d849532713eec687b','388a56dbb62a010dc26a378981346247',1,19,6530,0),
('f3a121399cb34f4d849532713eec687b','39c8942e1038872a822c0dc75eedbde3',1,24,6530,0),
('f3a121399cb34f4d849532713eec687b','4245bf56d28f22197a4b30b46c809626',2,0,13061,128),
('f3a121399cb34f4d849532713eec687b','492bd93456b81ad92f61e8891174ed04',1,27,6530,0),
('f3a121399cb34f4d849532713eec687b','4a2028eceac5e1f4d252ea13c71ecec6',1,45,6530,0),
('f3a121399cb34f4d849532713eec687b','53d670af9bb16ea82e7ef41ee23ec6df',1,13,6530,0),
('f3a121399cb34f4d849532713eec687b','589b397ed82131bf51acdf63521c2df5',1,5,6530,0),
('f3a121399cb34f4d849532713eec687b','599eba19aa93a929cb8589f148b8a6c4',1,16,6530,0),
('f3a121399cb34f4d849532713eec687b','5ef76d30bf9232902687324b5bfa0bd2',1,14,6530,0),
('f3a121399cb34f4d849532713eec687b','62cc0b4ebb0b57b40778179234246c38',1,29,6530,0),
('f3a121399cb34f4d849532713eec687b','639bae9ac6b3e1a84cebb7b403297b79',1,44,6530,0),
('f3a121399cb34f4d849532713eec687b','676c0f8e5f9d2ca2b0b70ad3169d10ae',1,46,6530,0),
('f3a121399cb34f4d849532713eec687b','71860c77c6745379b0d44304d66b6a13',1,26,6530,0),
('f3a121399cb34f4d849532713eec687b','7b7813f00f42b7e5366e7065aaa798c6',1,11,6530,0),
('f3a121399cb34f4d849532713eec687b','8ab87d4fb3600cc53fc0c5c958a250b1',1,40,6530,0),
('f3a121399cb34f4d849532713eec687b','910955a907e739b81ec8855763108a29',1,7,6530,0),
('f3a121399cb34f4d849532713eec687b','98defd6ee70dfb1dea416cecdf391f58',1,3,6530,0),
('f3a121399cb34f4d849532713eec687b','9e925e9341b490bfd3b4c4ca3b0c1ef2',1,2,6530,0),
('f3a121399cb34f4d849532713eec687b','a2a551a6458a8de22446cc76d639a9e9',1,4,6530,0),
('f3a121399cb34f4d849532713eec687b','a36e1b5a359678cc89110d27f81fd1f4',1,8,6530,0),
('f3a121399cb34f4d849532713eec687b','bd5bb0ca70a22a3725257f45e0e9f549',1,34,6530,0),
('f3a121399cb34f4d849532713eec687b','be5d5d37542d75f93a87094459f76678',2,37,13061,0),
('f3a121399cb34f4d849532713eec687b','c42bbd90740264d115048a82c9a10214',1,20,6530,0),
('f3a121399cb34f4d849532713eec687b','c6f057b86584942e415435ffb1fa93d4',2,35,13061,0),
('f3a121399cb34f4d849532713eec687b','c83b72dd001482ce10f0b106c7a0ed0e',1,30,6530,0),
('f3a121399cb34f4d849532713eec687b','df3f079de6961496f0460dcfdbf9bca3',1,9,6530,0),
('f3a121399cb34f4d849532713eec687b','e81c4e4f2b7b93b481e13a8553c2ae1b',1,21,6530,0),
('f3a121399cb34f4d849532713eec687b','ed2b5c0139cec8ad2873829dc1117d50',1,33,6530,0),
('f3a121399cb34f4d849532713eec687b','ed881bac6397ede33c0a285c9f50bb83',1,10,6530,0),
('f3a121399cb34f4d849532713eec687b','ef7c842dc2a5a859961053988674cedd',1,23,6530,0),
('f3a121399cb34f4d849532713eec687b','fe17ec3c451f132ef82a3a54e84a461e',2,31,13061,0),
('f3a121399cb34f4d849532713eec687b','ff1ccf57e98c817df1efcd9fe44a8aeb',1,38,6530,0),
('f419bc4f32582095e72050c638a7a4a2','01b6e20344b68835c5ed1ddedf20d531',2,21,9142,0),
('f419bc4f32582095e72050c638a7a4a2','044f058d53707e520ecab1c8b300635c',1,40,4571,0),
('f419bc4f32582095e72050c638a7a4a2','06d4cd63bde972fc66a0aed41d2f5c51',1,22,4571,0),
('f419bc4f32582095e72050c638a7a4a2','073d6f2167f8d9a96d86b9fe6b9d5b37',1,46,4571,0),
('f419bc4f32582095e72050c638a7a4a2','100b8cad7cf2a56f6df78f171f97a1ec',1,51,4571,0),
('f419bc4f32582095e72050c638a7a4a2','13b5bfe96f3e2fe411c9f66f4a582adf',1,2,4571,0),
('f419bc4f32582095e72050c638a7a4a2','15f6f8dc036519d7fe15b39338f6e5db',1,4,4571,0),
('f419bc4f32582095e72050c638a7a4a2','1ee85f6c60017a7f0646ba8dc5824de6',1,38,4571,0),
('f419bc4f32582095e72050c638a7a4a2','23a58bf9274bedb19375e527a0744fa9',1,14,4571,0),
('f419bc4f32582095e72050c638a7a4a2','2f212049ce79d2b949fd242043004288',2,0,9142,128),
('f419bc4f32582095e72050c638a7a4a2','3103a7d8f63cb184287c558ca51c6160',1,60,4571,0),
('f419bc4f32582095e72050c638a7a4a2','343453ca7edb572f3a3f971409a061b3',1,35,4571,0),
('f419bc4f32582095e72050c638a7a4a2','34776981fa47aa6cf3f2915d11bae051',1,59,4571,0),
('f419bc4f32582095e72050c638a7a4a2','4015e9ce43edfb0668ddaa973ebc7e87',1,12,4571,0),
('f419bc4f32582095e72050c638a7a4a2','430773153341c662da6867d207e96ae2',1,20,4571,0),
('f419bc4f32582095e72050c638a7a4a2','49ddafa93b4052e15e041a43d4343fda',3,34,13714,0),
('f419bc4f32582095e72050c638a7a4a2','4a46687a15a878b7c06dbc3d07a8f0ef',1,19,4571,0),
('f419bc4f32582095e72050c638a7a4a2','4c9184f37cff01bcdc32dc486ec36961',1,0,4571,128),
('f419bc4f32582095e72050c638a7a4a2','4d04cedd6d05b1f16a4404ff5a1fa4af',1,8,4571,0),
('f419bc4f32582095e72050c638a7a4a2','68daf8bdc8755fe8f4859024b3054fb8',1,0,4571,0),
('f419bc4f32582095e72050c638a7a4a2','6d84a9ae99910a7be5458a15c82a968c',1,31,4571,0),
('f419bc4f32582095e72050c638a7a4a2','6f4922f45568161a8cdf4ad2299f6d23',1,61,4571,0),
('f419bc4f32582095e72050c638a7a4a2','789183b7e98646c11d5f0544c8f3c4c9',1,55,4571,0),
('f419bc4f32582095e72050c638a7a4a2','7cef8a734855777c2a9d0caf42666e69',1,1,4571,0),
('f419bc4f32582095e72050c638a7a4a2','7d0db380a5b95a8ba1da0bca241abda1',3,39,13714,0),
('f419bc4f32582095e72050c638a7a4a2','811882fecd5c7618d7099ebbd39ea254',1,49,4571,0),
('f419bc4f32582095e72050c638a7a4a2','84cdc76cabf41bd7c961f6ab12f117d8',1,32,4571,0),
('f419bc4f32582095e72050c638a7a4a2','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,13,4571,0),
('f419bc4f32582095e72050c638a7a4a2','8fc42c6ddf9966db3b09e84365034357',7,0,32000,128),
('f419bc4f32582095e72050c638a7a4a2','90fafe3a7d04ee1c17239fa2d768f8fc',1,5,4571,0),
('f419bc4f32582095e72050c638a7a4a2','910955a907e739b81ec8855763108a29',1,48,4571,0),
('f419bc4f32582095e72050c638a7a4a2','933dd8674c563081260867dfa95b5e74',1,33,4571,0),
('f419bc4f32582095e72050c638a7a4a2','9a4b6f884971dcb4a5172876b335baab',1,47,4571,0),
('f419bc4f32582095e72050c638a7a4a2','9cc26fa09ce37bc95afe01bc718836d1',1,45,4571,0),
('f419bc4f32582095e72050c638a7a4a2','9e925e9341b490bfd3b4c4ca3b0c1ef2',1,15,4571,0),
('f419bc4f32582095e72050c638a7a4a2','9f62b8625f914a002496335037e9ad97',2,0,9142,128),
('f419bc4f32582095e72050c638a7a4a2','a181a603769c1f98ad927e7367c7aa51',1,3,4571,0),
('f419bc4f32582095e72050c638a7a4a2','a87ff679a2f3e71d9181a67b7542122c',1,7,4571,0),
('f419bc4f32582095e72050c638a7a4a2','aad0cd42d3c8a3b36a2be6a641d0cd53',3,0,13714,128),
('f419bc4f32582095e72050c638a7a4a2','bbdbe444288550204c968fe7002a97a9',1,37,4571,0),
('f419bc4f32582095e72050c638a7a4a2','d55669822f1a8cf72ec1911e462a54eb',1,28,4571,0),
('f419bc4f32582095e72050c638a7a4a2','d72749910e71e75279b310239e18f36f',2,11,9142,0),
('f419bc4f32582095e72050c638a7a4a2','d98a07f84921b24ee30f86fd8cd85c3c',1,6,4571,0),
('f419bc4f32582095e72050c638a7a4a2','df484065c67680ff240fdd4701aeff4f',1,62,4571,0),
('f419bc4f32582095e72050c638a7a4a2','e72f4545eb68c96c754f91fc01573517',2,44,9142,0),
('f419bc4f32582095e72050c638a7a4a2','e81c4e4f2b7b93b481e13a8553c2ae1b',1,54,4571,0),
('f419bc4f32582095e72050c638a7a4a2','ed2b5c0139cec8ad2873829dc1117d50',2,0,9142,128),
('f419bc4f32582095e72050c638a7a4a2','efd2af60c8501931cb9c736b5ad74f65',1,16,4571,0),
('f419bc4f32582095e72050c638a7a4a2','f91b2829bf8603e358094e1dedb6f947',2,10,9142,0),
('f419bc4f32582095e72050c638a7a4a2','f97c5d29941bfb1b2fdab0874906ab82',1,36,4571,0),
('f419bc4f32582095e72050c638a7a4a2','f9cb12f89c3f82ffaba2483cd3551d82',1,0,4571,128),
('f6094f9496469f15515d4d4d29d1f233','01b6e20344b68835c5ed1ddedf20d531',1,12,10000,0),
('f6094f9496469f15515d4d4d29d1f233','03c98ff9edc4b0e2fa19dd478e1613ee',1,14,10000,0),
('f6094f9496469f15515d4d4d29d1f233','09e1df54e12c423684f900e8f7143c79',1,22,10000,0),
('f6094f9496469f15515d4d4d29d1f233','21f64da1e5792c8295b964d159a14491',1,11,10000,0),
('f6094f9496469f15515d4d4d29d1f233','23a58bf9274bedb19375e527a0744fa9',1,6,10000,0),
('f6094f9496469f15515d4d4d29d1f233','3b38bec18c8edcf71c5f25e5f4fee0fc',1,7,10000,0),
('f6094f9496469f15515d4d4d29d1f233','4015e9ce43edfb0668ddaa973ebc7e87',2,15,20000,0),
('f6094f9496469f15515d4d4d29d1f233','6c92285fa6d3e827b198d120ea3ac674',1,25,10000,0),
('f6094f9496469f15515d4d4d29d1f233','7877adcb96eb8221c075f0008093bbf7',1,8,10000,0),
('f6094f9496469f15515d4d4d29d1f233','7cef8a734855777c2a9d0caf42666e69',1,1,10000,0),
('f6094f9496469f15515d4d4d29d1f233','7d0db380a5b95a8ba1da0bca241abda1',1,17,10000,0),
('f6094f9496469f15515d4d4d29d1f233','8bf8854bebe108183caeb845c7676ae4',1,3,10000,0),
('f6094f9496469f15515d4d4d29d1f233','8f888fedf6bd5ff7c93c6d76bb8dc21c',1,24,10000,0),
('f6094f9496469f15515d4d4d29d1f233','8fc42c6ddf9966db3b09e84365034357',3,10,30000,0),
('f6094f9496469f15515d4d4d29d1f233','93aa88d53279ccb3e40713d4396e198f',1,20,10000,0),
('f6094f9496469f15515d4d4d29d1f233','a2a551a6458a8de22446cc76d639a9e9',1,29,10000,0),
('f6094f9496469f15515d4d4d29d1f233','aad0cd42d3c8a3b36a2be6a641d0cd53',2,5,20000,0),
('f6094f9496469f15515d4d4d29d1f233','b44f86b9144cb9edd1d288a9cfc687a6',3,0,30000,128),
('f6094f9496469f15515d4d4d29d1f233','be5d5d37542d75f93a87094459f76678',1,9,10000,0),
('f6094f9496469f15515d4d4d29d1f233','c5946eb9400717fd6f40e26e36cdb498',1,16,10000,0),
('f6094f9496469f15515d4d4d29d1f233','c88d5d2b1f62346292376d93bd95c03b',1,30,10000,0),
('f6094f9496469f15515d4d4d29d1f233','d07182257bce13d49a5c183864e4a277',1,28,10000,0),
('f6094f9496469f15515d4d4d29d1f233','e2eff6c2dafd909df8508f891b385d88',1,26,10000,0),
('f6094f9496469f15515d4d4d29d1f233','e6f06702c43d31c81cb42967420c0b31',1,4,10000,0),
('f6094f9496469f15515d4d4d29d1f233','e72f4545eb68c96c754f91fc01573517',1,21,10000,0),
('f6094f9496469f15515d4d4d29d1f233','fd456406745d816a45cae554c788e754',1,13,10000,0);
/*!40000 ALTER TABLE `index_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_section`
--

DROP TABLE IF EXISTS `index_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_section` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` varchar(32) NOT NULL,
  `phash_t3` varchar(32) NOT NULL,
  `rl0` int(10) unsigned NOT NULL DEFAULT 0,
  `rl1` int(10) unsigned NOT NULL DEFAULT 0,
  `rl2` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`rl0`),
  KEY `page_id` (`page_id`),
  KEY `rl0` (`rl0`,`rl1`,`phash`),
  KEY `rl0_2` (`rl0`,`phash`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_section`
--

LOCK TABLES `index_section` WRITE;
/*!40000 ALTER TABLE `index_section` DISABLE KEYS */;
INSERT INTO `index_section` VALUES
(1,'3d798c3f120fdabe32985de46a5fc2fd','3d798c3f120fdabe32985de46a5fc2fd',1,0,0,1),
(2,'56ce185f3262c9101626cfd28a4127a4','56ce185f3262c9101626cfd28a4127a4',1,2,0,2),
(3,'78cabd40e1e1f417b9f83789c2321f4a','78cabd40e1e1f417b9f83789c2321f4a',1,2,3,3),
(4,'6d2ddd1174e062f12957e8f7a89bafb1','6d2ddd1174e062f12957e8f7a89bafb1',1,2,4,4),
(5,'53a65a8e3f722edf05d31693dce3236f','53a65a8e3f722edf05d31693dce3236f',1,0,0,1),
(6,'5192c25f9e1778c3c79dff990fa03437','5192c25f9e1778c3c79dff990fa03437',1,2,0,2),
(7,'97b8cd0fe54b6d09a38ff14702afb4bc','97b8cd0fe54b6d09a38ff14702afb4bc',1,2,3,3),
(8,'9bd8393860e6e9cf4c907a0919ca687d','9bd8393860e6e9cf4c907a0919ca687d',1,12,0,12),
(9,'f6094f9496469f15515d4d4d29d1f233','f6094f9496469f15515d4d4d29d1f233',1,14,0,14),
(10,'4f6e807051e61027dadc02f9f2906020','4f6e807051e61027dadc02f9f2906020',1,16,0,16),
(11,'67d787a12066aa33f927bc0bed2dc3fd','67d787a12066aa33f927bc0bed2dc3fd',1,18,0,18),
(12,'f3a121399cb34f4d849532713eec687b','f3a121399cb34f4d849532713eec687b',1,20,0,20),
(13,'85c2621b0fce09ac51613f18ce135f4b','85c2621b0fce09ac51613f18ce135f4b',1,22,0,22),
(14,'d031f71935b894cc76f91a35ad5e466a','d031f71935b894cc76f91a35ad5e466a',1,24,0,24),
(15,'ec2f2d3462894284b37105ddedffd64c','ec2f2d3462894284b37105ddedffd64c',1,12,0,12),
(16,'480f7b1104526ca784330338f9bc8f68','480f7b1104526ca784330338f9bc8f68',1,14,0,14),
(17,'b676e408624805da6b4c35566cad496c','b676e408624805da6b4c35566cad496c',1,16,0,16),
(18,'d2b728c29c935917865a91198146007e','d2b728c29c935917865a91198146007e',1,18,0,18),
(19,'1274e6ec4a76f4918a72b6b88575b2f1','1274e6ec4a76f4918a72b6b88575b2f1',1,20,0,20),
(20,'7fb9c8e8b02c27d3a5c5c229300fb27f','7fb9c8e8b02c27d3a5c5c229300fb27f',1,22,0,22),
(21,'ca9fd685b16e5922e940b713a6166e7f','ca9fd685b16e5922e940b713a6166e7f',1,24,0,24),
(22,'d3c7afff432dc4a8674da3b6cfcc9624','d3c7afff432dc4a8674da3b6cfcc9624',1,0,0,1),
(23,'e45333e70f61f6118c6492c55e8605b9','e45333e70f61f6118c6492c55e8605b9',1,2,0,2),
(24,'bec4701003457746b3e8eb7b62a181cf','bec4701003457746b3e8eb7b62a181cf',1,2,3,3),
(25,'78d410ed8d322872c93e023c151a02b9','78d410ed8d322872c93e023c151a02b9',1,2,29,29),
(26,'b4b473e088c0a9f40a7eb9053a621871','b4b473e088c0a9f40a7eb9053a621871',1,2,29,29),
(27,'2398fdd24f0b64e9f9f3e15fc0bb6109','2398fdd24f0b64e9f9f3e15fc0bb6109',1,34,0,34),
(28,'f419bc4f32582095e72050c638a7a4a2','f419bc4f32582095e72050c638a7a4a2',1,34,35,35),
(29,'55a8841b368fd8e1405e80ae0cf43f69','55a8841b368fd8e1405e80ae0cf43f69',1,34,36,36),
(30,'0e6531c5d0ae0b0a3fa3622a23f7818e','0e6531c5d0ae0b0a3fa3622a23f7818e',1,34,37,37),
(31,'56e8dbba6bd49275b2763e0aa24d2418','56e8dbba6bd49275b2763e0aa24d2418',1,34,38,38),
(32,'bf10d741ea1a3f66bd8f054520f99b4f','bf10d741ea1a3f66bd8f054520f99b4f',1,34,0,34),
(33,'4fe65afd46a96ebb6113e4082c07329f','4fe65afd46a96ebb6113e4082c07329f',1,34,35,35),
(34,'132c3127164c3476556136c8b825863f','132c3127164c3476556136c8b825863f',1,34,38,38);
/*!40000 ALTER TABLE `index_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_stat_word`
--

DROP TABLE IF EXISTS `index_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(50) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tstamp` (`tstamp`,`word`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_stat_word`
--

LOCK TABLES `index_stat_word` WRITE;
/*!40000 ALTER TABLE `index_stat_word` DISABLE KEYS */;
INSERT INTO `index_stat_word` VALUES
(1,'permit',1793166252,5),
(2,'permit',1793166301,5),
(3,'permit',1793166332,5),
(4,'mashujaa',1793166348,5),
(5,'land',1793166348,5),
(6,'rates',1793166348,5),
(7,'kangaroo',1793166348,5),
(8,'jambo',1793166638,5),
(9,'jambo',1793166852,5),
(10,'kibali',1793167735,5),
(11,'permit',1793167735,5),
(12,'jambo',1793168426,5),
(13,'huduma',1793168463,5),
(14,'permit',1793168493,5),
(15,'permit',1793168493,5),
(16,'permit',1793168537,5),
(17,'kangaroo',1793168538,5),
(18,'kibali',1793168538,5),
(19,'kangaroo',1793168538,5),
(20,'permit',1793168545,5),
(21,'kangaroo',1793168545,5),
(22,'kibali',1793168545,5),
(23,'kangaroo',1793168545,5),
(24,'permit',1793168546,5),
(25,'jambo',1793168606,5),
(26,'jambo',1793170752,5),
(27,'permit',1793171900,5);
/*!40000 ALTER TABLE `index_stat_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_words`
--

DROP TABLE IF EXISTS `index_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_words` (
  `wid` varchar(32) NOT NULL,
  `baseword` varchar(60) NOT NULL DEFAULT '',
  `is_stopword` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`wid`),
  KEY `baseword` (`baseword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_words`
--

LOCK TABLES `index_words` WRITE;
/*!40000 ALTER TABLE `index_words` DISABLE KEYS */;
INSERT INTO `index_words` VALUES
('000500166bc26ce9d248efa151a93742','anahitaji',0),
('01b6e20344b68835c5ed1ddedf20d531','to',0),
('01bbba85d02955b23cbb2be354be2be2','karani',0),
('01d1005bf5dd0c289b1af9226f6a01d5','kimoja',0),
('01fc8dbe01da25daf8fd5da8f519c6a1','tarehe',0),
('02ea2ae2a237c042285e093e6972eaa9','nani',0),
('02f12e93b2441290199a82ec7c270f5b','halmashauri',0),
('0347b574e0d2e699ffa6216abd44b6dc','barua',0),
('03c7c0ace395d80182db07ae2c30f034','s',0),
('03c98ff9edc4b0e2fa19dd478e1613ee','bids',0),
('044f058d53707e520ecab1c8b300635c','10:00',0),
('04a481486dd84d7c8bfdfc89d38136a6','nia',0),
('05155838d6a9b3ff384a8b247be221b5','kati',0),
('057a00ebe4c35f8e72be9349834dc619','trader',0),
('05b1aee1a08b2265d582914c2e1293d1','easier',0),
('05e2c42764429721c53046a2b83ffea4','taka.',0),
('060ad00963b820f66e4048a428c8dbd5','omba',0),
('0673e173f6d896cb2f1310a1499a1b6a','mapipa',0),
('06d4cd63bde972fc66a0aed41d2f5c51','comment',0),
('06ed9988df31251829e6237a844aa5d3','shillings',0),
('073d6f2167f8d9a96d86b9fe6b9d5b37','submissions',0),
('075a3e36a0a52dcbc568c05788e8a713','medium',0),
('07ccfe360dce69b84595428e2ec1c1cc','also',0),
('07d9e3aefc4093a49121c91ef65e708b','meters',0),
('08d5f9e9048e2000531c3170f4b833b1','assembly',0),
('09300df44b9d20cc219b25abddc3346e','enterprise',0),
('0931be4cc434934e64b1894aa2dba1ae','permit',0),
('09416c048ec5193549d096e7eb7fa36f','cooperatives',0),
('09e1df54e12c423684f900e8f7143c79','awards',0),
('0a538a0ca54a9f51fc1334040fb89d64','tender',0),
('0b352de3203b618d4f2e91f0bbb142dd','kinachoongezwa',0),
('0b3b97fa66886c5688ee4ae80ec0c3c2','us',0),
('0b3cfa5de16ad41eedf27d40fd0149d0','ukusanyaji',0),
('0b545251ae2a1ce47d189c39bc1b91bc','kuwasiliana',0),
('0b9a34b7bbce73bb011739b229debda7','mikutano',0),
('0ba4439ee9a46d9d9f14c60f88f45f87','check',0),
('0bead884803fe8c5643dda0dcb94b1bc','sealed',0),
('0c83f57c786a0b4a39efab23731c7ebc','email',0),
('0cc175b9c0f1b6a831c399e269772661','a',0),
('0cdebd4dc2635cced6099c034960b542','kinahitajika',0),
('0d149b90e7394297301c90191ae775f0','it',0),
('0d3c4f5d92495e85c1af09b4b8e6f536','kuachwa',0),
('0e3a8d38d6a037ceca6885c6b654124e','delivered',0),
('0e4b899600d9dbe31eb6f61080374baa','jumatatu',0),
('0e5243d9965540f62aac19a985f3f33e','then',0),
('0f5264038205edfb1ac05fbb0e8c5e94','long',0),
('0f5659687e42a1bb10aff6af0ca58adf','pictures.',0),
('0f710bba8d16303a415266af8bb52fcb','submission',0),
('0ff85bf08b1dda54ff95e390af1d9b99','accessibility',0),
('100b8cad7cf2a56f6df78f171f97a1ec','any',0),
('1038fe0a61dc0a70212f8845171167b0','inaorodhesha',0),
('106a6c241b8797f52e1e77317b96a201','home',0),
('10cd395cf71c18328c863c08e78f3fd0','services',0),
('110cea74cf52e41ead691dccdf75f27b','september',0),
('11efd54a5c384515bfd9cb473eef8ac5','zitaendelea',0),
('12a032ce9179c32a6c7ab397b9d871fa','people',0),
('12cba3ee81cf4a793796a51b6327c678','copy',0),
('12de3a4dab98ef8a7d67aace8150b540','come',0),
('131be413a48a3a5ce429995e2170c5aa','carries',0),
('13b5bfe96f3e2fe411c9f66f4a582adf','in',0),
('14354d69d78781de8295a50fd7db897f','weka',0),
('154d453667082d5297415cabcb7ac0ae','januari',0),
('15d72a64dfa9800801dae9a5abc4950c','hutozwa',0),
('15f6f8dc036519d7fe15b39338f6e5db','twelve',0),
('161667482354e5692dd1942931f981fd','handed',0),
('162e31afc5ade88a04d3f428e97e8f46','our',0),
('1679091c5a880faf6fb5e6087eb1b2dc','6',0),
('1718e70ba445df7073e04b1a679d2fa3','mkataba',0),
('172a8327fcd3685ab3c0f740d031da09','week',0),
('18218139eec55d83cf82679934e5cd75','will',0),
('18b049cc8d8535787929df716f9f4e68','an',0),
('18b243c932d6f259d2a0ce658720f41b','kiwanja',0),
('193da9b96f9705c746b0943c593bfbf3','ucheleweshaji',0),
('1976e926544da8d517bb7a722ce5fc68','makuu',0),
('1a31a6f65cc993ff6bd9a5b85f0520b0','tuesday',0),
('1aa39ec59532b438bfa67d6527e10d99','kubwa',0),
('1adc13cf053c4d8e60b6a20a9e611123','lease',0),
('1aec9c5d0644e11fd9dd0f9fb36009fb','used',0),
('1b20e9021b3a16b059287caddc7862f6','building',0),
('1c6154a8b601535135a2d76cd4ffdecb','maji',0),
('1c7a710dcf915e3ea681e113f7795eca','kimepangwa',0),
('1d9e348141a4a084c649ca616877f279','it.',0),
('1de9b0a30075ae8c303eb420c103c320','reader',0),
('1e41815a0ec40fdda1523537c23a70da','asked',0),
('1ee85f6c60017a7f0646ba8dc5824de6','starting',0),
('1f5f6080965ed6d0a90e6b9ec599e441','provided',0),
('1feb078f3e07a4b9b47c90c6495c894d','hufanya',0),
('2069ca795d8e10a6f9a92dd57d01af10','balance',0),
('20820bde05df43a0783e8886c51ace9a','missed',0),
('20cc39187933346eee8108ec76a2f796','serve',0),
('2116c221c2db2f9b400349baa6e3d7d1','yamechapishwa',0),
('21582c6c30be1217322cdb9aebaf4a59','that',0),
('21927851c1be56cb95b9baa4abcb023c','lets',0),
('21c5084aeff1e5fbcbaa98b661758382','huduma',0),
('21cec257feb15bcc84e0acd5b0773883','privacy',0),
('21e119daf697467b14b076f2d5819aec','trade',0),
('21f64da1e5792c8295b964d159a14491','documents',0),
('22af645d1859cb5ca6da0c484f1f37ea','new',0),
('22d97324e887bceb83f5a3a68ef31390','tuesdays',0),
('232e016a0f0555fc7f8e477f650c94c5','chini',0),
('237c3a9e6f91efa017ad144794777f42','floor.',0),
('23860c3722bca6a44358306a395480fd','makao',0),
('23a58bf9274bedb19375e527a0744fa9','with',0),
('2417b53255206bdce189add39d85fca1','appointments',0),
('2541d938b0a58946090d7abdde0d3890','send',0),
('2694d7d3321f7a44a04b461e1955c8d8','oktoba',0),
('276b6c4692e78d4799c12ada515bc3e4','ana',0),
('27792947ed5d5da7c0d1f43327ed9dab','details',0),
('27e1eb6ed60750644938070d3893555e','differs',0),
('28e32fb02cd44e44796348fbc2b93e1c','issued',0),
('28ef5e079b0571848c806ff5266c2c22','husika',0),
('2940c973c72bd82aad4460dbbb3c5a52','nyaraka',0),
('29a5417a3ebd1c4bd3108d86a3e5b995','around',0),
('29b7537f38eb598ebaec123f6a7c6a8e','mmiliki',0),
('29d0b8d9daec06cdd0cda7269997b216','makes',0),
('2a4982f2efa6b2c278db2286b3c23e8f','publicly',0),
('2af45960db0a678ed7f610f117b1d46e','notices',0),
('2b80472febb0c52ab4551deca95dcd7b','offices',0),
('2bb3d86d95234affa7c5bd68c4bab606','they',0),
('2c61ebff5a7f675451467527df66788d','can',0),
('2c9ceb35a9743095e6adddc158f6f31f','mmoja',0),
('2d95b19b24f71bcabbc68e31afaff694','cent',0),
('2e1268172f08d3cf32f2172eae567fb8','yaliyoandikwa',0),
('2f212049ce79d2b949fd242043004288','budget',0),
('2f517001fcdc575005781fd245125e75','tovuti',0),
('2f8a6bf31f3bd67bd2d9720c58b19c9a','contact',0),
('2fd7cb590fc8e5de760a3a21256b5555','ksh',0),
('30056e1cab7a61d256fc8edd970d14f5','five',0),
('306826899d77aaa50c928e83657d2687','kuhudumia',0),
('3103a7d8f63cb184287c558ca51c6160','until',0),
('312db69f5bf4447dfe3c58983083b54f','everything',0),
('313ab1575a0de48f02ee31f281346eee','zikitofautiana',0),
('31783e73d792207712a1add81d10cbe9','hili',0),
('31aa6d34f11de5c586cf042767e8d74e','closed.',0),
('32af23ab89095528e5cac67ce5c2a497','ukurasa',0),
('32bc1a1098bc887b73a516fa31e5d04a','washindi',0),
('32efcf78f15ffb8500029a8e74c0b8f4','huongezwa',0),
('32fa6e1b78a9d4028953e60564a2aa4c','plot',0),
('3309a7a7941818e131b4dfb9a6349914','has',0),
('33a931c25fc53fb3541e1d9754dbcc62','faragha',0),
('33e26553024adb44e6e95937bc1439fd','hutolewa',0),
('33e75ff09dd601bbe69f351039152189','28',0),
('3413e60c4be854b769e90cfa4cb1730d','bring',0),
('343453ca7edb572f3a3f971409a061b3','holds',0),
('34776981fa47aa6cf3f2915d11bae051','clerk',0),
('349e686330723975502e9ef4f939a5ac','closed',0),
('34a7956c816cd1faa1b96dbe2806f9b3','kubeba.',0),
('34d1f91fb2e514b8576fab1a75a89a6b','go',0),
('35661b0f1f47e1023ec3dfd336c62bd7','stands.',0),
('358c4c7750d79fd100568536318758ed','ili',0),
('3598e4f00157c2446d9ff61be81d66b0','iliyotajwa',0),
('35ea8083fa3fa79e8294cb56d079387d','needs',0),
('362140d5183309f61f9b3c34ec801fd6','dispensaries',0),
('3676d55f84497cbeadfc614c1b1b62fc','application',0),
('36a383994590c1a836800f68a08d00ba','against',0),
('36c3e41a4eef4082ea47cc9494244c79','zisizochukuliwa',0),
('36eee0019cac8e1c32d9f87d19de1355','kwenda',0),
('388a56dbb62a010dc26a378981346247','keyboard',0),
('39306192204262ad0b88470c636a75dd','grouped',0),
('393095cbd61196a5346e69acc966a029','unazotoa',0),
('39c8942e1038872a822c0dc75eedbde3','if',0),
('39ec46822b0f6f5eae91475d0960ddd7','machi',0),
('3a50c5e41a1c3eee6dcddca9e04992e0','opened',0),
('3a5afaf5d67c2547a79f0c517e1191f1','vya',0),
('3adf9b14e32c8e7a8013482c89bd78b8','viko',0),
('3b38bec18c8edcf71c5f25e5f4fee0fc','closing',0),
('3bebb2f89180b03fa5ae736665f648d9','started',0),
('3c59dc048e8850243be8079a5c74d079','21',0),
('3c68cbe461787ba38509df85e731f1a6','road',0),
('3c8925c7fb2d563070c4c7aa96954e92','headquarters',0),
('3eec4e89e171cfb8c51262fe749722e6','matangazo',0),
('4015e9ce43edfb0668ddaa973ebc7e87','are',0),
('4061838f4395ef541fb1b3f07e42bc21','march',0),
('410d98939d4116adb562b97046d2a3eb','submitted',0),
('4245bf56d28f22197a4b30b46c809626','statement',0),
('42ddcea8b7d1fd6b522b633c9cac018e','taarifa',0),
('430773153341c662da6867d207e96ae2','residents',0),
('434d51c5183af28f7f4ec4661b81397e','zaidi',0),
('437b930db84b8079c2dd804a71936b5f','something',0),
('43b5c9175984c071f30b873fdce0a000','current',0),
('43dc06f87883e446a94dbfd78d833852','zinapotolewa',0),
('4474385cf4b7c5b4a97b13026eeb0887','tafadhali',0),
('44fdec47036f482b68b748f9d786801b','days',0),
('459d9fca17e3a950deae755d13578292','department',0),
('45c48cce2e2d7fbdea1afc51c7c6ad26','9',0),
('467b6140fe3bb958f2332983914de787','january',0),
('46b3931b9959c927df4fc65fdee94b07','about',0),
('46c48bec0d282018b9d167eef7711b2c','up',0),
('470773b77a7114d03daa3480a975b8c0','zilizopo',0),
('47a708336d417719c1a1e942ff7da27d','badala',0),
('4842977d009b213a738666fe26ba78e6','nyingi',0),
('4893680cd9e9b799a7b8de8e14ea804d','mashujaa',0),
('48aee20d947736a18c6e9d09b526f75a','charged',0),
('48bb6e862e54f2a795ffc4e541caed4d','easy',0),
('4917dba1522528ff583a4abe5a90b62c','zinaweza',0),
('49256b9819abacbb8e6e031a03abe81b','wait',0),
('492bd93456b81ad92f61e8891174ed04','gets',0),
('49aa1219402b59fa7dd9b894e1101484','ndani',0),
('49b0be73826dd0f37993e8b19e583f44','kundi',0),
('49ddafa93b4052e15e041a43d4343fda','ward',0),
('4a2028eceac5e1f4d252ea13c71ecec6','what',0),
('4a46687a15a878b7c06dbc3d07a8f0ef','invites',0),
('4ab8710d781ba5b13aaf561cafd896b7','made',0),
('4ae07446a1d8ca36a97e34fcfce80376','ambapo',0),
('4be77da577a5f3e817dbfde199c142f6','mwanzo',0),
('4c0a1c806189b2c621111acee40217ac','biashara',0),
('4c9184f37cff01bcdc32dc486ec36961','public',0),
('4c9858e082cad5bd214a9efc0f2f8cec','reach',0),
('4d04cedd6d05b1f16a4404ff5a1fa4af','november',0),
('4d8b6084f3d167b76cac66a22a91be02','kept',0),
('4da463dcb391d40ec0352edd2e42b2d2','apply',0),
('4f09daa9d95bcb166a302407a0e0babe','short',0),
('509484d31b4ecf0a63251503d19b88e9','kumbukumbu',0),
('50ea87f4ddc58f228221d3b6bcad462b','wasiliana',0),
('51037a4a37730f52c8732586d3aaa316','same',0),
('5188aa9e6815c731a69a0c302c772797','08:00',0),
('52a1c95fd889c4a3b00f33472a845157','council',0),
('53b9e9679a8ea25880376080b76f98ad','call',0),
('53d670af9bb16ea82e7ef41ee23ec6df','who',0),
('5440e70c43cc02aba90d879c888e6e09','does',0),
('5464125f42d78ff58c5a88c3dedf675a','unachohitaji',0),
('555bf8344ca0caf09b42f55e185526d8','health',0),
('5592932dd92ccce1ceef6f3c5fbdede7','jumanne',0),
('55ab85e676ef2f7305f22d8119d53410','lorry',0),
('55c013101011f633b2d8b0b3fd27e123','mawasiliano',0),
('55f195813a158d82e2934cfac569575d','should',0),
('563873d38950b841aebf89c3be1b1a35','registration',0),
('567904efe9e64d9faf3e41ef402cb568','where',0),
('57f8fcaeb8f4d8fdda329582bdc9b72c','approvals',0),
('58258870a61e35f41e3c0aa1d7d6e29e','wakiwemo',0),
('582ca3f7cbaf4edcc1b445f8ea90b503','employees',0),
('584826e70485130530f7f01a973d5637','its',0),
('589b397ed82131bf51acdf63521c2df5','built',0),
('592cbbfa476b65fe142c0463135b5c67','fedha',0),
('599eba19aa93a929cb8589f148b8a6c4','screen',0),
('59ee99bd85013d119227d6f93de6155d','zake',0),
('5a0f33b732e7824bd6477cbb1ee20c64','000.',0),
('5ad960d224f349e7d93b8f38e96886db','usambazaji',0),
('5b431d3d0cd0aafac0ed312ac7ff536b','yoyote',0),
('5ba3205251522e793017b3af03c607ce','agreement',0),
('5be23b1de1eff5ddf95ff3d5d9a4bd90','umma',0),
('5c48b229521c5bbe9ac425745e45b724','sitting',0),
('5cfc1f542032073a69e82c2c7c6a8386','asubuhi',0),
('5d6eacb879f2a0d08080c3ca04e292c5','available.',0),
('5db97dad4d4d722e4cc31cff4ebda2fe','ijumaa',0),
('5dd2199ad68327cc76d583b057aee7d5','card',0),
('5e4020157ffb71ed07a530ac5c9c9be6','hutumwa',0),
('5ed33f7008771c9d49e3716aeaeca581','ask',0),
('5ef76d30bf9232902687324b5bfa0bd2','use',0),
('5f38f7089756746b5389e8e7d8645c61','mpya',0),
('5f919c0306e6579479e36d34ea7fb648','kulingana',0),
('5fa3852b08951fcdc4d2e60f89a85bfe','popular',0),
('60190cb2b5a1d64c6c22fdda4d9e29e0','safari',0),
('6040c69f06d0c61ef4dc25567bd0213c','alhamisi.',0),
('6050ce63e4bce6764cb34cac51fb44d1','please',0),
('6094a70fb9532dfc3b1a9133364f3f7e','ushirikishwaji',0),
('60df9e64b0693131b626e465236c6874','within',0),
('6178b53b06f14bed62ca36ba066c8862','kuidhinisha',0),
('61ba8e10509e5b38886b6a2a1cae367a','kutumwa',0),
('61e3bbe3ca4c8bc38e142b139a346b46','stops',0),
('624f02e348502edb4269ed73e2e14545','zitafungwa',0),
('628b7db04235f228d40adc671413a8c8','day',0),
('62cc0b4ebb0b57b40778179234246c38','your',0),
('632a2406bbcbcd553eec45ac14b40a0a','after',0),
('636d50a77da70596843a5638ac61d2b6','mwaka',0),
('639849f6b368019778991b32434354fc','again',0),
('639bae9ac6b3e1a84cebb7b403297b79','you',0),
('646e6c2859df4288ae1bca30363de15e','premises',0),
('657ae4b9e8b99f712b8f24621483e7a1','wowote',0),
('657f8b8da628ef83cf69101b6817150a','help',0),
('65a1fa2f453bc4b96ef8b1b5a267478f','kuomba',0),
('66007490e4f17e80484c9965fe1b4416','hupokelewa',0),
('661a504c6c4cd163fe4d67836577b926','mtu',0),
('6639c3233dfa712e4e2aa1bd48315bcc','levy',0),
('669e30e88461ad462e642c08a25ffb05','dealt',0),
('676c0f8e5f9d2ca2b0b70ad3169d10ae','changed.',0),
('677221a278ff6fd52c06f79626dbbf76','kufika',0),
('67e92c8765a9bc7fb2d335c459de9eb5','work',0),
('681647a719e45584566fe980061fe10d','decide',0),
('68944d7c9fbc300426a92fca45b6e014','kama',0),
('68daf8bdc8755fe8f4859024b3054fb8','forums',0),
('697623632caf407f9bcb5cc2a399de63','kukodi',0),
('69a256025f66e4ce5d15c9dd7225d357','activity',0),
('69d5f5f86a3e0858494d1d10493f1af6','kupakua',0),
('6a6f3774bb043964a8817729b501f988','inayofanya',0),
('6b2ded51d81a4403d8a4bd25fa1e57ee','done',0),
('6c1990b7d29f5774a516bfbf7bd05975','pale',0),
('6c374e70334072aeeb62ed46ea987838','leave',0),
('6c92285fa6d3e827b198d120ea3ac674','here',0),
('6cb2b035fec9a521c8a8c79ee20e9ac1','nyumbani',0),
('6cd8b57ad8ec40b32215dcb1c8c76af2','rates',0),
('6cdc4630ff5785e3cad3d47850021cce','baada',0),
('6cede1cfde12fc6d88ad1d8b6636a977','below',0),
('6d07377eb5cd42102c36d2adec8eb7fd','vibali',0),
('6d84a9ae99910a7be5458a15c82a968c','financial',0),
('6d8a6dae33d1c8276853e32544b4ccf6','hayo',0),
('6e5f1255c3b7e3008e41ca8974012fc4','facilities',0),
('6e9b99b713d2006a61c58f305913b66e','pamoja',0),
('6ec66e124fb93c190e9207b0b82f542a','na',0),
('6ed3e17a8745b6beef55c309768c05df','bunge',0),
('6f4922f45568161a8cdf4ad2299f6d23','18',0),
('6f493bf6f3beb9d46a9c649d2f7ddd29','terms',0),
('6f59adb57bd48bba19fed2dfec4bf275','approves',0),
('6f7748a83b9a124aadf27755faf8a5f4','yako',0),
('700541d99871107ff17c418c65ece8c7','huchukuliwa',0),
('7071db26295c44957f44c77f3759aa10','bajeti',0),
('70a17ffa722a3985b86d30b034ad06d7','order',0),
('7108537956afa2a526f96cc9da7b0c36','delivery',0),
('715a89390c6ba5fb2f93570784ccf6d3','unaofanyika',0),
('716f6b30598ba30945d84485e61c1027','close',0),
('71860c77c6745379b0d44304d66b6a13','page',0),
('7198cda575b51b68a0dc83f5d66c2aee','town',0),
('719931acac86b6d8a7d5482ca145fe34','zako',0),
('71ad8fa7968ec98dcaff0824894d24b8','mabadiliko',0),
('72122ce96bfec66e2396d2e25225d70a','owner',0),
('72dacc9d1e0082d557ac8c1a4543a737','zabuni',0),
('735e3acf03c5919833eb09776229fef4','huisha',0),
('73cdddd7730abfc13a55efb9f5685a3b','hours',0),
('73dc10cdc7580b395e0ae39d15f88919','zilizo',0),
('74a2dbd693f0f1e713011b1832c54d8c','ikikamilika.',0),
('74b92d895652792b35d69f92e3bab531','sittings',0),
('7515875808ef6219fa6fd725e2105588','floor',0),
('755f85c2723bb39381c7379a604160d8','good',0),
('7587ec3e10e7c0a2032fc022bb45b1fe','receives',0),
('758f0e9ea526af2ca587384176f5bbf3','renewed',0),
('76671d4b83f6e6f953ea2dfb75ded921','hadi',0),
('76910c443f73ac1788d6bd692d6f0ce0','mfanyabiashara',0),
('76ef63369f7d5b6597a543017e1ef578','pili',0),
('7702bad848a0039a0b92fbe490369d52','alhamisi',0),
('7761127a460aaf290ed953098284dd1a','than',0),
('778a15406292a461ce949276efcd87a3','maombi',0),
('77b401c373f3e42e6e873fc3b29a50e0','sheria',0),
('7820cd42355d0b56bb26edd33c628c13','kuanzia',0),
('7848ee4d5502d6243eaa56ac7270da02','hushinda.',0),
('7877adcb96eb8221c075f0008093bbf7','dates',0),
('789183b7e98646c11d5f0544c8f3c4c9','sent',0),
('78949a75178ddd3c0c73cfcd5475d75a','answers',0),
('7978648641239a911c0f5a639f530836','itumike',0),
('79a41c87ab53aba8350287d29a7011af','ushirika',0),
('7b7813f00f42b7e5366e7065aaa798c6','including',0),
('7c4f29407893c334a6cb7a87bf045c0d','right',0),
('7cc82ba62ed3892d8acbe1a73a0cba49','hazikuchukuliwa',0),
('7cd623f978d45e86a183f38489993e21','pasipoti',0),
('7ce10e36b6c1837a30f1bed7c05c60ad','inapohitajika',0),
('7cef8a734855777c2a9d0caf42666e69','open',0),
('7d0db380a5b95a8ba1da0bca241abda1','at',0),
('7d5291299ad348d03615a1d1577a7808','plans',0),
('7e09f4be5df1e5ad108d0e10bcb365e7','haya',0),
('7e3f660480ab1640de8024c200b5a4d3','paper',0),
('7e5187ccd575afcd362ec67efd5891bd','taifa',0),
('7eb0ae4ada5be19f438ce67bef5929e6','kabla',0),
('7f46165474d11ee5836777d85df2cdab','online',0),
('7fa1b37085e839d1de27b470abdf7973','kuongeza',0),
('80570bebec5742bf89b3fbf9642cec02','kila',0),
('811882fecd5c7618d7099ebbd39ea254','left',0),
('819f7414a0023bc05eab45a7cc1a822c','ufikivu',0),
('82002249bfc8b93e42f329ab528426b1','wafanyakazi',0),
('821f03288846297c2cf43c34766a38f7','book',0),
('8282252205923a5847a803d007ed0c0e','tuambie',0),
('829a56cc8ffa56209e3a10b80d0bbdf8','law',0),
('839d2f69c685976fdfc9a403d0aa9921','mji',0),
('83ab982dd08483187289a75163dc50fe','every',0),
('847c8ebb0e477b63fbc34fc0cd42b404','depends',0),
('84cdc76cabf41bd7c961f6ab12f117d8','year',0),
('84eeb81e61c76ad3f4103b0b051c7021','says',0),
('8510c43ca591928d86fde94dd386538b','miswada',0),
('85377d38c845e2d0661d1ad29d1aa0b2','mkutano',0),
('878983117a2370e5b702db49786da067','runs',0),
('87c131a1c1e6f6bdcdf14c8f92104306','wazi',0),
('87cf962b35146c21d0dd7f84594662b6','land',0),
('884d9804999fc47a3c2694e49ad2536a','address',0),
('8867e7959e7070fdf9127554f966eb3f','tano',0),
('88ae91df0447a7b6e338a3d65ce73be3','awali',0),
('89c26022b24ee6a919f70e5cb7249dad','skrini',0),
('89fe7b5ca56cdee4e750f4eb3ab12fbb','goes',0),
('8a1a17e049499fb3b978d1e11b4f7693','saa',0),
('8a1edb7c17ea34190b9aa6a751987d07','kaunti',0),
('8a6f503814aa4a7cd863e68c7778fbdb','pin',0),
('8ab87d4fb3600cc53fc0c5c958a250b1','fix',0),
('8af54a059c168446a6ea9843ff32a05d','kukueleza',0),
('8b7af514f25f1f9456dcd10d2337f753','which',0),
('8bcc25c96aa5a71f7a76309077753e67','au',0),
('8bf8854bebe108183caeb845c7676ae4','of',0),
('8c00c19e66a7ba9d80bded9460cb1b41','been',0),
('8c4291f6956da81515a5c0caec2976d0','look',0),
('8c8d357b5e872bbacd45197626bd5759','ada',0),
('8cac409b9b51935cca7c7ec697656e80','mara',0),
('8ccb649d8531adae5c2e89610629b12d','asilimia',0),
('8cd283d8b7bacc277f2bae5e26ce6d1e','many',0),
('8cf179ec0fa4b3ce5abe77fdf9deb0b8','iliyopangwa',0),
('8d307a36f1482990b806d415f85fff86','jinsi',0),
('8d31d9aa2193cbd93731d668fe8caadc','manufacturing',0),
('8d777f385d3dfec8815d20f7496026dc','data',0),
('8dee49165153fc68ffacb5f7f7bf9a3a','instead',0),
('8e1b595f6403c7a34b46acdf8732288d','unaeleza',0),
('8e39dd47f29a3fa442ba24ff6ebaacbd','kufanya',0),
('8e57eec98946ddacf0f4b4cbc844bdb8','non-refundable',0),
('8f3b0c9cf515520ce0b4b48a3daeb501','mbili',0),
('8f69d9e05a57132f2d3fd21ca569eebc','ikiwa',0),
('8f72382d96d9e4889cc14e35d423bf44','kwa',0),
('8f888fedf6bd5ff7c93c6d76bb8dc21c','published',0),
('8fc42c6ddf9966db3b09e84365034357','the',0),
('901889f4f34f8ca18ac2f53d1fed346e','while',0),
('90fafe3a7d04ee1c17239fa2d768f8fc','wards',0),
('910955a907e739b81ec8855763108a29','be',0),
('913b9c1b73b00bdcd1107494026d1c89','unaochukuliwa',0),
('9173c9ad929ae18dca5d684fc40f5595','yanaweza',0),
('9195c5d7e168864e4a7b5f74067fa638','kuamua',0),
('91eac053445a914d25ddd441f92f24cc','responsible',0),
('926e27eecdbc7a18858b3798ba99bddd','pepe',0),
('92eb9d8343658eafaae461d6276df50c','njema',0),
('933dd8674c563081260867dfa95b5e74','each',0),
('93aa88d53279ccb3e40713d4396e198f','procurement',0),
('93d4baf39753fa03a63feee313b022b0','kupatikana',0),
('94074ce331b5db47060fd2d8009503a8','industry',0),
('942c5256345499efd6c26aea884f4a58','hutumika',0),
('944ba223a5c1b5f4b495708e7cd5ee37','monday',0),
('9460370bb0ca1c98a779b1bcc6861c2c','water',0),
('94c774b2721ef9f51cc1c7b9df42b07c','inayoendeshwa',0),
('95723b5e620e47cf613462b9f293282a','collected',0),
('959848ca10cc8a60da818ac11523dc63','za',0),
('9662d33089e9ecf2a7b0caebcc22a977','unaotakiwa',0),
('96f223040672ea79c655dceda08e0830','fall',0),
('9726255eec083aa56dc0449a21b33190','money',0),
('97bc592b27a9ada2d9a4bb418ed0ebed','now',0),
('97eab50bed12220597a62014b33e2420','kufunga',0),
('984eaf792802b84bce30376ec5e56247','moja',0),
('98bd1c45684cf587ac2347a92dd7bb51','last',0),
('98defd6ee70dfb1dea416cecdf391f58','site',0),
('98f13708210194c475687be6106a3b84','20',0),
('9a09e6ec9d67e3856d220f708ceb1508','businesses',0),
('9a4b6f884971dcb4a5172876b335baab','may',0),
('9acb44549b41563697bb490144ec6258','status',0),
('9b865ffcca75bae72520a5b43a64a47e','zinazotolewa',0),
('9bbd993d9da7df60b3fd4a4ed721b082','round',0),
('9bf31c7ff062936a96d3c8bd1f8f2ff3','15',0),
('9cc26fa09ce37bc95afe01bc718836d1','written',0),
('9cc49ff7cdca6cb5a0646f1e962943a4','sentences',0),
('9cd237cbcfaa843bac1e5a8299f9f2a1','wafanyabiashara',0),
('9de70f6546b2452f6e7b98b46ac36070','visit',0),
('9e6823d5a518efab0ef808da6caffa93','wakazi',0),
('9e925e9341b490bfd3b4c4ca3b0c1ef2','this',0),
('9f62b8625f914a002496335037e9ad97','2027',0),
('a00e43bc9d0a6d583cfcd6f8d00b1d35','laws',0),
('a0e7b2a565119c0a7ec3126a16016113','calendar',0),
('a12ace82ecc53103152294f32edc19fe','kazi',0),
('a16574242b3bbe2fc5ec9dc26fe4deb2','page.',0),
('a181a603769c1f98ad927e7367c7aa51','all',0),
('a1b140811f9aa57a4154706e98fa2dee','carried',0),
('a1ec23e9b9ab43a88222d9949ee26499','give',0),
('a1ff09453cc85d1a8cc7fb1f4911f8e4','fees',0),
('a212ff322370e1d58e71fba0550aca76','vitu',0),
('a22c8f2df3150c0d125b5769235ab6af','kuanzishwa',0),
('a249768ea130ced1376e512efff73021','idara',0),
('a2a551a6458a8de22446cc76d639a9e9','is',0),
('a2b8ed9c305b8ea86116b603cca78a97','registered',0),
('a2c93d508496a6e10ed94b231302fc3a','hupokea',0),
('a363b8d13575101a0226e8d0d054f2e7','answer',0),
('a36e1b5a359678cc89110d27f81fd1f4','usable',0),
('a3c222e464ac4c7fc64d8686ed379439','tangazo',0),
('a4010945e4bd924bc2a890a2effea0e6','follow',0),
('a48a68f037b7ff127cdecac38b2581bd','eneo',0),
('a4ddbadbe786fc766560cb14b16ffc90','kikao',0),
('a5212ecae231b0a7405799192fc34ab5','ofisi',0),
('a53108f7543b75adbb34afc035d4cdf6','run',0),
('a546cabc633a9d02345954ffa2c98f44','renew',0),
('a5582ce082dd86808f032b23447b370f','tathmini',0),
('a566b2bebc62611dff4cdaceac1a7bbd','papers',0),
('a57627656770ae9f260aa162ecacecb3','kutoa',0),
('a6daad2f29decd1e94a592164d34183a','remain',0),
('a77b3598941cb803eac0fcdafe44fac9','was',0),
('a87ff679a2f3e71d9181a67b7542122c','4',0),
('a8c478391757a06ee53d8aec274b31a6','tells',0),
('a9c97af092d8959d34afd99722d2b0dc','kibodi',0),
('a9e4f7e098ba45314ead394184671cc7','covers',0),
('a9f0e61a137d86aa9db53465e0801612','second',0),
('aaabf0d39951f3e6c3e8a7911df524c2','service',0),
('aad0cd42d3c8a3b36a2be6a641d0cd53','county',0),
('aae446086f8e81194ed115b566bf2e3d','wednesday',0),
('aaf9a7ade8ad853549f9ce5d53e8d645','supply',0),
('ab280114f07686e8c6872827c99ca96e','kerb',0),
('ab431ce8ae539a4bf0f21c2f5fcfe0cf','masharti',0),
('ac29e4af163e60052daea96214151601','5:00',0),
('ac67ede5a84eb5a1add7ff4440e9a485','required',0),
('acbaf7dd72a645872b64a28687e0cb45','domestic',0),
('addec426932e71323700afa1911f8f1c','more',0),
('af1fcc06be6421a2519c0a048a526ba6','yake',0),
('af85b9ed98481408d4101739fed539d6','katika',0),
('afacdb0a401ccdf6b48551bbc00e8a74','large',0),
('aff5412b9c6214a7ba9321f9f02a262d','tutarekebisha',0),
('b01c779298700e97cfd00b5cec9f2b28','yanaruhusu',0),
('b02a45a596bfb86fe2578bde75ff5444','pay',0),
('b0a00b35f2131ede81d4717282b6a90f','yenye',0),
('b1b9a972ccd8c962a473909b97007eb4','ten',0),
('b1bc248a7ff2b2e95569f56de68615df','number',0),
('b1caa385c37f1fec467494c8fde4f49b','appointment',0),
('b1ccce9f4800002b39d95661dde1185e','clinics',0),
('b2ae2cd3f4143bf192efb35bb9e7d369','novemba',0),
('b326b5062b2f0e69046810717534cb09','true',0),
('b33f4c25b86a0df3480941ffa14a0686','ratiba',0),
('b39a10c3757e6c589ea4fe4db9f04cc9','linapoenda',0),
('b3b32a2d422265cd25c3323ed0157f81','pages',0),
('b3ba719b7f5004d91df10aff537603e4','closing.',0),
('b403d3f0efbf4cb850d2d543758cb57c','too',0),
('b42dad5453b2128a32f6612b13ea5d9f','have',0),
('b44f86b9144cb9edd1d288a9cfc687a6','tenders',0),
('b4714fa709d5fd6b39b5719b3b157622','kando',0),
('b4992073ceb7cead98413d6509b1db49','decided',0),
('b5237b6a7892a42a4a7a60fdfbe828b9','bills',0),
('b550a1f8cb36a6cad7477f4a8ac18f48','kituo',0),
('b5eda0a74558a342cf659187f06f746f','get',0),
('b5fba9ff24d0045d1377a05a46b32f68','applications',0),
('b6d767d2f8ed5d21a44b0e5886680cb9','22',0),
('b6f3b4b5b8b20e28fb9763001bb4b079','rent',0),
('b80bb7740288fda1f201890375a60c8f','id',0),
('b8a9f715dbb64fd5c56e7783c6820a61','two',0),
('b8bf222bdaf3eb9c6559c0b5386861e4','hukamilishwa',0),
('b99a78d80570fc2b2bfd0dab4c39ea04','bring.',0),
('b9b9e36c1a5d1be22158df398f2e29b8','decision',0),
('ba2b767d7dfa81d754fa0b8ea4692eb7','hupatikana',0),
('ba543925dcf34943ee34636edfb90198','transfer.',0),
('bae2084bfdeaa3f6d8428ecbb0baf7da','itaanza',0),
('bae3d929b274a4cd35c38fe92f059f1a','mita',0),
('bb3ccd5881d651448ded1dac904054ac','information',0),
('bb9f601ba081ab8d336a14a697048cb0','nasi',0),
('bba21ef56d55c873195e173c1e2c3e04','novemba.',0),
('bbc675c430deefa88c9091c8084ec4c9','thursdays',0),
('bbdbe444288550204c968fe7002a97a9','forum',0),
('bbf3c5a13c25133cc08db092814e9167','thursdays.',0),
('bccd1749fc2f1ef02fdc62280cd40df0','announcements',0),
('bd0dd14cd9e91d6290387dd7b66baefb','cheti',0),
('bd4c4ea1b44a8ff2afa18dfd261ec2c8','these',0),
('bd5af1f610a12434c9128e4a399cef8a','bank',0),
('bd5bb0ca70a22a3725257f45e0e9f549','0800',0),
('be43f0cbf4bcbb3ab0d83b14b868920e','kumi',0),
('be5d5d37542d75f93a87094459f76678','and',0),
('be9bd32df53512c2246361c712a26051','costs',0),
('beae3de7729a01f28c1a7857dee08ead','mdogo',0),
('c048177706eb0476cea140a8b54eaca8','septemba',0),
('c0ca5324e06afa567f7d5ad10a592576','needed',0),
('c16a5320fa475530d9583c34fd356ef5','31',0),
('c16ab7b9eb450c2b6a74bbc56ffc2442','kitambulisho',0),
('c1a55efe8fd9efed48836d50691cdae4','operating',0),
('c1c16452b04650ea34d1463da2739f3b','market',0),
('c1c4b206324f9567d8f593bd0e4d1634','huchapishwa',0),
('c1d8ae6cfb3b6b1cc7d95f4259339a83','opening',0),
('c1e9bbd19a22e89056f55541cc14a9f1','majukumu',0),
('c1f7ed800b498c3e7d5ee7f3cbdedc63','riverside',0),
('c2477f223c3c4ca19a5029e0cd91fda8','cha',0),
('c277c9611f0a0f19beb3658245ac305f','venues',0),
('c2f28daa81da003f46d3865ae0362d5c','permits',0),
('c327b49efdca2668f28cd7b4beee54b3','working',0),
('c42bbd90740264d115048a82c9a10214','alone',0),
('c4ca4238a0b923820dcc509a6f75849b','1',0),
('c4cdd836c5df69ba56216bfb3d4e3fb7','kitu',0),
('c4ef352f74e502ef5e7bc98e6f4e493d','category',0),
('c55ef437cbcc4d74946ba1ce40b31e6d','ambayo',0),
('c5946eb9400717fd6f40e26e36cdb498','received',0),
('c64ace31a7ae9d6b932ef82e562433af','itafanya',0),
('c68271a63ddbc431c307beb7d2918275','out',0),
('c68c559d956d4ca20f435ed74a6e71e6','wa',0),
('c6f057b86584942e415435ffb1fa93d4','000',0),
('c79bdf421714f5087fc34b7c538b6807','submit',0),
('c7c3169c21f1d92e9577871831d067c8','morning',0),
('c81e728d9d4c2f636f067f89cc14862c','2',0),
('c83b72dd001482ce10f0b106c7a0ed0e','way',0),
('c88d5d2b1f62346292376d93bd95c03b','complete.',0),
('c8b6cb5a4739ab2974c13bc3b7887758','kuchukua',0),
('c8e461e773e69f597ca10f66dfc46016','inayofuata',0),
('c9089f3c9adaf0186f6ffb1ee8d6501c','la',0),
('c91497eaedfc46b7398ef737efc428e0','uhuru',0),
('c92a10324374fac681719d63979d00fe','2026',0),
('c994344e3f36e9d9a9e97398adf5ce20','timu',0),
('c9f0f895fb98ab9159f51fd0297e236d','8',0),
('ca0222f0a8e51643bad05c3195c37dc6','ukikuzuia',0),
('ca698f1db3dca4b22a58d2c426ec716e','departments',0),
('cb15e32f389b7af9b285a63ca1044651','waste',0),
('cb73f2f1a23779bd445d8199ad3c522f','11:00',0),
('ccf04975637febdf16f9b1ebddffa3dd','hutunga',0),
('cdaeeeba9b4a4c5ebf042c0215a7bb0e','set',0),
('d056025fbea3c4700729c5b96b0ff97b','passport',0),
('d07182257bce13d49a5c183864e4a277','evaluation',0),
('d0970d0bb517ca0203cd7c95dd98a8f4','requires.',0),
('d0cab90d8d20d57e2f2b9be52f7dd25d','next',0),
('d19f18cfcef6bf11646efd672718c57b','desemba',0),
('d301c2ac0c0c28d573de9c8b2e4ea57c','nakala',0),
('d3d08f32ecb981f9bf60e43277e93177','kwayo',0),
('d4319fefc66c701f24c875afda6360d6','fee',0),
('d4fbae6323ac161c03127c31690d81f4','wodi',0),
('d529e941509eb9e9b9cfaeae1fe7ca23','not',0),
('d54b7ba27571a2f00b38ed9273b974f2','wiki',0),
('d55669822f1a8cf72ec1911e462a54eb','for',0),
('d5ee9f95a62d822c8296af787f94e3bf','imetengenezwa',0),
('d6145d469d21cc6a3c808862fc17d089','zote',0),
('d624e01f1ab405400b5cb596e45c6fc3','permits.',0),
('d6327112b02e4af370dae5ceac67f6e5','zitachukuliwa',0),
('d645920e395fedad7bbbed0eca3fe2e0','40',0),
('d64a4d022098892cecf250b5842c2a48','centre',0),
('d6659eb12bf486df161279952521dcfc','rateable',0),
('d6692dd335c3c6b2ad020e2758eed628','due',0),
('d71a968296f22a13f920ca7e9e36baa1','vikao',0),
('d72749910e71e75279b310239e18f36f','estimates',0),
('d72e436f8bf8d8982bcdb3f51e356849','nambari',0),
('d7427581d459b8812a848189f4ea3636','kuhusu',0),
('d74600e380dbf727f67113fd71669d88','ya',0),
('d78406cbaeb5be8c2ef9dfca493dc55e','kra',0),
('d850f04cdb48312a9be171e214c0b4ee','there',0),
('d85e38447c7ce595b30df48be3e60329','pekee',0),
('d88c2449e1f4aa6a7cdf21932598ce91','kibali',0),
('d8aea03e0a2a7e49a90d3d62728feafe','owed',0),
('d98a07f84921b24ee30f86fd8cd85c3c','from',0),
('d9a22d7a8178d5b42a8750123cbfe5b1','complete',0),
('db5cee64d8879581f189d71178dcb055','nini',0),
('db6d9b451b818ccc9a449383f2f0c450','collection',0),
('db88a0257c220dbfdd2e40f6152d6a8d','how',0),
('dc42cc70ee86f1d2760ddcef21987882','wanaotumia',0),
('dd5c07036f2975ff4bce568b6511d3bc','single',0),
('dd7d7ea7a3ea82cc1a987a084f03e379','usajili',0),
('dde4bab04145ef8852c840d66cd2f07b','makadirio',0),
('de17f0f24b49f8364187891f8550ffbb','record',0),
('de2843227b7e57d11cff826009db0ef4','kilichobadilika.',0),
('de5b97db74bc753f659c63891c3e1e48','kikuzaji',0),
('def87c3849a544babc82c3fc4e84a695','uamuzi',0),
('df3df30793210c75e78c66ecb845d3c9','ghorofa',0),
('df3f079de6961496f0460dcfdbf9bca3','by',0),
('df484065c67680ff240fdd4701aeff4f','november.',0),
('df491a4de50739fa9cffdbd4e3f4b4bb','when',0),
('e0ba0c0363c5c47bb4c42b39afcbe0ae','taka',0),
('e0d2deb0913fdcf884c0f7971df7a623','inawakaribisha',0),
('e0d30cef5c6139275b58b525001b413c','certificate',0),
('e113a38355ed45892a2d3b2d385c48f2','nne',0),
('e170e3a15923188224c1c2bd1477d451','parcel',0),
('e188e9c5f384131b52fd2a30258312d6','inahitaji',0),
('e1a1ba25715bed51a3b86e54d07bcf20','muda',0),
('e23670e9a137bdfe52b8a3a27797a450','ununuzi',0),
('e2eff6c2dafd909df8508f891b385d88','once',0),
('e4894ca167b08880bfc35862f18575eb','available',0),
('e4da3b7fbbce2345d7772b0674a318d5','5',0),
('e58f2b4a9bde8c7c349b44be5b469bb6','utengenezaji',0),
('e60a95f3f443e37f5a47210d9b340a05','october',0),
('e64c3132023b29762b354a750b474c53','things',0),
('e651c10fdbc910984f0f1edd22727541','viwanda',0),
('e6dbca21d4865b265ca2780205b19305','lists',0),
('e6f06702c43d31c81cb42967420c0b31','jambo',0),
('e72f4545eb68c96c754f91fc01573517','office',0),
('e7841e2173994144a0203476d77a72f4','ripoti',0),
('e81c4e4f2b7b93b481e13a8553c2ae1b','or',0),
('e877c56e4fb621e81fd30dbd114a545b','need',0),
('e886b5e8a9e6a8b1a306ac1efb18ec84','them',0),
('e98d2f001da5678b39482efbdf5770dc','report',0),
('ea170e2cafb1337755c8b3d5ae4437f4','find',0),
('ea46e7e94ccee171a97fe14853d5861e','lori',0),
('ea9f91b2cda019730f2891bd12a7a4d6','extra',0),
('eb399bcaca686f8609137153307eecf1','change',0),
('eb5c1399a871211c7e7ed732d15e3a8b','small',0),
('ebb021ec2f9dabb53dcd71109d87c1d5','mtandaoni',0),
('ebbb763f6bd9ffd6ec8d2a7e9a68e91a','yalifanyika',0),
('ebed715e82a0a0f3e950ef6565cdc4a8','place',0),
('ecae13117d6f0584c25a9da6c8f8415e','read',0),
('ecee7df9bbac50b9b428483bfea1dd7c','faith',0),
('ed2b5c0139cec8ad2873829dc1117d50','on',0),
('ed881bac6397ede33c0a285c9f50bb83','everyone',0),
('ee1150845fa3041ceb3a3fcdbe42d68a','evening',0),
('ee45ece1ad226515c7e61bf67940f6dc','huhifadhiwa',0),
('ef56b0b0ddb93c2885892c06be830c68','much',0),
('ef7c842dc2a5a859961053988674cedd','magnifier',0),
('ef836cc47626c394523434ab2fbe7dcd','maoni',0),
('efd2af60c8501931cb9c736b5ad74f65','notice',0),
('f057f5ccb87a310534b9dda3a69a72c4','hii',0),
('f2c67381db28fa11c59fe7a6df0f2587','late',0),
('f2dd6c078b512971abdd8ed871bafb6f','household',0),
('f318725c1410c1d610689d723cdd855c','barabara',0),
('f5d7e2532cc9ad16bc2a41222d76f269','business',0),
('f61657e8b1aa35d4af30522a25c4df3a','bins',0),
('f6f7fec07f372b7bd5eb196bbca0f3f4','friday',0),
('f75cac02116d825a000c33a7c326af37','takes',0),
('f7c0a09108cdf26287c1bc5af2ed1f93','most',0),
('f82d71a6491c31b384ab5b57d85b6593','national',0),
('f894427cc1c571f79da49605ef8b112f','team',0),
('f8dbe7019222241d15ac0a1c3f28a6a0','vibaya.',0),
('f91b2829bf8603e358094e1dedb6f947','draft',0),
('f962bed5616612c8c7053f6e97e72b12','december',0),
('f970e2767d0cfe75876ea857f92e319b','as',0),
('f97c5d29941bfb1b2fdab0874906ab82','one',0),
('f9cb12f89c3f82ffaba2483cd3551d82','participation',0),
('f9f95e1eedab26dc8502590bcea74a76','kisomaji',0),
('fa350f2393222ede0b459dfa89e1df26','hapa',0),
('faa078ebcbce40c9dc56e5163430e48a','kinahusu',0),
('faf005cd0a28451902235d831661432e','yake.',0),
('fb251350149d040f301da700807ee378','approval',0),
('fb5d2d956db4905af044dfb1e0680a95','wrong.',0),
('fb9e0c48b8a116a3da9a28c36bdd6840','17:00',0),
('fbccd5bc2be21e45d77b45272dcefed4','kisheria.',0),
('fbf5b451f590a940e1a18477b062f8e0','renewing',0),
('fbf72ef07575a3df98f24440047b609a','maeneo',0),
('fc0f4646481d70f1b597b52204c360eb','matumizi',0),
('fc9187af4b3b23c0e44e797fe4ba3ee9','siku',0),
('fd375dee4843d6afdf6aeae485db529d','07:00',0),
('fd456406745d816a45cae554c788e754','download',0),
('fd5b2e5383df624fab39afadb1b8896a','kamili',0),
('fdd0f1186c86fe0da3e761f32e50ed55','kuulizwa',0),
('fe17ec3c451f132ef82a3a54e84a461e','tell',0),
('fe3838c7c11aa406dd956566e17360d5','per',0),
('ff1ccf57e98c817df1efcd9fe44a8aeb','we',0),
('ff483d1ff591898a9942916050d2ca3f','identity',0),
('ff6f9e6eb127358d7f6cac078f7fba1d','ambacho',0),
('ffe181130430aff6386df37df36347f8','immediately',0);
/*!40000 ALTER TABLE `index_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_jambotheme_notice_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `jambo_notices` (`pid`,`tx_jambotheme_notice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1793117478,1793117478,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1793187294,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'Apply for a permit, pay a levy, book an appointment at a ward office, or read what Jambo County Council decided at its last sitting.',NULL,'','',0,1,0,'',0,'pagets__default','pagets__subpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(2,1,1793118734,1793118734,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Services','/services',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'All services of Jambo County Council for residents and businesses, grouped by what you need to get done.',NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(3,2,1793118734,1793118734,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Business permits','/services/business-permits',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'How to apply for, renew or amend a single business permit in Jambo County: who needs one, what to bring, the fees and how long it takes.',NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(4,2,1793118734,1793118734,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Land rates','/services/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'Check what is owed on a parcel in Jambo County and pay the current year\'s land rates.',NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(5,1,1793166102,1793166102,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793187294,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',1,0,'','','',NULL,0,'',NULL,0,'',0),
(6,0,1793167382,1793167382,0,0,0,0,'0',256,NULL,0,1,1,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793187294,0,0,0,0,0.5,1,'Mwanzo','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'Omba kibali, lipa ushuru, weka miadi katika ofisi ya wodi, au soma maamuzi ya halmashauri ya Kaunti ya Jambo.',NULL,'','',0,1,0,'',0,'pagets__default','pagets__subpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(7,1,1793167382,1793167382,0,0,0,0,'0',256,NULL,0,1,2,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Huduma','/huduma',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'Huduma zote za Kaunti ya Jambo kwa wakazi na wafanyabiashara, zimepangwa kulingana na unachohitaji kufanya.',NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(8,2,1793167382,1793167382,0,0,0,0,'0',256,NULL,0,1,3,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Vibali vya biashara','/huduma/vibali-vya-biashara',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,'Jinsi ya kuomba, kuongeza muda au kubadilisha kibali cha biashara katika Kaunti ya Jambo: nani anahitaji, vitu vya kubeba, ada na muda.',NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(9,1,1793167382,1793167382,0,0,0,0,'0',1024,NULL,0,1,5,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793167469,0,0,0,0,0.5,1,'Tafuta','/tafuta',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',1,0,'','','',NULL,0,'',NULL,0,'',0),
(10,1,1793172062,1793172062,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Page not found','/404',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',1,0,'','','',NULL,0,'',NULL,0,'',0),
(11,1,1793172062,1793172062,0,0,0,0,'0',2048,NULL,0,1,10,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793172062,0,0,0,0,0.5,1,'Ukurasa haujapatikana','/ukurasa-haujapatikana',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',1,0,'','','',NULL,0,'',NULL,0,'',0),
(12,1,1793174043,1793174043,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Departments','/departments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(13,1,1793174043,1793174043,0,0,0,0,'0',512,NULL,0,1,12,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Idara','/idara',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(14,1,1793174043,1793174043,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(15,1,1793174043,1793174043,0,0,0,0,'0',768,NULL,0,1,14,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Zabuni','/zabuni',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(16,1,1793174043,1793174043,0,0,0,0,'0',896,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'County assembly','/county-assembly',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(17,1,1793174043,1793174043,0,0,0,0,'0',896,NULL,0,1,16,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Bunge la kaunti','/bunge-la-kaunti',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(18,1,1793174043,1793174043,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Contact us','/contact',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(19,1,1793174043,1793174043,0,0,0,0,'0',3072,NULL,0,1,18,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Wasiliana nasi','/wasiliana-nasi',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(20,1,1793174043,1793174043,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Accessibility statement','/accessibility',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(21,1,1793174043,1793174043,0,0,0,0,'0',3328,NULL,0,1,20,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Taarifa ya ufikivu','/taarifa-ya-ufikivu',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(22,1,1793174043,1793174043,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Privacy','/privacy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(23,1,1793174043,1793174043,0,0,0,0,'0',3584,NULL,0,1,22,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Faragha','/faragha',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(24,1,1793174043,1793174043,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Terms of use','/terms',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(25,1,1793174043,1793174043,0,0,0,0,'0',3840,NULL,0,1,24,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793174043,0,0,0,0,0.5,1,'Masharti ya matumizi','/masharti-ya-matumizi',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(26,0,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,1,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793187448,0,0,0,0,0.5,1,'Jambo County Council','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__easyread','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(27,1,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,2,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793187448,0,0,0,0,0.5,1,'Services','/services',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__easyread','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(28,2,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,3,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793187448,0,0,0,0,0.5,1,'Business permits','/services/business-permits',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__easyread','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(29,2,1793178400,1793178400,0,0,0,0,'0',384,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Waste collection','/services/waste-collection',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(30,2,1793178400,1793178400,0,0,0,0,'0',384,NULL,0,1,29,0,NULL,NULL,0,0,0,0,1,0,31,27,0,1793188974,0,0,0,0,0.5,1,'Ukusanyaji wa taka','/huduma/ukusanyaji-wa-taka',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(31,1,1793187294,1793187294,0,0,0,0,'0',4096,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,0,0,0,0,0,0.5,254,'Footer blocks','/footer-blocks',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__footer','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(32,1,1793187294,1793187294,0,0,0,0,'0',4096,NULL,0,1,31,31,NULL,NULL,0,0,0,0,1,1,31,31,1,0,0,0,0,0,0.5,254,'Vipande vya kijachini','/footer-blocks',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__footer','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(33,1,1793187448,1793187448,0,0,0,0,'0',4096,NULL,0,2,31,31,NULL,NULL,0,0,0,0,1,1,31,31,1,0,0,0,0,0,0.5,254,'Footer blocks (Easy Read)','/footer-blocks',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__footer','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(34,1,1793191752,1793191752,0,0,0,0,'0',384,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1793192089,0,0,0,0,0.5,1,'Notices','/notices',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Notices, announcements and tenders of Jambo County Council.','','',0,0,0,'',0,'pagets__notices','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(35,34,1793191768,1793191768,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'Public participation on the 2027 county budget','/notices/public-participation-2027-budget',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Forums open in all twelve wards from 4 November. The draft estimates are published with this notice.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1792620000),
(36,34,1793191768,1793191768,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'Tender: supply of water meters','/notices/tender-supply-of-water-meters',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Bids close at 11:00 on 6 November at the county procurement office.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1792015200),
(37,34,1793191768,1793191768,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'Ward offices closed on 20 October','/notices/ward-offices-closed-20-october',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'All ward offices are closed for Mashujaa Day. Online services remain available.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1791496800),
(38,34,1793191768,1793191768,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'New collection day for Riverside ward','/notices/new-collection-day-riverside',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'From 1 November, household waste in Riverside ward is collected on Tuesdays instead of Thursdays.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1790546400),
(39,1,1793191807,1793191807,0,0,0,0,'0',384,NULL,0,1,34,34,NULL,NULL,0,0,0,0,31,31,31,31,1,1793192089,0,0,0,0,0.5,1,'Matangazo','/matangazo',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Matangazo, tangazo na zabuni za Kaunti ya Jambo.','','',0,0,0,'',0,'pagets__notices','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(40,34,1793191807,1793191807,0,0,0,0,'0',256,NULL,0,1,35,35,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027','/matangazo/ushirikishwaji-wa-umma-bajeti-2027',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1792620000),
(41,34,1793191807,1793191807,0,0,0,0,'0',512,NULL,0,1,36,36,NULL,NULL,0,0,0,0,31,31,31,31,1,0,0,0,0,0,0.5,1,'Zabuni: usambazaji wa mita za maji','/matangazo/zabuni-usambazaji-wa-mita-za-maji',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Zabuni zitafungwa saa 5:00 asubuhi tarehe 6 Novemba katika ofisi ya ununuzi ya kaunti.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1792015200),
(42,34,1793191807,1793191807,0,0,0,0,'0',768,NULL,0,1,37,37,NULL,NULL,0,0,0,0,31,31,31,31,1,0,0,0,0,0,0.5,1,'Ofisi za wodi zitafungwa tarehe 20 Oktoba','/matangazo/ofisi-za-wodi-zitafungwa-20-oktoba',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Ofisi zote za wodi zitafungwa kwa Siku ya Mashujaa. Huduma za mtandaoni zitaendelea kupatikana.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1791496800),
(43,34,1793191807,1793191807,0,0,0,0,'0',1024,NULL,0,1,38,38,NULL,NULL,0,0,0,0,31,31,31,31,1,1793191857,0,0,0,0,0.5,1,'Siku mpya ya kuchukua taka kwa wodi ya Riverside','/matangazo/siku-mpya-ya-kuchukua-taka-riverside',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,'Kuanzia tarehe 1 Novemba, taka za nyumbani katika wodi ya Riverside zitachukuliwa siku ya Jumanne badala ya Alhamisi.','','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',1790546400);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1793163092,1793163092,'/slider/county-headquarters.jpg','a15b6183f9ec81266d2af8efd8345d46569f5cbf','a610353c12c21ed74dfc46c6d9794e62dbab9b9c','jpg','county-headquarters.jpg','0fbcf5c065fa5c01c7b7903350330e7c34e42a87',1793163092,1793163092,51046,1,2,'image/jpeg',0,0),
(2,0,1793163092,1793163092,'/slider/ward-office.jpg','25cd1100a5ecff40f178f4a984b007fbe01fae8d','a610353c12c21ed74dfc46c6d9794e62dbab9b9c','jpg','ward-office.jpg','580878ef2613974553c2d3a27eadf7f78c3a3604',1793163092,1793163092,46119,1,2,'image/jpeg',0,0),
(3,0,1793163092,1793163092,'/slider/public-participation.jpg','245c9622162bb703ef267ae7effdf282d91cb5cc','a610353c12c21ed74dfc46c6d9794e62dbab9b9c','jpg','public-participation.jpg','06bc3e26c47dc5afe97e7ef382bd87f9aead211d',1793163092,1793163092,52081,1,2,'image/jpeg',0,0),
(4,0,1793177470,1793177470,'/easyread/paper.png','313f2d21ed4fddfe98dd9f280273cf1dbe6829a8','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','paper.png','9e51ecd7b484e818afddc084f57cb26f81512635',1793177470,1793177470,1424,1,2,'image/png',0,0),
(5,0,1793177470,1793177470,'/easyread/shop.png','bfff539e837066dfac793f1f253847acb60f7076','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','shop.png','6502733750936c2bf34710f9972ae41279a04572',1793177470,1793177470,1577,1,2,'image/png',0,0),
(6,0,1793177470,1793177470,'/easyread/id.png','286bec281374aef0418bb9096319155af8a6f987','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','id.png','6be58163e9723436eed91dd9f1ecd427f5698323',1793177470,1793177470,1394,1,2,'image/png',0,0),
(7,0,1793177470,1793177470,'/easyread/money.png','6352c90aa747213e5dcf245b96a18991f03a318a','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','money.png','b7897564f5f1e8a5ad6f048ac841b6cef9051811',1793177470,1793177470,2682,1,2,'image/png',0,0),
(8,0,1793177470,1793177470,'/easyread/clock.png','f530d1cfa00e780faee3656d73245b674b013aeb','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','clock.png','9e34083140b4a3850a88abe526c53f92c76c8753',1793177470,1793177470,2403,1,2,'image/png',0,0),
(9,0,1793177471,1793177471,'/easyread/calendar.png','2d5a0cbf83dcc3a9100a144691c39bbee4c209e0','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','calendar.png','9b2761ed829e8ab3f9742d74809c025b5c13cb9d',1793177471,1793177471,1236,1,2,'image/png',0,0),
(10,0,1793177471,1793177471,'/easyread/phone.png','0534a6db12c7d3087637f9400f0c3076b1b90304','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','phone.png','1cf7ac1d9cf1ea3fdd70660a1a068db301b2f9ea',1793177471,1793177471,1191,1,2,'image/png',0,0),
(11,0,1793177471,1793177471,'/easyread/building.png','ecb99315b76b2b950e76140bb198aa86a26bd091','a5b202dd4f014c0241626ea4b68365122f62c3fb','png','building.png','371b6665045500c724eb91fc7d6800a13539a56f',1793177471,1793177471,1544,1,2,'image/png',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1793163092,1793163092,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,1280,720),
(2,0,1793163092,1793163092,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1280,720),
(3,0,1793163092,1793163092,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,1280,720),
(4,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,320,320),
(5,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,320,320),
(6,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,320,320),
(7,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,320,320),
(8,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,320,320),
(9,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,320,320),
(10,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,320,320),
(11,0,1793177470,1793177470,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,320,320);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1793163092,1793163092,0,0,0,0,NULL,NULL,0,0,0,0,1,'County Headquarters','County Headquarters, Jambo County Council',23,'tt_content','assets',16,'','The county headquarters on Uhuru Road, Jambo Town.',NULL,0),
(2,1,1793163092,1793163092,0,0,0,0,NULL,NULL,0,0,0,0,2,'Ward Office','Ward Office, Jambo County Council',23,'tt_content','assets',32,'','One of the twelve ward offices where applications are handed in.',NULL,0),
(3,1,1793163092,1793163092,0,0,0,0,NULL,NULL,0,0,0,0,3,'Public Participation','Public Participation, Jambo County Council',23,'tt_content','assets',48,'','A public participation forum on the county budget.',NULL,0),
(4,1,1793167469,1793167469,0,0,1,0,NULL,NULL,0,0,0,0,1,'County Headquarters','County Headquarters, Jambo County Council',26,'tt_content','assets',16,'','The county headquarters on Uhuru Road, Jambo Town.',NULL,0),
(5,1,1793167469,1793167469,0,0,1,0,NULL,NULL,0,0,0,0,2,'Ward Office','Ward Office, Jambo County Council',26,'tt_content','assets',32,'','One of the twelve ward offices where applications are handed in.',NULL,0),
(6,1,1793167469,1793167469,0,0,1,0,NULL,NULL,0,0,0,0,3,'Public Participation','Public Participation, Jambo County Council',26,'tt_content','assets',48,'','A public participation forum on the county budget.',NULL,0),
(7,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,4,NULL,NULL,67,'tt_content','assets',16,'',NULL,NULL,0),
(8,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,5,NULL,NULL,68,'tt_content','assets',16,'',NULL,NULL,0),
(9,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,6,NULL,NULL,69,'tt_content','assets',16,'',NULL,NULL,0),
(10,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,7,NULL,NULL,70,'tt_content','assets',16,'',NULL,NULL,0),
(11,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,8,NULL,NULL,71,'tt_content','assets',16,'',NULL,NULL,0),
(12,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,9,NULL,NULL,72,'tt_content','assets',16,'',NULL,NULL,0),
(13,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,10,NULL,NULL,73,'tt_content','assets',16,'',NULL,NULL,0),
(14,3,1793177518,1793177518,0,0,2,0,NULL,NULL,0,0,0,0,11,NULL,NULL,74,'tt_content','assets',16,'',NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1793163092,1793163092,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('000bc5e8a04c1f74322146b3e03fec78','tt_content',26,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('01825a4513c269885861eb1881c6ab5b','tt_content',72,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('018a27a32f801a1307521803f7b373dd','pages',41,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('039671c7fbe499b0ae9729f7f94319a0','tx_jambotheme_wastereport',3,'reporter_email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'juma@example.com'),
('08a8a7cb224e06287478fba5572c6403','tt_content',41,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',18,'',0,0,2147483647,0,0,''),
('08c71ec432cdc3456984f27cf4ed4dfd','tx_jambotheme_wastereport',12,'reporter_email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'112@linawolf.de'),
('0b4c6534aa1eefb09159ced7c2a6afa4','tt_content',31,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',8,'',0,0,2147483647,0,0,''),
('0b8a91881b286c90c6a509eaf99edd57','tt_content',23,'assets',0,0,2147483647,0,'','','',2,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('0beb744274edf6b0265f454bb25a4ad7','tt_content',38,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',15,'',0,0,2147483647,0,0,''),
('0f7acc98f38b0c305d9925781bbb3cd9','tt_content',62,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','2083a4b9ed9ca94607ab7a3a8890d08a',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:jambo_theme/Resources/Private/Forms/Contact.form.yaml'),
('0fdbe0772f9cf5d478cf0e85344280bc','tt_content',83,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',79,'',0,0,2147483647,0,0,''),
('11aa4c3cfbd8a5e7c24c37952d799339','pages',39,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('13a89f350fd497923b037f8f679d4d64','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('13e3f775f5fe55e34e6c3053fc81a294','sys_file',7,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',7,'',0,0,2147483647,0,0,''),
('15fd99ffa7357c9b1d4290d396f2780f','sys_file_metadata',4,'file',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('17b1520e71bbe3a8a6c594c9f44d07b9','sys_file',9,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',9,'',0,0,2147483647,0,0,''),
('181c4219ab2dcdc5d6a1d623c6b860d3','tt_content',26,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',23,'',0,0,2147483647,0,0,''),
('1853cddbab491124aa78e712cc126f1e','tt_content',81,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',79,'',0,0,2147483647,0,0,''),
('19822ae0973ac192ea6045fcd35af0fc','pages',6,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('1a11a7eb070686e6264bbb96c4f958ed','tt_content',78,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','60fc88a9df5edfbe891cc3d59e53815a',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:jambo_theme/Resources/Private/Forms/WasteReport.form.yaml'),
('1ab42020417acef1530669b4287fb1ea','sys_file_metadata',11,'file',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('1cfc48d2a55989a55fcf860dc6d09489','tt_content',45,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',24,'',0,0,2147483647,0,0,''),
('1f656faa342bb8b9196f37d35d52ac51','pages',27,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('213146efdd3867d03d12928213f5aba0','tt_content',63,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','29660bbd323c5b101553373eac9625c5',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:jambo_theme/Resources/Private/Forms/Contact.form.yaml'),
('22e73aa869347277eb1f98fc138067d2','sys_file_metadata',2,'file',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('2990074c2ac26ce0fc9b820af817b847','tt_content',25,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('29aded0541fbe819d625270b833a58bb','pages',19,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('2ac9ddedd4e0a86dc399142738897b5f','tt_content',4,'header_link',0,0,2147483647,0,'','typolink','6e311ef6da871410c737b95116694a38:0',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('2b8fd3bf8f17fb10f9b6fb7eda11a741','tx_jambotheme_wastereport',2,'reporter_email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'peter@example.com'),
('2c9886c59d7883ed13346344887a7622','tt_content',68,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('2ce902cae778b9a56de801356dcddf0c','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('317eb3d89624e7ca4c1e7c48e9fe4828','pages',15,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('34102ecdb4ca95a375622fa369601066','be_users',2,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'admin@example.com'),
('363a9e113503620ecef9238f87707287','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('37347550ff60a6cf38bcb64ee24fbe35','tt_content',28,'header_link',0,0,2147483647,0,'','typolink','31813718afeea9d66c3a817f0c1218ae:0',0,0,'pages',4,'',0,0,2147483647,0,0,''),
('380e10d43e1d99311339bacb4f435d06','tt_content',25,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('39302b34fcc68b7cc0dab6f16be7c324','sys_file',8,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',8,'',0,0,2147483647,0,0,''),
('3acfe234198b02a3137c7cfef723bd15','pages',8,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('3c4d8f680737b3cdefab6ce2b70c559d','tt_content',27,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('3f0097ba64cf183104209c396ce64e6a','tt_content',53,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',52,'',0,0,2147483647,0,0,''),
('3f496062b937549b16c7105df3ac0e64','tt_content',46,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('41cfc82c3d5168e637c384eb4e7dc36c','tt_content',26,'assets',0,0,2147483647,0,'','','',2,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('424177cc66e48f13f354b0b940243c4e','tt_content',59,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',58,'',0,0,2147483647,0,0,''),
('48046f6c269a74f08ae3d6397050e9ff','pages',7,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('4835e93e559ec686e4495769e2c931bf','tt_content',94,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',93,'',0,0,2147483647,0,0,''),
('4abe9d9d0277427e44d88aa88ef61290','tt_content',42,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',19,'',0,0,2147483647,0,0,''),
('4be399adefeb3cc95622a5f86ff7ed1b','tt_content',32,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',9,'',0,0,2147483647,0,0,''),
('4fe8795a5add8fa13eb54185dd3ead44','tt_content',40,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',17,'',0,0,2147483647,0,0,''),
('50af37a6aba7104ee641c9a9b1b56283','pages',17,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('5111ab441654e6e7ef77662c3bee182e','tt_content',49,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',48,'',0,0,2147483647,0,0,''),
('5306137c51ebbd5dbc00502af5f6a469','tt_content',29,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('5341ca441793f1b038d308db596b1408','tt_content',23,'assets',0,0,2147483647,0,'','','',1,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('5ad66d6480348045c9d0e4e54e0927f8','tt_content',26,'assets',0,0,2147483647,0,'','','',1,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('5cf62de176f58998d1750ec070eb9269','sys_file',2,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',2,'',0,0,2147483647,0,0,''),
('60508ef2be643b160fb0fc63f365e3ba','tt_content',30,'header_link',0,0,2147483647,0,'','typolink','8de9d296cab54ce4cc55288010480fa2:0',0,0,'pages',29,'',0,0,2147483647,0,0,''),
('616feed3a553cefd5488378a5f16d5fe','tt_content',82,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',80,'',0,0,2147483647,0,0,''),
('61d39f3d46a7bb9513278df79a0a76d8','tt_content',44,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',21,'',0,0,2147483647,0,0,''),
('635bac3c063fbbcb7060a974039c5081','pages',40,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('639ad7da6747b34084e96c9360ebc7e4','sys_file_metadata',9,'file',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('6b74150609c2657059f4a1c36ea28644','tt_content',71,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('6c928314713c4ec3c2f302f6b41cf5f1','pages',42,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',37,'',0,0,2147483647,0,0,''),
('6cb94a06e4835f70377b2c2505264d82','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6eb138246d217ee81b5eb43c5716a2d1','tt_content',39,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',16,'',0,0,2147483647,0,0,''),
('72b4788dae857d73dc9433d7e4f570bd','pages',33,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('74b492ebf5d6fc6d864b1a0bff0ef3a5','tt_content',30,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('75398b5339481684cc2cc42b2e111aab','tt_content',74,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('759cfc95586433c158d5daae0939a6dd','sys_file',10,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',10,'',0,0,2147483647,0,0,''),
('7712a94ad0d272cf77bab364d68a51a1','tt_content',3,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('7cf5539af7669ec526e2c650638b69d6','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('7f29e93606596d2b888faf8c177109d1','pages',11,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',10,'',0,0,2147483647,0,0,''),
('83af79dd2cebb1569ddf61622df52bcb','sys_file_metadata',7,'file',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('8568a93b81e2869cfffefb6279d9ee07','tt_content',37,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',14,'',0,0,2147483647,0,0,''),
('86fce793f324ca1cec94d75167e780bd','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('8b6bf81d0406fb9fe90b544eae0d3ca9','tt_content',69,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('8efc34e52cddc3fadb5443a9a54e6021','tt_content',28,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('90033f8b1866e540db0d58e7d1193652','pages',13,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('9007b97bbb373a088e39dbfd723a9094','sys_file_metadata',6,'file',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('90fd028475224f949d9ab767f80df5af','pages',26,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('9368c7e5cbd438c6fc6e686d599f2949','tt_content',67,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('a04baa7b3668cabfe53f1cb056be2f4e','tt_content',78,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',76,'',0,0,2147483647,0,0,''),
('a115c7a8ceda810b5e698670b3b8ac8f','tt_content',25,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',3,'',0,0,2147483647,0,0,''),
('a4f9c3b02221061d680001c748e78f1f','pages',43,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',38,'',0,0,2147483647,0,0,''),
('a513d9657d0eaacaef280aaac15e3a55','tt_content',90,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',86,'',0,0,2147483647,0,0,''),
('ab0a22e273aa9ec0a772a45251c999d6','sys_file_reference',14,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('ab92bcc272dabcb367e189e9ca50910c','tt_content',89,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',85,'',0,0,2147483647,0,0,''),
('ae70fcb3155e060d13cb06a7d1703fc7','sys_file',11,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',11,'',0,0,2147483647,0,0,''),
('b0663031ec0592a8a9b50dfacd7546b4','tt_content',91,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',87,'',0,0,2147483647,0,0,''),
('b358f98e1fb19d9f2aac25e892cee6f7','tt_content',55,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',54,'',0,0,2147483647,0,0,''),
('b5552926925ef34bdea4e4251f844eae','sys_file_reference',13,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('b90992884f1e8b7e6fca97e41791c506','tt_content',51,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',50,'',0,0,2147483647,0,0,''),
('b992e35a9b8ac7186a9837b47c249bbc','pages',25,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',24,'',0,0,2147483647,0,0,''),
('bb07476d9b0172491715d5ea40709c28','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('bcbafdf044fb76300f4104ff455fe8b0','pages',28,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('bd5e5bd53415f212cde4bfb5923cc8e5','sys_file',4,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',4,'',0,0,2147483647,0,0,''),
('bdf6c943a76155ce076282877f8ff98d','tt_content',3,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('c166d0787f5d9b05fc574e0d30829f46','tt_content',7,'header_link',0,0,2147483647,0,'','typolink','f5193c0381a6717a7169398680924f81:0',0,0,'pages',29,'',0,0,2147483647,0,0,''),
('cabfc6812ea1f143feda324c759597d7','tt_content',73,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('cd163a2c18c84f815d501e2a11ebe7f0','pages',23,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',22,'',0,0,2147483647,0,0,''),
('cda0cd25aefb2c262fabb8608bdd8606','tt_content',76,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','9d252e9f173afcff861fbc85530c69d0',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:jambo_theme/Resources/Private/Forms/WasteReport.form.yaml'),
('ce6a585e7afe58ff67d97d915f452c15','tt_content',47,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',46,'',0,0,2147483647,0,0,''),
('ce9f19b6de747ff379a24086c1985f85','sys_file_metadata',5,'file',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('cf73e971e8ab0a36ead30bf460b76973','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('d1957bd7670c45ee6d9b54261e2d7f14','pages',21,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,''),
('d3114ff3fff65827b38d9b18145da0db','tt_content',57,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',56,'',0,0,2147483647,0,0,''),
('d68285a61a65f8369e1fd4bb50db9b33','tt_content',92,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',88,'',0,0,2147483647,0,0,''),
('d860d9389667c92145871d401a40f562','sys_file',6,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',6,'',0,0,2147483647,0,0,''),
('da3d88bce1f8d47ee5763aadfab6558a','sys_file_metadata',8,'file',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('daafc02dc669e278a3e54f8a8f928f9d','tt_content',84,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',80,'',0,0,2147483647,0,0,''),
('dc5316bae719ecd33b1a6721fcefbd20','tt_content',77,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',75,'',0,0,2147483647,0,0,''),
('dc55cca02c447704220ab80b9b8b65cb','sys_file_metadata',10,'file',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('ddcf553c464429ac8db1d03f0ab67211','sys_file_reference',11,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('de0bb0266d6d3d48a90260aec50943de','be_users',3,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'112@linawolf.de'),
('e14bed1495e3abd3b23633bf5a55d362','pages',30,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',29,'',0,0,2147483647,0,0,''),
('e175cdf1edbaf43ce703bdd16b12ddb9','tt_content',47,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('e6155b32298627f0c80162b43348c6dd','tx_jambotheme_wastereport',1,'reporter_email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'asha@example.com'),
('e6d1231d15b9b30923b161ff80a14ec5','sys_file_metadata',3,'file',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('e7b87dbb167738410a95a97cc92816ec','tt_content',36,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',13,'',0,0,2147483647,0,0,''),
('e95b18135be25665443ebc89b59d58fc','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('e979f5172b9aa804c27b98c901dc724c','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('ea87cd91bb75472a4ce5e81407db87dd','pages',32,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('ec05cf9ac3b7229886b037ccb51eb38f','tt_content',27,'header_link',0,0,2147483647,0,'','typolink','97985cf7cc34399810ebf4059b877a91:0',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('ec7d65a25718ca99a7f4a62f9263c9bc','tt_content',70,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('eebcb0b96346fd66634a4a1bce05a5a5','tt_content',5,'header_link',0,0,2147483647,0,'','typolink','1e38a01f424ede96b79b8ff662ea9576:0',0,0,'pages',4,'',0,0,2147483647,0,0,''),
('f1b141d8d9468fcfaf6a18e0a1fb5cc7','sys_file',3,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',3,'',0,0,2147483647,0,0,''),
('f474d1ee7e98aa066da21688bed4ed78','tt_content',63,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',62,'',0,0,2147483647,0,0,''),
('f65fcfc6ebb391842f2718555b2e9a8f','tt_content',61,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',60,'',0,0,2147483647,0,0,''),
('f8906d3b5bbff0f57bd27814e3d86b80','tt_content',43,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',20,'',0,0,2147483647,0,0,''),
('f91618b29ba11f410ce357b5cdca063c','pages',9,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',5,'',0,0,2147483647,0,0,''),
('f9c64f1c71a8b40ffa94f38fcbb366b0','sys_file_metadata',1,'file',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('fcbd136a536addcfdce07c893438ca9b','tt_content',23,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('ffa602de6cc41aa063aec87c7234f976','sys_file',5,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',5,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'core','formProtectionSessionToken:2','s:64:\"1dc33496b21d712622a0daea8ff4f0c34801c1284bef35765849bbeb7e6500cc\";'),
(38,'core','formProtectionSessionToken:3','s:64:\"9c51b070a28bc3bfb63e26bca9edc5a41e032672e3f9638850a6198042cdc0d0\";'),
(39,'extensionDataImport','jambo_theme:ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','indexed_search:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'core','sys_refindex_lastUpdate','i:1793204177;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1793117478,1793117478,1,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(2,3,1793118742,1793118742,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Business permits',0,'','','','<p class=\"lede\">Every business operating in Jambo County needs a single business permit for the current year.</p><h2>Who needs a permit</h2><p>A permit is required for any trade, service or manufacturing activity carried out in the county, including a business run from home.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(3,1,1793119088,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'County services, online and in one place',1,'','','','<p>Apply for a permit, pay a levy, book an appointment at a ward office, or read what the council decided at its last sitting.</p><p class=\"button-row\"><a class=\"button\" href=\"t3://page?uid=2\">Find a service</a> <a class=\"button button--secondary\" href=\"t3://page?uid=18\">Book an appointment</a></p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(4,1,1793119088,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Business permits',3,'','t3://page?uid=3','','<p>Apply for a single business permit, renew one, or change the details on it.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(5,1,1793119088,1793119088,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Land rates',3,'','t3://page?uid=4','','<p>Check what is owed on a parcel and pay the current year&rsquo;s rates.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(6,1,1793119088,1793119088,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Building approvals',3,'','','','<p>Submit plans for approval and follow the status of a submission.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(7,1,1793119088,1793119088,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Waste collection',3,'','t3://page?uid=29','','<p>Collection days by ward, and how to report a missed collection.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(8,1,1793119088,1793119088,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Health facilities',3,'','','','<p>Opening hours and services of the county clinics and dispensaries.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(9,1,1793119088,1793119088,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Public participation',3,'','','','<p>Dates, venues and papers for the county&rsquo;s public participation forums.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(10,1,1793191857,1793119088,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1792620000,'Public participation on the 2027 county budget',3,'','','','<p>Forums open in all twelve wards from 4 November. The draft estimates are published with this notice.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(11,1,1793191857,1793119088,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1792015200,'Tender: supply of water meters',3,'','','','<p>Bids close at 11:00 on 6 November at the county procurement office.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(12,1,1793191857,1793119088,1,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1791496800,'Ward offices closed on 20 October',3,'','','','<p>All ward offices are closed for Mashujaa Day. Online services remain available.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(13,2,1793188974,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Services',1,'','','','<p class=\"lead\">Everything the county does for residents and businesses, grouped by what you need to get done.</p><p>Most services can be started online. Where a visit is needed, the page for that service says which office to go to and what to bring.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(14,3,1793188974,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Business permits',1,'','','','<p class=\"lead\">Every business operating in Jambo County needs a single business permit for the current year. Apply online, at a ward office, or at the county headquarters.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(15,3,1793119088,1793119088,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Who needs a permit',2,'','','','<p>A permit is required for any trade, service or manufacturing activity carried out in the county, including a business run from home. One permit covers one premises. A business with premises in two wards needs a permit for each.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(16,3,1793119088,1793119088,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'What you need to apply',2,'','','','<ul><li>The registration certificate of the business</li><li>The national identity card or passport of the owner</li><li>The KRA PIN certificate</li><li>The plot number or the lease agreement of the premises</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(17,3,1793188974,1793119088,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Fees',2,'','','','<table><caption>Permit fees for the 2026 calendar year</caption><thead><tr><th scope=\"col\">Category</th><th scope=\"col\">Employees</th><th scope=\"col\">Fee per year</th></tr></thead><tbody><tr><th scope=\"row\">Small trader</th><td>Up to 5</td><td>KSh 5,000</td></tr><tr><th scope=\"row\">Medium enterprise</th><td>6 to 20</td><td>KSh 15,000</td></tr><tr><th scope=\"row\">Large enterprise</th><td>More than 20</td><td>KSh 40,000</td></tr></tbody></table>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(18,3,1793119088,1793119088,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'How long it takes',2,'','','','<p>A complete application is decided within five working days. The permit is issued at the office where the application was made, and a copy is sent to the email address on the application.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(19,3,1793188040,1793119088,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'callout',0,NULL,0,'text',0,0,'','',0,'Renewing a permit',2,'','','','<p>Permits run to 31 December and are renewed from 2 January. A permit renewed after 31 March carries a late fee of ten per cent.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(20,3,1793119088,1793119088,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Contact',2,'','','','<p>Department of Trade, Industry and Cooperatives<br>County Headquarters, second floor<br>Monday to Friday, 08:00&ndash;17:00</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(21,3,1793188040,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'callout',2,NULL,0,'text',0,0,'','',0,'Need help applying?',3,'','','','<p>The county contact centre answers on 0800 000 000, Monday to Friday, 08:00&ndash;17:00.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(22,4,1793188974,1793119088,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Land rates',1,'','','','<p class=\"lead\">Land rates are charged on every rateable parcel in the county and fall due on 1 January each year.</p><p>Check the balance on a parcel with its plot number, then pay online, at a ward office, or by bank transfer.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(23,1,1793163092,1793163092,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',1,NULL,0,'jambotheme_imageslider',0,0,'','',0,'A look around the county',2,'','','',NULL,0,3,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(24,5,1793166102,1793166102,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'indexedsearch_pi2',0,0,'','',0,'Search this site',1,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(25,1,1793167469,1793167469,0,0,0,0,'0',256,NULL,0,1,3,3,NULL,NULL,0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Huduma za kaunti, mtandaoni na mahali pamoja',1,'','','','<p>Omba kibali, lipa ushuru, weka miadi katika ofisi ya wodi, au soma maamuzi ya halmashauri katika kikao chake cha mwisho.</p><p class=\"button-row\"><a class=\"button\" href=\"t3://page?uid=2\">Tafuta huduma</a> <a class=\"button button--secondary\" href=\"t3://page?uid=18\">Weka miadi</a></p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(26,1,1793167469,1793167469,0,0,0,0,'0',512,NULL,0,1,23,23,NULL,NULL,0,0,0,0,'default',1,NULL,0,'jambotheme_imageslider',0,0,'','',0,'Mandhari ya kaunti',2,'','','','',0,3,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(27,1,1793167469,1793167469,0,0,0,0,'0',256,NULL,0,1,4,4,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Vibali vya biashara',3,'','t3://page?uid=3','','<p>Omba kibali kimoja cha biashara, kikiongeze muda, au badilisha maelezo yake.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(28,1,1793167469,1793167469,0,0,0,0,'0',512,NULL,0,1,5,5,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Ushuru wa ardhi',3,'','t3://page?uid=4','','<p>Angalia deni la kiwanja na ulipe ushuru wa mwaka huu.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(29,1,1793167469,1793167469,0,0,0,0,'0',768,NULL,0,1,6,6,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Idhini za ujenzi',3,'','','','<p>Wasilisha michoro kwa idhini na ufuatilie hali ya maombi.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(30,1,1793167469,1793167469,0,0,0,0,'0',1024,NULL,0,1,7,7,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Ukusanyaji wa taka',3,'','t3://page?uid=29','','<p>Siku za ukusanyaji kwa kila wodi, na jinsi ya kuripoti ukusanyaji uliokosekana.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(31,1,1793167469,1793167469,0,0,0,0,'0',1280,NULL,0,1,8,8,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Vituo vya afya',3,'','','','<p>Saa za kufunguliwa na huduma za zahanati na vituo vya afya vya kaunti.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(32,1,1793167469,1793167469,0,0,0,0,'0',1536,NULL,0,1,9,9,NULL,NULL,0,0,0,0,'default',2,NULL,0,'text',0,0,'','',0,'Ushirikishwaji wa umma',3,'','','','<p>Tarehe, mahali na nyaraka za mikutano ya ushirikishwaji wa umma.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(33,1,1793191857,1793167469,1,0,0,0,'0',256,NULL,0,1,10,10,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1792620000,'Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027',3,'','','','<p>Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(34,1,1793191857,1793167469,1,0,0,0,'0',512,NULL,0,1,11,11,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1792015200,'Zabuni: usambazaji wa mita za maji',3,'','','','<p>Zabuni zitafungwa saa 5:00 asubuhi tarehe 6 Novemba katika ofisi ya ununuzi ya kaunti.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(35,1,1793191857,1793167469,1,0,0,0,'0',768,NULL,0,1,12,12,NULL,NULL,0,0,0,0,'default',3,NULL,0,'text',0,0,'','',1791496800,'Ofisi za wodi zitafungwa tarehe 20 Oktoba',3,'','','','<p>Ofisi zote za wodi zitafungwa kwa Siku ya Mashujaa. Huduma za mtandaoni zitaendelea kupatikana.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(36,2,1793188974,1793167469,0,0,0,0,'0',256,NULL,0,1,13,13,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Huduma',1,'','','','<p class=\"lead\">Kila kitu ambacho kaunti hufanya kwa wakazi na wafanyabiashara, kimepangwa kulingana na unachohitaji kufanya.</p><p>Huduma nyingi zinaweza kuanzishwa mtandaoni. Pale inapohitajika kufika ana kwa ana, ukurasa wa huduma husika unaeleza ofisi ya kwenda na vitu vya kubeba.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(37,3,1793188974,1793167469,0,0,0,0,'0',256,NULL,0,1,14,14,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Vibali vya biashara',1,'','','','<p class=\"lead\">Kila biashara inayofanya kazi katika Kaunti ya Jambo inahitaji kibali kimoja cha biashara kwa mwaka husika. Omba mtandaoni, katika ofisi ya wodi, au katika makao makuu ya kaunti.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(38,3,1793167469,1793167469,0,0,0,0,'0',512,NULL,0,1,15,15,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Nani anahitaji kibali',2,'','','','<p>Kibali kinahitajika kwa biashara, huduma au utengenezaji wowote unaofanyika katika kaunti, pamoja na biashara inayoendeshwa nyumbani. Kibali kimoja kinahusu eneo moja. Biashara yenye maeneo katika wodi mbili inahitaji kibali kwa kila eneo.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(39,3,1793167469,1793167469,0,0,0,0,'0',768,NULL,0,1,16,16,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Unachohitaji ili kuomba',2,'','','','<ul><li>Cheti cha usajili wa biashara</li><li>Kitambulisho cha taifa au pasipoti ya mmiliki</li><li>Cheti cha PIN cha KRA</li><li>Nambari ya kiwanja au mkataba wa kukodi eneo</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(40,3,1793188974,1793167469,0,0,0,0,'0',1024,NULL,0,1,17,17,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ada',2,'','','','<table><caption>Ada za vibali kwa mwaka wa 2026</caption><thead><tr><th scope=\"col\">Kundi</th><th scope=\"col\">Wafanyakazi</th><th scope=\"col\">Ada kwa mwaka</th></tr></thead><tbody><tr><th scope=\"row\">Mfanyabiashara mdogo</th><td>Hadi 5</td><td>KSh 5,000</td></tr><tr><th scope=\"row\">Biashara ya kati</th><td>6 hadi 20</td><td>KSh 15,000</td></tr><tr><th scope=\"row\">Biashara kubwa</th><td>Zaidi ya 20</td><td>KSh 40,000</td></tr></tbody></table>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(41,3,1793167469,1793167469,0,0,0,0,'0',1280,NULL,0,1,18,18,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Muda unaochukuliwa',2,'','','','<p>Maombi kamili hukamilishwa ndani ya siku tano za kazi. Kibali hutolewa katika ofisi ambapo maombi yalifanyika, na nakala hutumwa kwa barua pepe iliyotajwa katika maombi.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(42,3,1793188040,1793167469,0,0,0,0,'0',1536,NULL,0,1,19,19,NULL,NULL,0,0,0,0,'callout',0,NULL,0,'text',0,0,'','',0,'Kuongeza muda wa kibali',2,'','','','<p>Vibali huisha tarehe 31 Desemba na huongezwa muda kuanzia tarehe 2 Januari. Kibali kinachoongezwa muda baada ya tarehe 31 Machi hutozwa ada ya ucheleweshaji ya asilimia kumi.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(43,3,1793167469,1793167469,0,0,0,0,'0',1792,NULL,0,1,20,20,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Mawasiliano',2,'','','','<p>Idara ya Biashara, Viwanda na Ushirika<br>Makao Makuu ya Kaunti, ghorofa ya pili<br>Jumatatu hadi Ijumaa, 08:00&ndash;17:00</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(44,3,1793188040,1793167469,0,0,0,0,'0',256,NULL,0,1,21,21,NULL,NULL,0,0,0,0,'callout',2,NULL,0,'text',0,0,'','',0,'Unahitaji msaada kuomba?',3,'','','','<p>Kituo cha mawasiliano cha kaunti hupatikana kwa 0800 000 000, Jumatatu hadi Ijumaa, 08:00&ndash;17:00.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(45,5,1793167469,1793167469,0,0,0,0,'0',256,NULL,0,1,24,24,NULL,NULL,0,0,0,0,'default',0,NULL,0,'indexedsearch_pi2',0,0,'','',0,'Tafuta katika tovuti hii',1,'','','','',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(46,10,1793188974,1793172062,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Page not found',1,'','','','<p class=\"lead\">The page you asked for does not exist, or it has been moved.</p><p>Try the <a href=\"t3://page?uid=2\">list of services</a>, or search this site from the box at the top of the page.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(47,10,1793188974,1793172062,0,0,0,0,'0',256,NULL,0,1,46,46,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ukurasa haujapatikana',1,'','','','<p class=\"lead\">Ukurasa uliouomba haupo, au umehamishwa.</p><p>Jaribu <a href=\"t3://page?uid=2\">orodha ya huduma</a>, au tafuta katika tovuti hii kwa kisanduku kilicho juu ya ukurasa.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(48,12,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Departments',1,'','','','<p class=\"lead\">The ten departments of the county and what each of them is responsible for.</p><p>Every department lists the services it runs, the offices where they are delivered, and who to ask when something goes wrong.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(49,12,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,48,48,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Idara',1,'','','','<p class=\"lead\">Idara kumi za kaunti na majukumu ya kila moja.</p><p>Kila idara inaorodhesha huduma zake, ofisi zinapotolewa, na wa kuulizwa jambo linapoenda vibaya.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(50,14,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Tenders',1,'','','','<p class=\"lead\">Open tenders of Jambo County, with closing dates and the documents to download.</p><p>Bids are received at the county procurement office. Awards are published here once the evaluation is complete.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(51,14,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,50,50,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Zabuni',1,'','','','<p class=\"lead\">Zabuni zilizo wazi za Kaunti ya Jambo, pamoja na tarehe za kufunga na nyaraka za kupakua.</p><p>Zabuni hupokelewa katika ofisi ya ununuzi ya kaunti. Washindi huchapishwa hapa tathmini ikikamilika.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(52,16,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'County assembly',1,'','','','<p class=\"lead\">The assembly makes the laws of the county and approves its budget.</p><p>Sittings are open to the public. Order papers, bills and the record of each sitting are published after it.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(53,16,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,52,52,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Bunge la kaunti',1,'','','','<p class=\"lead\">Bunge hutunga sheria za kaunti na kuidhinisha bajeti yake.</p><p>Vikao viko wazi kwa umma. Ratiba, miswada na kumbukumbu za kila kikao huchapishwa baada yake.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(54,18,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Contact us',1,'','','','<p class=\"lead\">How to reach Jambo County Council.</p><p>County Headquarters, Uhuru Road, Jambo Town. Monday to Friday, 08:00&ndash;17:00. The contact centre answers on 0800 000 000.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(55,18,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,54,54,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Wasiliana nasi',1,'','','','<p class=\"lead\">Jinsi ya kuwasiliana na Kaunti ya Jambo.</p><p>Makao Makuu ya Kaunti, Barabara ya Uhuru, Mji wa Jambo. Jumatatu hadi Ijumaa, 08:00&ndash;17:00. Kituo cha mawasiliano hupatikana kwa 0800 000 000.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(56,20,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Accessibility statement',1,'','','','<p class=\"lead\">This site is built to be usable by everyone, including people who use a screen reader, a keyboard alone, or a magnifier.</p><p>If a page gets in your way, tell us on 0800 000 000 and we will fix it and tell you what changed.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(57,20,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,56,56,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Taarifa ya ufikivu',1,'','','','<p class=\"lead\">Tovuti hii imetengenezwa itumike na kila mtu, wakiwemo wanaotumia kisomaji skrini, kibodi pekee, au kikuzaji.</p><p>Ukurasa ukikuzuia, tuambie kwa 0800 000 000 nasi tutarekebisha na kukueleza kilichobadilika.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(58,22,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Privacy',1,'','','','<p class=\"lead\">What the county does with the data you give it.</p><p>Data submitted with an application is used to decide that application and is kept for as long as the law requires.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(59,22,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,58,58,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Faragha',1,'','','','<p class=\"lead\">Kaunti hufanya nini na taarifa unazotoa.</p><p>Taarifa zinazotolewa na maombi hutumika kuamua maombi hayo na huhifadhiwa kwa muda unaotakiwa kisheria.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(60,24,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Terms of use',1,'','','','<p class=\"lead\">The terms on which this site is provided.</p><p>The information here is published in good faith. Where it differs from a decision of the council, the decision stands.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(61,24,1793188974,1793174043,0,0,0,0,'0',256,NULL,0,1,60,60,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Masharti ya matumizi',1,'','','','<p class=\"lead\">Masharti ambayo tovuti hii hutolewa kwayo.</p><p>Taarifa zilizopo hapa huchapishwa kwa nia njema. Zikitofautiana na uamuzi wa halmashauri, uamuzi hushinda.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(62,18,1793174686,1793174686,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Send us a message',2,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:jambo_theme/Resources/Private/Forms/Contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(63,18,1793174686,1793174686,0,0,0,0,'0',512,NULL,0,1,62,62,NULL,NULL,0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Tutumie ujumbe',2,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:jambo_theme/Resources/Private/Forms/Contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(64,1,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Jambo County Council',1,'','','','<p>These pages are in Easy Read.</p><p>Easy Read is easier to read.</p><p>It has short sentences and pictures.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(65,2,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Services',1,'','','','<p>These are things the county does for you.</p><p>Right now one page is in Easy Read.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(66,3,1793177518,1793177518,0,0,0,0,'0',256,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Business permits',1,'','','','<p>This page is in Easy Read.</p><p>It tells you about business permits.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(67,3,1793177518,1793177518,0,0,0,0,'0',512,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'What is a business permit?',2,'','','','<p>A permit is a paper from the county.</p><p>It says you can run your business.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(68,3,1793177518,1793177518,0,0,0,0,'0',768,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'Who needs a permit?',2,'','','','<p>You need a permit for every business.</p><p>This is true if you work from home too.</p><p>You need one permit for each place you work.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(69,3,1793177518,1793177518,0,0,0,0,'0',1024,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'What you need to bring',2,'','','','<ul><li>The paper that says your business is registered</li><li>Your ID card or your passport</li><li>Your KRA PIN paper</li><li>The paper for your plot or your rent</li></ul>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(70,3,1793177518,1793177518,0,0,0,0,'0',1280,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'What it costs',2,'','','','<p>You pay money once a year.</p><p>How much you pay depends on how many people work for you.</p><ul><li>Up to 5 people: 5,000 shillings</li><li>6 to 20 people: 15,000 shillings</li><li>More than 20 people: 40,000 shillings</li></ul>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(71,3,1793177518,1793177518,0,0,0,0,'0',1536,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'How long it takes',2,'','','','<p>We answer in 5 working days.</p><p>You get your permit at the office where you asked.</p><p>We also send a copy to your email.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(72,3,1793177518,1793177518,0,0,0,0,'0',1792,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'Every year you need a new permit',2,'','','','<p>Your permit stops on 31 December.</p><p>You can get a new one from 2 January.</p><p>If you wait until after 31 March, you pay extra money.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(73,3,1793177518,1793177518,0,0,0,0,'0',2048,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'If you need help',2,'','','','<p>You can call us.</p><p>Our number is 0800 000 000.</p><p>We answer Monday to Friday.</p><p>We are there from 8 in the morning to 5 in the evening.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(74,3,1793177518,1793177518,0,0,0,0,'0',2304,NULL,0,2,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'jambotheme_easyread',0,0,'','',0,'Where to find us',2,'','','','<p>You can come to our office.</p><p>Department of Trade.</p><p>County Headquarters, second floor.</p>',0,1,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(75,29,1793188974,1793178400,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Waste collection',1,'','','','<p class=\"lead\">Household waste is collected once a week, on the day set for your ward.</p><p>If your waste was not collected on the day it should have been, tell us below. The waste team receives every report the next morning.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(76,29,1793178400,1793178400,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Report a missed collection',2,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:jambo_theme/Resources/Private/Forms/WasteReport.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(77,29,1793188974,1793178400,0,0,0,0,'0',256,NULL,0,1,75,75,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ukusanyaji wa taka',1,'','','','<p class=\"lead\">Taka za nyumbani huchukuliwa mara moja kwa wiki, siku iliyopangwa kwa wodi yako.</p><p>Ikiwa taka zako hazikuchukuliwa siku iliyopangwa, tuambie hapa chini. Timu ya taka hupokea kila ripoti asubuhi inayofuata.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(78,29,1793178400,1793178400,0,0,0,0,'0',512,NULL,0,1,76,76,NULL,NULL,0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Ripoti taka zisizochukuliwa',2,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:jambo_theme/Resources/Private/Forms/WasteReport.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(79,31,1793187294,1793187294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>County Headquarters<br>Uhuru Road, Jambo Town<br>P.O. Box 1200&ndash;00100</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(80,31,1793187294,1793187294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>Monday to Friday<br>08:00&ndash;17:00</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(81,31,1793187294,1793187294,0,0,0,0,'0',256,NULL,0,1,79,79,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>Makao Makuu ya Kaunti<br>Barabara ya Uhuru, Mji wa Jambo<br>S.L.P. 1200&ndash;00100</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(82,31,1793187294,1793187294,0,0,0,0,'0',256,NULL,0,1,80,80,NULL,NULL,0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>Jumatatu hadi Ijumaa<br>08:00&ndash;17:00</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(83,31,1793187448,1793187448,0,0,0,0,'0',256,NULL,0,2,79,79,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>You can visit our office:<br>County Headquarters, Uhuru Road<br>Jambo Town</p><p>You can write to us:<br>P.O. Box 1200&ndash;00100</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(84,31,1793187448,1793187448,0,0,0,0,'0',256,NULL,0,2,80,80,NULL,NULL,0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'',100,'','','','<p>We are open Monday to Friday.</p><p>From 8 in the morning<br>to 5 in the afternoon.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(85,35,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Public participation on the 2027 county budget',1,'','','','<p class=\"lead\">Forums open in all twelve wards from 4 November. The draft estimates are published with this notice.</p><p>The county invites residents to comment on the draft budget estimates for the 2027 financial year. Each ward holds one forum, starting at 10:00 at the ward office.</p><p>Written submissions may be left at any ward office or sent to the county clerk until 18 November.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(86,36,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Tender: supply of water meters',1,'','','','<p class=\"lead\">Bids close at 11:00 on 6 November at the county procurement office.</p><p>The county invites sealed bids for the supply and delivery of 2,000 domestic water meters.</p><p>Tender documents are available at the procurement office at the county headquarters from 20 October, against a non-refundable fee of KSh 1,000. Bids are opened publicly immediately after closing.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(87,37,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ward offices closed on 20 October',1,'','','','<p class=\"lead\">All ward offices are closed for Mashujaa Day. Online services remain available.</p><p>All twelve ward offices and the county headquarters are closed on Tuesday 20 October for Mashujaa Day, and open again at 08:00 on Wednesday 21 October.</p><p>Permits, land rates and appointments can be dealt with online while the offices are closed.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(88,38,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'New collection day for Riverside ward',1,'','','','<p class=\"lead\">From 1 November, household waste in Riverside ward is collected on Tuesdays instead of Thursdays.</p><p>The change lets one lorry serve Riverside and Market wards on the same round.</p><p>Please leave bins at the kerb by 07:00. If a collection is missed, report it on the waste collection page.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(89,35,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,1,85,85,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ushirikishwaji wa umma kuhusu bajeti ya kaunti ya 2027',1,'','','','<p class=\"lead\">Mikutano itaanza katika wodi zote kumi na mbili kuanzia tarehe 4 Novemba. Makadirio ya awali yamechapishwa pamoja na tangazo hili.</p><p>Kaunti inawakaribisha wakazi kutoa maoni kuhusu makadirio ya awali ya bajeti ya mwaka wa fedha wa 2027. Kila wodi itafanya mkutano mmoja, kuanzia saa nne asubuhi katika ofisi ya wodi.</p><p>Maoni yaliyoandikwa yanaweza kuachwa katika ofisi yoyote ya wodi au kutumwa kwa karani wa kaunti hadi tarehe 18 Novemba.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(90,36,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,1,86,86,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Zabuni: usambazaji wa mita za maji',1,'','','','<p class=\"lead\">Zabuni zitafungwa saa 5:00 asubuhi tarehe 6 Novemba katika ofisi ya ununuzi ya kaunti.</p><p>Kaunti inakaribisha zabuni zilizofungwa kwa usambazaji wa mita 2,000 za maji za nyumbani.</p><p>Hati za zabuni zinapatikana katika ofisi ya ununuzi makao makuu ya kaunti kuanzia tarehe 20 Oktoba, kwa ada ya KSh 1,000 isiyorejeshwa. Zabuni zitafunguliwa hadharani mara baada ya kufungwa.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(91,37,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,1,87,87,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Ofisi za wodi zitafungwa tarehe 20 Oktoba',1,'','','','<p class=\"lead\">Ofisi zote za wodi zitafungwa kwa Siku ya Mashujaa. Huduma za mtandaoni zitaendelea kupatikana.</p><p>Ofisi zote kumi na mbili za wodi na makao makuu ya kaunti zitafungwa siku ya Jumanne tarehe 20 Oktoba kwa Siku ya Mashujaa, na zitafunguliwa tena saa mbili asubuhi siku ya Jumatano tarehe 21 Oktoba.</p><p>Vibali, ushuru wa ardhi na miadi vinaweza kufanyiwa kazi mtandaoni wakati ofisi zimefungwa.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(92,38,1793191857,1793191857,0,0,0,0,'0',256,NULL,0,1,88,88,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Siku mpya ya kuchukua taka kwa wodi ya Riverside',1,'','','','<p class=\"lead\">Kuanzia tarehe 1 Novemba, taka za nyumbani katika wodi ya Riverside zitachukuliwa siku ya Jumanne badala ya Alhamisi.</p><p>Mabadiliko haya yanaruhusu lori moja kuhudumia wodi za Riverside na Market katika safari moja.</p><p>Tafadhali weka mapipa kando ya barabara kabla ya saa moja asubuhi. Kama taka hazikuchukuliwa, ripoti katika ukurasa wa ukusanyaji wa taka.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(93,34,1793192089,1793192089,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Notices and announcements',1,'','','','<p class=\"lead\">Decisions, tenders and announcements of Jambo County Council, newest first.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(94,34,1793192089,1793192089,0,0,0,0,'0',128,NULL,0,1,93,93,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Matangazo na taarifa',1,'','','','<p class=\"lead\">Maamuzi, zabuni na taarifa za Kaunti ya Jambo, mpya zaidi kwanza.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
